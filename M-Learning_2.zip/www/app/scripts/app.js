﻿/*!
 * This file is part of App Builder
 * For licenses information see App Builder help
 * ©2016 App Builder - https://www.davidesperalta.com
 */

window.App = {};

window.App.Plugins = {};

window.App.Utils = (function() {

  var
    lastPlaySound = new Audio();

  return {

    strLen: function(text) {
      return text.length;
    },

    trimStr: function(text) {
      return text.trim();
    },

    strSearch: function(text, query) {
      return text.search(query);
    },

    splitStr: function(text, separator) {
      return text.split(separator);
    },

    subStr: function(text, start, count) {
      return text.substr(start, count);
    },

    strReplace: function(text, from, to) {
      return text.replace(from, to);
    },

    strReplaceAll: function(text, from, to) {
      return text.split(from).join(to);
    },

    playSound: function(mp3Url, oggUrl) {
      if (lastPlaySound.canPlayType('audio/mpeg')) {
        lastPlaySound.src = mp3Url;
        lastPlaySound.type = 'audio/mpeg';
      } else {
        lastPlaySound.src = oggUrl;
        lastPlaySound.type = 'audio/ogg';
      }
      lastPlaySound.play();
    },

    stopSound: function() {
      lastPlaySound.pause();
      lastPlaySound.currentTime = 0.0;
    },

    sleep: function(milliseconds) {
      var
        start = new Date().getTime();
      for (var i = 0; i < 1e7; i++) {
        if ((new Date().getTime() - start) > milliseconds){
          break;
        }
      }
    }
  };
})();

window.App.Modal = (function() {

  var
    stack = [],
    current = 0;

  return {

    insert: function(name) {
      current = stack.length;
      stack[current] = {};
      stack[current].name = name;
      stack[current].instance = null;
      return stack[current];
    },

    removeCurrent: function() {
      stack.slice(current, 1);
      current = current - 1;
      current = (current < 0) ? 0 : current;
    },

    currentInstance: function() {
      if (stack[current]) {
        return stack[current].instance;
      } else {
        return null;
      }
    },

    closeAll: function() {
      for (var i = stack.length-1; i >= 0; i--) {
        stack[i].instance.dismiss();
      }
      stack = [];
      current = 0;
    }
  };
})();

window.App.Debugger = (function() {

  return {

    isRunning: function() {
      return (typeof window.external === 'object')
       && ('hello' in window.external);
    },

    log: function(text, aType, lineNum) {
      if (window.App.Debugger.isRunning()) {
        external.log('' + text, aType || 'info', lineNum || 0);
      } else {
        console.log(text);
      }
    },

    watch: function(varName, newValue, oldValue) {
      if (window.App.Debugger.isRunning()) {
        if (angular.isArray(newValue)) {
          external.watch('', varName, newValue.toString(), 'array');
        } else if (angular.isObject(newValue)) {
          angular.forEach(newValue, function(value, key) {
            if (!angular.isFunction(value)) {
              try {
                external.watch(varName, key, value.toString(), typeof value);
              } catch(exception) {}
            }
          });
        } else if (angular.isString(newValue) || angular.isNumber(newValue)) {
          external.watch('', varName, newValue.toString(), typeof newValue);
        }
      }
    }
  };
})();

window.App.Module = angular.module
(
  'AppModule',
  [
    'ngRoute',
    'ngTouch',
    'ngSanitize',
    'blockUI',
    'chart.js',
    'ngOnload',
    'ui.bootstrap',
    'angular-canvas-gauge',
    'com.2fdevs.videogular',
    'com.2fdevs.videogular.plugins.controls',
    'AppCtrls'
  ]
);

window.App.Module.directive('ngImageLoad',
[
  '$parse',

  function($parse) {
    return {
      restrict: 'A',
      link: function($scope, el, attrs) {
        el.bind('load', function(event) {
          var
            fn = $parse(attrs.ngImageLoad);
          fn($scope, {$event: event});
        });
      }
    }
  }
]);

window.App.Module.directive('ngContextMenu',
[
  '$parse',

  function($parse) {
    return {
      restrict: 'A',
      link: function($scope, el, attrs) {
        el.bind('contextmenu', function(event) {
          var
            fn = $parse(attrs.ngContextMenu);
          fn($scope, {$event: event});
        });
      }
    }
  }
]);

window.App.Module.directive('bindFile',
[
  function() {
    return {
      restrict: 'A',
      require: 'ngModel',
      link: function($scope, el, attrs, ngModel) {
        el.bind('change', function(event) {
          ngModel.$setViewValue(event.target.files[0]);
          $scope.$apply();
        });

        $scope.$watch(function () {
          return ngModel.$viewValue;
        }, function(value) {
          if (!value) {
            el.val('');
          }
        });
      }
    }
  }
]);

window.App.Module.config
([
  '$compileProvider',

  function($compileProvider) {
    $compileProvider.debugInfoEnabled(window.App.Debugger.isRunning());
    $compileProvider.imgSrcSanitizationWhitelist
     (/^\s*(https?|blob|ftp|mailto|file|tel|app|data:image|chrome-extension|ms-appx-web):/);
  }
]);

window.App.Module.config
([
  '$httpProvider',

  function($httpProvider) {
    if (!$httpProvider.defaults.headers.get) {
      $httpProvider.defaults.headers.get = {};
    }
    if (!$httpProvider.defaults.headers.post) {
      $httpProvider.defaults.headers.post = {};
    }
    $httpProvider.defaults.headers.get['Pragma'] = 'no-cache';
    $httpProvider.defaults.headers.get['Cache-Control'] = 'no-cache';
    $httpProvider.defaults.headers.get['If-Modified-Since'] = 'Mon, 26 Jul 1997 05:00:00 GMT';
    $httpProvider.defaults.headers.post['Content-Type'] = undefined;
    $httpProvider.defaults.transformRequest.unshift(function(data) {
      var
        frmData = new FormData();
      angular.forEach(data, function(value, key) {
        frmData.append(key, value);
      });
      return frmData;
    });
}]);

window.App.Module.config
([
  '$provide',

  function($provide) {
    $provide.decorator('$exceptionHandler',
    ['$injector',
      function($injector) {
        return function(exception, cause) {
          var
            $rs = $injector.get('$rootScope');

          if (!angular.isUndefined(cause)) {
            exception.message += ' (caused by "'+cause+'")';
          }

          $rs.App.LastError = exception.message;
          $rs.OnAppError();
          $rs.App.LastError = '';

          if (window.App.Debugger.isRunning()) {
            throw exception;
          } else {
            if (window.console) {
              window.console.error(exception);
            }
          }
        };
      }
    ]);
  }
]);

window.App.Module.config
([
  'blockUIConfig',

  function(blockUIConfig) {
    blockUIConfig.delay = 0;
    blockUIConfig.autoBlock = false;
    blockUIConfig.resetOnException = true;
    blockUIConfig.message = 'Please wait';
    blockUIConfig.autoInjectBodyBlock = false;
    blockUIConfig.blockBrowserNavigation = true;
  }
]);

window.App.Module.config
([
  '$routeProvider',

  function($routeProvider) {
    $routeProvider.otherwise({redirectTo: "/Login"})
    .when("/Login", {controller: "LoginCtrl", templateUrl: "app/views/Login.html"})
    .when("/HomeDosen", {controller: "HomeDosenCtrl", templateUrl: "app/views/HomeDosen.html"})
    .when("/MateriDosenHome", {controller: "MateriDosenHomeCtrl", templateUrl: "app/views/MateriDosenHome.html"})
    .when("/MateriDosenTambah", {controller: "MateriDosenTambahCtrl", templateUrl: "app/views/MateriDosenTambah.html"})
    .when("/MahasiswaEnroll", {controller: "MahasiswaEnrollCtrl", templateUrl: "app/views/MahasiswaEnroll.html"})
    .when("/DetailMateriDosen", {controller: "DetailMateriDosenCtrl", templateUrl: "app/views/DetailMateriDosen.html"})
    .when("/MenuMateriDosen", {controller: "MenuMateriDosenCtrl", templateUrl: "app/views/MenuMateriDosen.html"})
    .when("/MenuTugasDosen", {controller: "MenuTugasDosenCtrl", templateUrl: "app/views/MenuTugasDosen.html"})
    .when("/MenuEnroll", {controller: "MenuEnrollCtrl", templateUrl: "app/views/MenuEnroll.html"})
    .when("/DosenTugasTambah", {controller: "DosenTugasTambahCtrl", templateUrl: "app/views/DosenTugasTambah.html"})
    .when("/TugasDosenHome", {controller: "TugasDosenHomeCtrl", templateUrl: "app/views/TugasDosenHome.html"})
    .when("/NilaiTugasHome", {controller: "NilaiTugasHomeCtrl", templateUrl: "app/views/NilaiTugasHome.html"})
    .when("/ListMateriTugas", {controller: "ListMateriTugasCtrl", templateUrl: "app/views/ListMateriTugas.html"})
    .when("/TugasMahasiswaDosen", {controller: "TugasMahasiswaDosenCtrl", templateUrl: "app/views/TugasMahasiswaDosen.html"})
    .when("/DetailTugasDosen", {controller: "DetailTugasDosenCtrl", templateUrl: "app/views/DetailTugasDosen.html"})
    .when("/ListMatkulEnroll", {controller: "ListMatkulEnrollCtrl", templateUrl: "app/views/ListMatkulEnroll.html"})
    .when("/Materi", {controller: "MateriCtrl", templateUrl: "app/views/Materi.html"})
    .when("/Home", {controller: "HomeCtrl", templateUrl: "app/views/Home.html"})
    .when("/ViewMateriMahasiwa", {controller: "ViewMateriMahasiwaCtrl", templateUrl: "app/views/ViewMateriMahasiwa.html"})
    .when("/DetailMateriMahasiswa", {controller: "DetailMateriMahasiswaCtrl", templateUrl: "app/views/DetailMateriMahasiswa.html"})
    .when("/ViewTugasMahasisa", {controller: "ViewTugasMahasisaCtrl", templateUrl: "app/views/ViewTugasMahasisa.html"})
    .when("/DetailTugasMahasiswa", {controller: "DetailTugasMahasiswaCtrl", templateUrl: "app/views/DetailTugasMahasiswa.html"})
    .when("/MahasiswaKirimTugas", {controller: "MahasiswaKirimTugasCtrl", templateUrl: "app/views/MahasiswaKirimTugas.html"})
    .when("/ViewNilaiTugasMahasiswa", {controller: "ViewNilaiTugasMahasiswaCtrl", templateUrl: "app/views/ViewNilaiTugasMahasiswa.html"})
    .when("/DetailNilaiMahasiswa", {controller: "DetailNilaiMahasiswaCtrl", templateUrl: "app/views/DetailNilaiMahasiswa.html"})
    .when("/ViewTugasMahasiswaDosen", {controller: "ViewTugasMahasiswaDosenCtrl", templateUrl: "app/views/ViewTugasMahasiswaDosen.html"});
  }
]);

window.App.Module.service
(
  'AppEventsService',

  ['$rootScope',

  function($rootScope) {

    function setAppHideEvent() {
      window.document.addEventListener('visibilitychange', function(event) {
        if (window.document.hidden) {
          window.App.Event = event;
          $rootScope.OnAppHide();
          $rootScope.$apply();
        }
      }, false);
    }
    
    function setAppShowEvent() {
      window.document.addEventListener('visibilitychange', function(event) {
        if (!window.document.hidden) {
          window.App.Event = event;
          $rootScope.OnAppShow();
          $rootScope.$apply();
        }
      }, false);
    }    

    function setAppOnlineEvent() {
      window.addEventListener('online', function(event) {
        window.App.Event = event;
        $rootScope.OnAppOnline();
      }, false);
    }

    function setAppOfflineEvent() {
      window.addEventListener('offline', function(event) {
        window.App.Event = event;
        $rootScope.OnAppOffline();
      }, false);
    }

    function setAppResizeEvent() {
      window.addEventListener('resize', function(event) {
        window.App.Event = event;
        $rootScope.OnAppResize();
      }, false);
    }

    function setAppPauseEvent() {
      if (!window.App.Cordova) {
        document.addEventListener('pause', function(event) {
          window.App.Event = event;
          $rootScope.OnAppPause();
          $rootScope.$apply();
        }, false);
      }
    }

    function setAppReadyEvent() {
      if (window.App.Cordova) {
        angular.element(window.document).ready(function(event) {
          window.App.Event = event;
          $rootScope.OnAppReady();
        });
      } else {
        document.addEventListener('deviceready', function(event) {
          window.App.Event = event;
          $rootScope.OnAppReady();
        }, false);
      }
    }

    function setAppResumeEvent() {
      if (!window.App.Cordova) {
        document.addEventListener('resume', function(event) {
          window.App.Event = event;
          $rootScope.OnAppResume();
          $rootScope.$apply();
        }, false);
      }
    }

    function setAppBackButtonEvent() {
      if (!window.App.Cordova) {
        document.addEventListener('backbutton', function(event) {
          window.App.Event = event;
          $rootScope.OnAppBackButton();
        }, false);
      }
    }

    function setAppMenuButtonEvent() {
      if (!window.App.Cordova) {
        document.addEventListener('deviceready', function(event) {
          // http://stackoverflow.com/q/30309354
          navigator.app.overrideButton('menubutton', true);
          document.addEventListener('menubutton', function(event) {
            window.App.Event = event;
            $rootScope.OnAppMenuButton();
          }, false);
        }, false);
      }
    }

    function setAppOrientationEvent() {
      window.addEventListener('orientationchange', function(event) {
        window.App.Event = event;
        $rootScope.OnAppOrientation();
      }, false);
    }

    function setAppVolumeUpEvent() {
      if (!window.App.Cordova) {
        document.addEventListener('volumeupbutton', function(event) {
          window.App.Event = event;
          $rootScope.OnAppVolumeUpButton();
        }, false);
      }
    }

    function setAppVolumeDownEvent() {
      if (!window.App.Cordova) {
        document.addEventListener('volumedownbutton', function(event) {
          window.App.Event = event;
          $rootScope.OnAppVolumeDownButton();
        }, false);
      }
    }

    function setAppKeyUpEvent() {
      document.addEventListener('keyup', function(event) {
        window.App.Event = event;
        $rootScope.OnAppKeyUp();
      }, false);
    }

    function setAppKeyDownEvent() {
      document.addEventListener('keydown', function(event) {
        window.App.Event = event;
        $rootScope.OnAppKeyDown();
      }, false);
    }

    function setAppMouseUpEvent() {
      document.addEventListener('mouseup', function(event) {
        window.App.Event = event;
        $rootScope.OnAppMouseUp();
      }, false);
    }

    function setAppMouseDownEvent() {
      document.addEventListener('mousedown', function(event) {
        window.App.Event = event;
        $rootScope.OnAppMouseDown();
      }, false);
    }

    function setAppViewChangeEvent() {
      angular.element(window.document).ready(function(event) {
        $rootScope.$on('$locationChangeStart', function(event, next, current) {
          window.App.Event = event;
          $rootScope.App.NextView = next.substring(next.lastIndexOf('/') + 1);
          $rootScope.App.CurrentView = current.substring(current.lastIndexOf('/') + 1);
          $rootScope.OnAppViewChange();
        });
      });
    }

    return {
      init : function() {
        //setAppHideEvent();
        //setAppShowEvent();
        //setAppReadyEvent();
        //setAppPauseEvent();
        //setAppKeyUpEvent();
        //setAppResumeEvent();
        //setAppResizeEvent();
        //setAppOnlineEvent();
        //setAppKeyDownEvent();
        //setAppMouseUpEvent();
        //setAppOfflineEvent();
        //setAppVolumeUpEvent();
        //setAppMouseDownEvent();
        //setAppVolumeDownEvent();
        //setAppBackButtonEvent();
        //setAppMenuButtonEvent();
        //setAppViewChangeEvent();
        //setAppOrientationEvent();
      }
    };
  }
]);

window.App.Module.service
(
  'AppGlobalsService',

  ['$rootScope', '$filter',

  function($rootScope, $filter) {

    var setGlobals = function() {
      $rootScope.App = {};
      var s = function(name, method) {
        Object.defineProperty($rootScope.App, name, { get: method });
      };
      s('Online', function() { return navigator.onLine; });
      s('WeekDay', function() { return new Date().getDay(); });
      s('Event', function() { return window.App.Event || ''; });
      s('OuterWidth', function() { return window.outerWidth; });
      s('InnerWidth', function() { return window.innerWidth; });
      s('InnerHeight', function() { return window.innerHeight; });
      s('OuterHeight', function() { return window.outerHeight; });
      s('Timestamp', function() { return new Date().getTime(); });
      s('Day', function() { return $filter('date')(new Date(), 'dd'); });
      s('Fullscreen', function() { return BigScreen.element !== null; });
      s('Hour', function() { return $filter('date')(new Date(), 'hh'); });
      s('Week', function() { return $filter('date')(new Date(), 'ww'); });
      s('Month', function() { return $filter('date')(new Date(), 'MM'); });
      s('Year', function() { return $filter('date')(new Date(), 'yyyy'); });
      s('Hour24', function() { return $filter('date')(new Date(), 'HH'); });
      s('Minutes', function() { return $filter('date')(new Date(), 'mm'); });
      s('Seconds', function() { return $filter('date')(new Date(), 'ss'); });
      s('DayShort', function() { return $filter('date')(new Date(), 'd'); });
      s('WeekShort', function() { return $filter('date')(new Date(), 'w'); });
      s('HourShort', function() { return $filter('date')(new Date(), 'h'); });
      s('YearShort', function() { return $filter('date')(new Date(), 'yy'); });
      s('MonthShort', function() { return $filter('date')(new Date(), 'M'); });
      s('Hour24Short', function() { return $filter('date')(new Date(), 'H'); });
      s('MinutesShort', function() { return $filter('date')(new Date(), 'm'); });
      s('SecondsShort', function() { return $filter('date')(new Date(), 's'); });
      s('Milliseconds', function() { return $filter('date')(new Date(), 'sss'); });
      s('Cordova', function() {  return angular.isUndefined(window.App.Cordova) ? 'true' : 'false' });
      s('Orientation', function() { return window.innerWidth >= window.innerHeight ? 'landscape' : 'portrait'; });
      s('ActiveControl', function() { return (window.document.activeElement !== null) ? window.document.activeElement.id : '' });

      
$rootScope.App.IdleIsIdling = "false";
$rootScope.App.IdleIsRunning = "false";
$rootScope.App.ID = "com.m.learning";
$rootScope.App.Name = "M-Learning";
$rootScope.App.Version = "1.0.0";
$rootScope.App.Description = "Another App Builder app";
$rootScope.App.AuthorName = "Me";
$rootScope.App.AuthorEmail = "me@ok.com";
$rootScope.App.AuthorUrl = "https://www.ok.com/";
$rootScope.App.Scaled = "scaled";
$rootScope.App.Theme = "Default";
$rootScope.App.Themes = ["Default"];
if ($rootScope.App.Themes.indexOf("Default") == -1) { $rootScope.App.Themes.push("Default"); }
$rootScope.LanguageCode = "en";
$rootScope.TextDirection = "ltr";
    };

    return {
      init : function() {
        setGlobals();
      }
    };
  }
]);

window.App.Module.service
(
  'AppControlsService',

  ['$rootScope', '$http', '$sce',

  function($rootScope, $http, $sce) {

    var setControlVars = function() {
      

$rootScope.Simpan = {};
$rootScope.Simpan.Hidden = "";
$rootScope.Simpan.Title = "";
$rootScope.Simpan.TabIndex = 5;
$rootScope.Simpan.TooltipText = "";
$rootScope.Simpan.TooltipPos = "top";
$rootScope.Simpan.PopoverText = "";
$rootScope.Simpan.PopoverTitle = "";
$rootScope.Simpan.PopoverEvent = "mouseenter";
$rootScope.Simpan.PopoverPos = "top";
$rootScope.Simpan.Badge = "";
$rootScope.Simpan.Icon = "glyphicon glyphicon-floppy-disk";
$rootScope.Simpan.Text = "Login";
$rootScope.Simpan.Class = "btn btn-success btn-lg ";
$rootScope.Simpan.Disabled = "";

$rootScope.Label2 = {};
$rootScope.Label2.Hidden = "";
$rootScope.Label2.Class = "";
$rootScope.Label2.Text = "Password :";
$rootScope.Label2.Input = "";
$rootScope.Label2.Title = "";
$rootScope.Label2.TooltipText = "";
$rootScope.Label2.TooltipPos = "top";
$rootScope.Label2.PopoverText = "";
$rootScope.Label2.PopoverEvent = "mouseenter";
$rootScope.Label2.PopoverTitle = "";
$rootScope.Label2.PopoverPos = "top";

$rootScope.Label4 = {};
$rootScope.Label4.Hidden = "";
$rootScope.Label4.Class = "";
$rootScope.Label4.Text = "Username NIM / NIP :";
$rootScope.Label4.Input = "";
$rootScope.Label4.Title = "";
$rootScope.Label4.TooltipText = "";
$rootScope.Label4.TooltipPos = "top";
$rootScope.Label4.PopoverText = "";
$rootScope.Label4.PopoverEvent = "mouseenter";
$rootScope.Label4.PopoverTitle = "";
$rootScope.Label4.PopoverPos = "top";

$rootScope.P1 = {};
$rootScope.P1.Hidden = "";
$rootScope.P1.Value = "1";
$rootScope.P1.Title = "";
$rootScope.P1.TabIndex = 1;
$rootScope.P1.TooltipText = "";
$rootScope.P1.TooltipPos = "top";
$rootScope.P1.PopoverText = "";
$rootScope.P1.PopoverEvent = "mouseenter";
$rootScope.P1.PopoverTitle = "";
$rootScope.P1.PopoverPos = "top";
$rootScope.P1.PlaceHolder = "isikan username...";
$rootScope.P1.Class = "form-control input-lg ";
$rootScope.P1.Disabled = "";
$rootScope.P1.Required = "true";
$rootScope.P1.ReadOnly = "";

$rootScope.Batal = {};
$rootScope.Batal.Hidden = "";
$rootScope.Batal.Title = "";
$rootScope.Batal.TabIndex = -1;
$rootScope.Batal.TooltipText = "";
$rootScope.Batal.TooltipPos = "top";
$rootScope.Batal.PopoverText = "";
$rootScope.Batal.PopoverTitle = "";
$rootScope.Batal.PopoverEvent = "mouseenter";
$rootScope.Batal.PopoverPos = "top";
$rootScope.Batal.Badge = "";
$rootScope.Batal.Icon = "glyphicon glyphicon-remove";
$rootScope.Batal.Text = "Batal";
$rootScope.Batal.Class = "btn btn-danger btn-lg ";
$rootScope.Batal.Disabled = "";

$rootScope.HtmlContent2 = {};
$rootScope.HtmlContent2.Hidden = "";
$rootScope.HtmlContent2.Class = "";
$rootScope.HtmlContent2.Title = "";
$rootScope.HtmlContent2.TooltipText = "";
$rootScope.HtmlContent2.TooltipPos = "top";
$rootScope.HtmlContent2.PopoverText = "";
$rootScope.HtmlContent2.PopoverEvent = "mouseenter";
$rootScope.HtmlContent2.PopoverTitle = "";
$rootScope.HtmlContent2.PopoverPos = "top";

$rootScope.P2 = {};
$rootScope.P2.Hidden = "";
$rootScope.P2.Value = "1";
$rootScope.P2.Title = "";
$rootScope.P2.TabIndex = -1;
$rootScope.P2.TooltipText = "";
$rootScope.P2.TooltipPos = "top";
$rootScope.P2.PopoverText = "";
$rootScope.P2.PopoverEvent = "mouseenter";
$rootScope.P2.PopoverTitle = "";
$rootScope.P2.PopoverPos = "top";
$rootScope.P2.PlaceHolder = "isikan password...";
$rootScope.P2.Class = "form-control input-lg ";
$rootScope.P2.Disabled = "";
$rootScope.P2.Required = "";
$rootScope.P2.ReadOnly = "";

$rootScope.LoginClient = {};
$rootScope.LoginClient.Status = 0;
$rootScope.LoginClient.StatusText = "";
$rootScope.LoginClient.Response = "";
$rootScope.LoginClient.Request = {};
$rootScope.LoginClient.Request.data = {};
$rootScope.LoginClient.Request.headers = {};
$rootScope.LoginClient.Request.url = "http://192.168.56.1/learnapi/inc/api.php";
$rootScope.LoginClient.Request.method = "POST";

$rootScope.Progressbar2 = {};
$rootScope.Progressbar2.Hidden = "true";
$rootScope.Progressbar2.Title = "";
$rootScope.Progressbar2.TooltipText = "";
$rootScope.Progressbar2.TooltipPos = "top";
$rootScope.Progressbar2.PopoverText = "";
$rootScope.Progressbar2.PopoverEvent = "mouseenter";
$rootScope.Progressbar2.PopoverTitle = "";
$rootScope.Progressbar2.PopoverPos = "top";
$rootScope.Progressbar2.Class = "progress-bar progress-bar-warning progress-bar-striped active ";
$rootScope.Progressbar2.Percentage = 100;

$rootScope.Image3 = {};
$rootScope.Image3.Hidden = "";
$rootScope.Image3.Image = "app/images/umm.png";
$rootScope.Image3.Class = "";
$rootScope.Image3.Title = "";
$rootScope.Image3.TooltipText = "";
$rootScope.Image3.TooltipPos = "top";
$rootScope.Image3.PopoverText = "";
$rootScope.Image3.PopoverEvent = "mouseenter";
$rootScope.Image3.PopoverTitle = "";
$rootScope.Image3.PopoverPos = "top";

$rootScope.Container1 = {};
$rootScope.Container1.Hidden = "";
$rootScope.Container1.Title = "";
$rootScope.Container1.TooltipText = "";
$rootScope.Container1.TooltipPos = "top";
$rootScope.Container1.PopoverText = "";
$rootScope.Container1.PopoverTitle = "";
$rootScope.Container1.PopoverEvent = "mouseenter";
$rootScope.Container1.PopoverPos = "top";
$rootScope.Container1.Class = "animated";

$rootScope.Menu1 = {};
$rootScope.Menu1.Hidden = "";
$rootScope.Menu1.Items = [];
$rootScope.Menu1.Items.push("<span class=\x22glyphicon glyphicon-info-sign\x22></span> Materi");
$rootScope.Menu1.Items.push("<span class=\x22glyphicon glyphicon-info-sign\x22></span> Tugas");
$rootScope.Menu1.Items.push("<span class=\x22glyphicon glyphicon-info-sign\x22></span> Penilaian Tugas ");
$rootScope.Menu1.Items.push("<span class=\x22glyphicon glyphicon-info-sign\x22></span> Logout");
$rootScope.Menu1.Class = "list-group ";

$rootScope.Image1 = {};
$rootScope.Image1.Hidden = "";
$rootScope.Image1.Image = "app/images/logo.png";
$rootScope.Image1.Class = "";
$rootScope.Image1.Title = "";
$rootScope.Image1.TooltipText = "";
$rootScope.Image1.TooltipPos = "top";
$rootScope.Image1.PopoverText = "";
$rootScope.Image1.PopoverEvent = "mouseenter";
$rootScope.Image1.PopoverTitle = "";
$rootScope.Image1.PopoverPos = "top";

$rootScope.HtmlContent1 = {};
$rootScope.HtmlContent1.Hidden = "";
$rootScope.HtmlContent1.Class = "";
$rootScope.HtmlContent1.Title = "";
$rootScope.HtmlContent1.TooltipText = "";
$rootScope.HtmlContent1.TooltipPos = "top";
$rootScope.HtmlContent1.PopoverText = "";
$rootScope.HtmlContent1.PopoverEvent = "mouseenter";
$rootScope.HtmlContent1.PopoverTitle = "";
$rootScope.HtmlContent1.PopoverPos = "top";

$rootScope.HtmlContent4 = {};
$rootScope.HtmlContent4.Hidden = "";
$rootScope.HtmlContent4.Class = "";
$rootScope.HtmlContent4.Title = "";
$rootScope.HtmlContent4.TooltipText = "";
$rootScope.HtmlContent4.TooltipPos = "top";
$rootScope.HtmlContent4.PopoverText = "";
$rootScope.HtmlContent4.PopoverEvent = "mouseenter";
$rootScope.HtmlContent4.PopoverTitle = "";
$rootScope.HtmlContent4.PopoverPos = "top";

$rootScope.htmlDosen = {};
$rootScope.htmlDosen.Hidden = "";
$rootScope.htmlDosen.Class = "";
$rootScope.htmlDosen.Title = "";
$rootScope.htmlDosen.TooltipText = "";
$rootScope.htmlDosen.TooltipPos = "top";
$rootScope.htmlDosen.PopoverText = "";
$rootScope.htmlDosen.PopoverEvent = "mouseenter";
$rootScope.htmlDosen.PopoverTitle = "";
$rootScope.htmlDosen.PopoverPos = "top";

$rootScope.htmlMenu = {};
$rootScope.htmlMenu.Hidden = "";
$rootScope.htmlMenu.Class = "";
$rootScope.htmlMenu.Title = "";
$rootScope.htmlMenu.TooltipText = "";
$rootScope.htmlMenu.TooltipPos = "top";
$rootScope.htmlMenu.PopoverText = "";
$rootScope.htmlMenu.PopoverEvent = "mouseenter";
$rootScope.htmlMenu.PopoverTitle = "";
$rootScope.htmlMenu.PopoverPos = "right";

$rootScope.Container2 = {};
$rootScope.Container2.Hidden = "";
$rootScope.Container2.Title = "";
$rootScope.Container2.TooltipText = "";
$rootScope.Container2.TooltipPos = "top";
$rootScope.Container2.PopoverText = "";
$rootScope.Container2.PopoverTitle = "";
$rootScope.Container2.PopoverEvent = "mouseenter";
$rootScope.Container2.PopoverPos = "top";
$rootScope.Container2.Class = "animated";

$rootScope.Menu2 = {};
$rootScope.Menu2.Hidden = "";
$rootScope.Menu2.Items = [];
$rootScope.Menu2.Items.push("<span class=\x22glyphicon glyphicon-info-sign\x22></span> Enroll");
$rootScope.Menu2.Items.push("<span class=\x22glyphicon glyphicon-info-sign\x22></span> Materi");
$rootScope.Menu2.Items.push("<span class=\x22glyphicon glyphicon-info-sign\x22></span> Tugas");
$rootScope.Menu2.Items.push("<span class=\x22glyphicon glyphicon-info-sign\x22></span> Nilai Tugas");
$rootScope.Menu2.Items.push("<span class=\x22glyphicon glyphicon-info-sign\x22></span> Logout");
$rootScope.Menu2.Class = "list-group ";

$rootScope.Image2 = {};
$rootScope.Image2.Hidden = "";
$rootScope.Image2.Image = "app/images/logo.png";
$rootScope.Image2.Class = "";
$rootScope.Image2.Title = "";
$rootScope.Image2.TooltipText = "";
$rootScope.Image2.TooltipPos = "top";
$rootScope.Image2.PopoverText = "";
$rootScope.Image2.PopoverEvent = "mouseenter";
$rootScope.Image2.PopoverTitle = "";
$rootScope.Image2.PopoverPos = "top";

$rootScope.HtmlContent21 = {};
$rootScope.HtmlContent21.Hidden = "";
$rootScope.HtmlContent21.Class = "";
$rootScope.HtmlContent21.Title = "";
$rootScope.HtmlContent21.TooltipText = "";
$rootScope.HtmlContent21.TooltipPos = "top";
$rootScope.HtmlContent21.PopoverText = "";
$rootScope.HtmlContent21.PopoverEvent = "mouseenter";
$rootScope.HtmlContent21.PopoverTitle = "";
$rootScope.HtmlContent21.PopoverPos = "top";

$rootScope.HtmlContent22 = {};
$rootScope.HtmlContent22.Hidden = "";
$rootScope.HtmlContent22.Class = "";
$rootScope.HtmlContent22.Title = "";
$rootScope.HtmlContent22.TooltipText = "";
$rootScope.HtmlContent22.TooltipPos = "top";
$rootScope.HtmlContent22.PopoverText = "";
$rootScope.HtmlContent22.PopoverEvent = "mouseenter";
$rootScope.HtmlContent22.PopoverTitle = "";
$rootScope.HtmlContent22.PopoverPos = "top";

$rootScope.ReportMateri = {};
$rootScope.ReportMateri.Hidden = "";
$rootScope.ReportMateri.Url = "";
$rootScope.ReportMateri.Loading = "Loading data materi...";
$rootScope.ReportMateri.Class = "";
$rootScope.ReportMateri.Order = "";
$rootScope.ReportMateri.Query = "";
$rootScope.ReportMateri.Record = null;
$rootScope.ReportMateri.Data = "";

$rootScope.FilterInput = {};
$rootScope.FilterInput.Hidden = "";
$rootScope.FilterInput.Value = "";
$rootScope.FilterInput.Title = "";
$rootScope.FilterInput.TabIndex = -1;
$rootScope.FilterInput.TooltipText = "";
$rootScope.FilterInput.TooltipPos = "top";
$rootScope.FilterInput.PopoverText = "";
$rootScope.FilterInput.PopoverEvent = "mouseenter";
$rootScope.FilterInput.PopoverTitle = "";
$rootScope.FilterInput.PopoverPos = "top";
$rootScope.FilterInput.PlaceHolder = "pencarian data";
$rootScope.FilterInput.Class = "form-control input-sm ";
$rootScope.FilterInput.Disabled = "";
$rootScope.FilterInput.Required = "";
$rootScope.FilterInput.ReadOnly = "";

$rootScope.NotesSpin = {};
$rootScope.NotesSpin.Hidden = "true";
$rootScope.NotesSpin.Class = "";
$rootScope.NotesSpin.Title = "";
$rootScope.NotesSpin.TooltipText = "";
$rootScope.NotesSpin.TooltipPos = "top";
$rootScope.NotesSpin.PopoverText = "";
$rootScope.NotesSpin.PopoverEvent = "mouseenter";
$rootScope.NotesSpin.PopoverTitle = "";
$rootScope.NotesSpin.PopoverPos = "top";

$rootScope.HtmlContent7 = {};
$rootScope.HtmlContent7.Hidden = "";
$rootScope.HtmlContent7.Class = "";
$rootScope.HtmlContent7.Title = "";
$rootScope.HtmlContent7.TooltipText = "";
$rootScope.HtmlContent7.TooltipPos = "top";
$rootScope.HtmlContent7.PopoverText = "";
$rootScope.HtmlContent7.PopoverEvent = "mouseenter";
$rootScope.HtmlContent7.PopoverTitle = "";
$rootScope.HtmlContent7.PopoverPos = "right";

$rootScope.menTambah = {};
$rootScope.menTambah.Hidden = "";
$rootScope.menTambah.Class = "";
$rootScope.menTambah.Title = "";
$rootScope.menTambah.TooltipText = "";
$rootScope.menTambah.TooltipPos = "top";
$rootScope.menTambah.PopoverText = "";
$rootScope.menTambah.PopoverEvent = "mouseenter";
$rootScope.menTambah.PopoverTitle = "";
$rootScope.menTambah.PopoverPos = "right";

$rootScope.menuBack = {};
$rootScope.menuBack.Hidden = "";
$rootScope.menuBack.Class = "";
$rootScope.menuBack.Title = "";
$rootScope.menuBack.TooltipText = "";
$rootScope.menuBack.TooltipPos = "top";
$rootScope.menuBack.PopoverText = "";
$rootScope.menuBack.PopoverEvent = "mouseenter";
$rootScope.menuBack.PopoverTitle = "";
$rootScope.menuBack.PopoverPos = "right";

$rootScope.MateriDosenList = {};
$rootScope.MateriDosenList.Status = 0;
$rootScope.MateriDosenList.StatusText = "";
$rootScope.MateriDosenList.Response = "";
$rootScope.MateriDosenList.Request = {};
$rootScope.MateriDosenList.Request.data = {};
$rootScope.MateriDosenList.Request.headers = {};
$rootScope.MateriDosenList.Request.url = "";
$rootScope.MateriDosenList.Request.method = "POST";

$rootScope.MateriDosenListLoader = {};
$rootScope.MateriDosenListLoader.Hidden = "true";
$rootScope.MateriDosenListLoader.Class = "";
$rootScope.MateriDosenListLoader.Title = "";
$rootScope.MateriDosenListLoader.TooltipText = "";
$rootScope.MateriDosenListLoader.TooltipPos = "top";
$rootScope.MateriDosenListLoader.PopoverText = "";
$rootScope.MateriDosenListLoader.PopoverEvent = "mouseenter";
$rootScope.MateriDosenListLoader.PopoverTitle = "";
$rootScope.MateriDosenListLoader.PopoverPos = "top";

$rootScope.MasterDosenHapus = {};
$rootScope.MasterDosenHapus.Status = 0;
$rootScope.MasterDosenHapus.StatusText = "";
$rootScope.MasterDosenHapus.Response = "";
$rootScope.MasterDosenHapus.Request = {};
$rootScope.MasterDosenHapus.Request.data = {};
$rootScope.MasterDosenHapus.Request.headers = {};
$rootScope.MasterDosenHapus.Request.url = "";
$rootScope.MasterDosenHapus.Request.method = "POST";

$rootScope.BtnSimpanMateriDosen = {};
$rootScope.BtnSimpanMateriDosen.Hidden = "";
$rootScope.BtnSimpanMateriDosen.Title = "";
$rootScope.BtnSimpanMateriDosen.TabIndex = 5;
$rootScope.BtnSimpanMateriDosen.TooltipText = "";
$rootScope.BtnSimpanMateriDosen.TooltipPos = "top";
$rootScope.BtnSimpanMateriDosen.PopoverText = "";
$rootScope.BtnSimpanMateriDosen.PopoverTitle = "";
$rootScope.BtnSimpanMateriDosen.PopoverEvent = "mouseenter";
$rootScope.BtnSimpanMateriDosen.PopoverPos = "top";
$rootScope.BtnSimpanMateriDosen.Badge = "";
$rootScope.BtnSimpanMateriDosen.Icon = "glyphicon glyphicon-floppy-disk";
$rootScope.BtnSimpanMateriDosen.Text = "Simpan";
$rootScope.BtnSimpanMateriDosen.Class = "btn btn-primary btn-lg ";
$rootScope.BtnSimpanMateriDosen.Disabled = "";

$rootScope.P_MateriDosenIsi = {};
$rootScope.P_MateriDosenIsi.Hidden = "";
$rootScope.P_MateriDosenIsi.Value = "";
$rootScope.P_MateriDosenIsi.Title = "";
$rootScope.P_MateriDosenIsi.TabIndex = 7;
$rootScope.P_MateriDosenIsi.TooltipText = "";
$rootScope.P_MateriDosenIsi.TooltipPos = "top";
$rootScope.P_MateriDosenIsi.PopoverText = "";
$rootScope.P_MateriDosenIsi.PopoverEvent = "mouseenter";
$rootScope.P_MateriDosenIsi.PopoverTitle = "";
$rootScope.P_MateriDosenIsi.PopoverPos = "top";
$rootScope.P_MateriDosenIsi.PlaceHolder = "isikan teks materi...";
$rootScope.P_MateriDosenIsi.Class = "form-control input-sm ";
$rootScope.P_MateriDosenIsi.Disabled = "";
$rootScope.P_MateriDosenIsi.Required = "";
$rootScope.P_MateriDosenIsi.ReadOnly = "";

$rootScope.P_MateriDosenBerkas = {};
$rootScope.P_MateriDosenBerkas.Hidden = "";
$rootScope.P_MateriDosenBerkas.Url = "";
$rootScope.P_MateriDosenBerkas.Data = "";
$rootScope.P_MateriDosenBerkas.Value = null;
$rootScope.P_MateriDosenBerkas.Title = "";
$rootScope.P_MateriDosenBerkas.Accept = "";
$rootScope.P_MateriDosenBerkas.TabIndex = 3;
$rootScope.P_MateriDosenBerkas.TooltipText = "";
$rootScope.P_MateriDosenBerkas.TooltipPos = "top";
$rootScope.P_MateriDosenBerkas.PopoverText = "";
$rootScope.P_MateriDosenBerkas.PopoverEvent = "mouseenter";
$rootScope.P_MateriDosenBerkas.PopoverTitle = "";
$rootScope.P_MateriDosenBerkas.PopoverPos = "top";
$rootScope.P_MateriDosenBerkas.Class = "form-control input-sm ";
$rootScope.P_MateriDosenBerkas.Disabled = "";
$rootScope.P_MateriDosenBerkas.Required = "";

$rootScope.MateriDosenProgress = {};
$rootScope.MateriDosenProgress.Hidden = "true";
$rootScope.MateriDosenProgress.Title = "";
$rootScope.MateriDosenProgress.TooltipText = "";
$rootScope.MateriDosenProgress.TooltipPos = "top";
$rootScope.MateriDosenProgress.PopoverText = "";
$rootScope.MateriDosenProgress.PopoverEvent = "mouseenter";
$rootScope.MateriDosenProgress.PopoverTitle = "";
$rootScope.MateriDosenProgress.PopoverPos = "top";
$rootScope.MateriDosenProgress.Class = "progress-bar progress-bar-info progress-bar-striped active ";
$rootScope.MateriDosenProgress.Percentage = 100;

$rootScope.Label3 = {};
$rootScope.Label3.Hidden = "";
$rootScope.Label3.Class = "";
$rootScope.Label3.Text = "Matakuliah";
$rootScope.Label3.Input = "Textarea3";
$rootScope.Label3.Title = "";
$rootScope.Label3.TooltipText = "";
$rootScope.Label3.TooltipPos = "top";
$rootScope.Label3.PopoverText = "";
$rootScope.Label3.PopoverEvent = "mouseenter";
$rootScope.Label3.PopoverTitle = "";
$rootScope.Label3.PopoverPos = "top";

$rootScope.P_MateriDosenMatkul = {};
$rootScope.P_MateriDosenMatkul.Hidden = "";
$rootScope.P_MateriDosenMatkul.Items = [];
$rootScope.P_MateriDosenMatkul.ItemIndex = 0;
$rootScope.P_MateriDosenMatkul.Title = "";
$rootScope.P_MateriDosenMatkul.TabIndex = 6;
$rootScope.P_MateriDosenMatkul.TooltipText = "";
$rootScope.P_MateriDosenMatkul.TooltipPos = "top";
$rootScope.P_MateriDosenMatkul.PopoverText = "";
$rootScope.P_MateriDosenMatkul.PopoverEvent = "mouseenter";
$rootScope.P_MateriDosenMatkul.PopoverTitle = "";
$rootScope.P_MateriDosenMatkul.PopoverPos = "top";
$rootScope.P_MateriDosenMatkul.Class = "form-control input-sm ";
$rootScope.P_MateriDosenMatkul.Disabled = "";
$rootScope.P_MateriDosenMatkul.Required = "";

$rootScope.MatkulClient = {};
$rootScope.MatkulClient.Status = 0;
$rootScope.MatkulClient.StatusText = "";
$rootScope.MatkulClient.Response = "";
$rootScope.MatkulClient.Request = {};
$rootScope.MatkulClient.Request.data = {};
$rootScope.MatkulClient.Request.headers = {};
$rootScope.MatkulClient.Request.url = "";
$rootScope.MatkulClient.Request.method = "POST";

$rootScope.MatkulLoader = {};
$rootScope.MatkulLoader.Hidden = "true";
$rootScope.MatkulLoader.Class = "";
$rootScope.MatkulLoader.Title = "";
$rootScope.MatkulLoader.TooltipText = "";
$rootScope.MatkulLoader.TooltipPos = "top";
$rootScope.MatkulLoader.PopoverText = "";
$rootScope.MatkulLoader.PopoverEvent = "mouseenter";
$rootScope.MatkulLoader.PopoverTitle = "";
$rootScope.MatkulLoader.PopoverPos = "top";

$rootScope.btnBatalMateriDosen = {};
$rootScope.btnBatalMateriDosen.Hidden = "";
$rootScope.btnBatalMateriDosen.Title = "";
$rootScope.btnBatalMateriDosen.TabIndex = 4;
$rootScope.btnBatalMateriDosen.TooltipText = "";
$rootScope.btnBatalMateriDosen.TooltipPos = "top";
$rootScope.btnBatalMateriDosen.PopoverText = "";
$rootScope.btnBatalMateriDosen.PopoverTitle = "";
$rootScope.btnBatalMateriDosen.PopoverEvent = "mouseenter";
$rootScope.btnBatalMateriDosen.PopoverPos = "top";
$rootScope.btnBatalMateriDosen.Badge = "";
$rootScope.btnBatalMateriDosen.Icon = "glyphicon glyphicon-repeat";
$rootScope.btnBatalMateriDosen.Text = "Batal";
$rootScope.btnBatalMateriDosen.Class = "btn btn-danger btn-lg ";
$rootScope.btnBatalMateriDosen.Disabled = "";

$rootScope.Label5 = {};
$rootScope.Label5.Hidden = "";
$rootScope.Label5.Class = "";
$rootScope.Label5.Text = "Isi Materi";
$rootScope.Label5.Input = "Textarea3";
$rootScope.Label5.Title = "";
$rootScope.Label5.TooltipText = "";
$rootScope.Label5.TooltipPos = "top";
$rootScope.Label5.PopoverText = "";
$rootScope.Label5.PopoverEvent = "mouseenter";
$rootScope.Label5.PopoverTitle = "";
$rootScope.Label5.PopoverPos = "top";

$rootScope.Label6 = {};
$rootScope.Label6.Hidden = "";
$rootScope.Label6.Class = "";
$rootScope.Label6.Text = "Berkas";
$rootScope.Label6.Input = "Textarea3";
$rootScope.Label6.Title = "";
$rootScope.Label6.TooltipText = "";
$rootScope.Label6.TooltipPos = "top";
$rootScope.Label6.PopoverText = "";
$rootScope.Label6.PopoverEvent = "mouseenter";
$rootScope.Label6.PopoverTitle = "";
$rootScope.Label6.PopoverPos = "top";

$rootScope.MatkulSimpan = {};
$rootScope.MatkulSimpan.Status = 0;
$rootScope.MatkulSimpan.StatusText = "";
$rootScope.MatkulSimpan.Response = "";
$rootScope.MatkulSimpan.Request = {};
$rootScope.MatkulSimpan.Request.data = {};
$rootScope.MatkulSimpan.Request.headers = {};
$rootScope.MatkulSimpan.Request.url = "";
$rootScope.MatkulSimpan.Request.method = "POST";

$rootScope.ReporteEnroll = {};
$rootScope.ReporteEnroll.Hidden = "";
$rootScope.ReporteEnroll.Url = "";
$rootScope.ReporteEnroll.Loading = "Loading data...";
$rootScope.ReporteEnroll.Class = "";
$rootScope.ReporteEnroll.Order = "";
$rootScope.ReporteEnroll.Query = "";
$rootScope.ReporteEnroll.Record = null;
$rootScope.ReporteEnroll.Data = "";

$rootScope.Input8 = {};
$rootScope.Input8.Hidden = "";
$rootScope.Input8.Value = "";
$rootScope.Input8.Title = "";
$rootScope.Input8.TabIndex = -1;
$rootScope.Input8.TooltipText = "";
$rootScope.Input8.TooltipPos = "top";
$rootScope.Input8.PopoverText = "";
$rootScope.Input8.PopoverEvent = "mouseenter";
$rootScope.Input8.PopoverTitle = "";
$rootScope.Input8.PopoverPos = "top";
$rootScope.Input8.PlaceHolder = "pencarian data";
$rootScope.Input8.Class = "form-control input-sm ";
$rootScope.Input8.Disabled = "";
$rootScope.Input8.Required = "";
$rootScope.Input8.ReadOnly = "";

$rootScope.HtmlContent24 = {};
$rootScope.HtmlContent24.Hidden = "true";
$rootScope.HtmlContent24.Class = "";
$rootScope.HtmlContent24.Title = "";
$rootScope.HtmlContent24.TooltipText = "";
$rootScope.HtmlContent24.TooltipPos = "top";
$rootScope.HtmlContent24.PopoverText = "";
$rootScope.HtmlContent24.PopoverEvent = "mouseenter";
$rootScope.HtmlContent24.PopoverTitle = "";
$rootScope.HtmlContent24.PopoverPos = "top";

$rootScope.HtmlContent26 = {};
$rootScope.HtmlContent26.Hidden = "";
$rootScope.HtmlContent26.Class = "";
$rootScope.HtmlContent26.Title = "";
$rootScope.HtmlContent26.TooltipText = "";
$rootScope.HtmlContent26.TooltipPos = "top";
$rootScope.HtmlContent26.PopoverText = "";
$rootScope.HtmlContent26.PopoverEvent = "mouseenter";
$rootScope.HtmlContent26.PopoverTitle = "";
$rootScope.HtmlContent26.PopoverPos = "right";

$rootScope.HtmlContent28 = {};
$rootScope.HtmlContent28.Hidden = "";
$rootScope.HtmlContent28.Class = "";
$rootScope.HtmlContent28.Title = "";
$rootScope.HtmlContent28.TooltipText = "";
$rootScope.HtmlContent28.TooltipPos = "top";
$rootScope.HtmlContent28.PopoverText = "";
$rootScope.HtmlContent28.PopoverEvent = "mouseenter";
$rootScope.HtmlContent28.PopoverTitle = "";
$rootScope.HtmlContent28.PopoverPos = "right";

$rootScope.HtmlContent29 = {};
$rootScope.HtmlContent29.Hidden = "";
$rootScope.HtmlContent29.Class = "";
$rootScope.HtmlContent29.Title = "";
$rootScope.HtmlContent29.TooltipText = "";
$rootScope.HtmlContent29.TooltipPos = "top";
$rootScope.HtmlContent29.PopoverText = "";
$rootScope.HtmlContent29.PopoverEvent = "mouseenter";
$rootScope.HtmlContent29.PopoverTitle = "";
$rootScope.HtmlContent29.PopoverPos = "right";

$rootScope.ReportEnrollLoader = {};
$rootScope.ReportEnrollLoader.Hidden = "true";
$rootScope.ReportEnrollLoader.Class = "";
$rootScope.ReportEnrollLoader.Title = "";
$rootScope.ReportEnrollLoader.TooltipText = "";
$rootScope.ReportEnrollLoader.TooltipPos = "top";
$rootScope.ReportEnrollLoader.PopoverText = "";
$rootScope.ReportEnrollLoader.PopoverEvent = "mouseenter";
$rootScope.ReportEnrollLoader.PopoverTitle = "";
$rootScope.ReportEnrollLoader.PopoverPos = "top";

$rootScope.EnrollClient = {};
$rootScope.EnrollClient.Status = 0;
$rootScope.EnrollClient.StatusText = "";
$rootScope.EnrollClient.Response = "";
$rootScope.EnrollClient.Request = {};
$rootScope.EnrollClient.Request.data = {};
$rootScope.EnrollClient.Request.headers = {};
$rootScope.EnrollClient.Request.url = "";
$rootScope.EnrollClient.Request.method = "POST";

$rootScope.MatkulEnrollSimpan = {};
$rootScope.MatkulEnrollSimpan.Status = 0;
$rootScope.MatkulEnrollSimpan.StatusText = "";
$rootScope.MatkulEnrollSimpan.Response = "";
$rootScope.MatkulEnrollSimpan.Request = {};
$rootScope.MatkulEnrollSimpan.Request.data = {};
$rootScope.MatkulEnrollSimpan.Request.headers = {};
$rootScope.MatkulEnrollSimpan.Request.url = "";
$rootScope.MatkulEnrollSimpan.Request.method = "POST";

$rootScope.EnrollHapus = {};
$rootScope.EnrollHapus.Status = 0;
$rootScope.EnrollHapus.StatusText = "";
$rootScope.EnrollHapus.Response = "";
$rootScope.EnrollHapus.Request = {};
$rootScope.EnrollHapus.Request.data = {};
$rootScope.EnrollHapus.Request.headers = {};
$rootScope.EnrollHapus.Request.url = "";
$rootScope.EnrollHapus.Request.method = "POST";

$rootScope.HtmlContent5 = {};
$rootScope.HtmlContent5.Hidden = "";
$rootScope.HtmlContent5.Class = "";
$rootScope.HtmlContent5.Title = "";
$rootScope.HtmlContent5.TooltipText = "";
$rootScope.HtmlContent5.TooltipPos = "top";
$rootScope.HtmlContent5.PopoverText = "";
$rootScope.HtmlContent5.PopoverEvent = "mouseenter";
$rootScope.HtmlContent5.PopoverTitle = "";
$rootScope.HtmlContent5.PopoverPos = "top";

$rootScope.Button4 = {};
$rootScope.Button4.Hidden = "";
$rootScope.Button4.Title = "";
$rootScope.Button4.TabIndex = -1;
$rootScope.Button4.TooltipText = "";
$rootScope.Button4.TooltipPos = "top";
$rootScope.Button4.PopoverText = "";
$rootScope.Button4.PopoverTitle = "";
$rootScope.Button4.PopoverEvent = "mouseenter";
$rootScope.Button4.PopoverPos = "top";
$rootScope.Button4.Badge = "";
$rootScope.Button4.Icon = "glyphicon glyphicon-hdd";
$rootScope.Button4.Text = "Download Materi";
$rootScope.Button4.Class = "btn btn-primary btn-md ";
$rootScope.Button4.Disabled = "";

$rootScope.HtmlContent6 = {};
$rootScope.HtmlContent6.Hidden = "";
$rootScope.HtmlContent6.Class = "";
$rootScope.HtmlContent6.Title = "";
$rootScope.HtmlContent6.TooltipText = "";
$rootScope.HtmlContent6.TooltipPos = "top";
$rootScope.HtmlContent6.PopoverText = "";
$rootScope.HtmlContent6.PopoverEvent = "mouseenter";
$rootScope.HtmlContent6.PopoverTitle = "";
$rootScope.HtmlContent6.PopoverPos = "top";

$rootScope.HtmlContent8 = {};
$rootScope.HtmlContent8.Hidden = "";
$rootScope.HtmlContent8.Class = "";
$rootScope.HtmlContent8.Title = "";
$rootScope.HtmlContent8.TooltipText = "";
$rootScope.HtmlContent8.TooltipPos = "top";
$rootScope.HtmlContent8.PopoverText = "";
$rootScope.HtmlContent8.PopoverEvent = "mouseenter";
$rootScope.HtmlContent8.PopoverTitle = "";
$rootScope.HtmlContent8.PopoverPos = "top";

$rootScope.Button5 = {};
$rootScope.Button5.Hidden = "";
$rootScope.Button5.Title = "";
$rootScope.Button5.TabIndex = -1;
$rootScope.Button5.TooltipText = "";
$rootScope.Button5.TooltipPos = "top";
$rootScope.Button5.PopoverText = "";
$rootScope.Button5.PopoverTitle = "";
$rootScope.Button5.PopoverEvent = "mouseenter";
$rootScope.Button5.PopoverPos = "top";
$rootScope.Button5.Badge = "";
$rootScope.Button5.Icon = "glyphicon glyphicon-pencil";
$rootScope.Button5.Text = "Edit Materi";
$rootScope.Button5.Class = "btn btn-warning btn-lg ";
$rootScope.Button5.Disabled = "";

$rootScope.Button6 = {};
$rootScope.Button6.Hidden = "";
$rootScope.Button6.Title = "";
$rootScope.Button6.TabIndex = -1;
$rootScope.Button6.TooltipText = "";
$rootScope.Button6.TooltipPos = "top";
$rootScope.Button6.PopoverText = "";
$rootScope.Button6.PopoverTitle = "";
$rootScope.Button6.PopoverEvent = "mouseenter";
$rootScope.Button6.PopoverPos = "top";
$rootScope.Button6.Badge = "";
$rootScope.Button6.Icon = "glyphicon glyphicon-trash";
$rootScope.Button6.Text = "Hapus Materi";
$rootScope.Button6.Class = "btn btn-danger btn-lg ";
$rootScope.Button6.Disabled = "";

$rootScope.Button7 = {};
$rootScope.Button7.Hidden = "";
$rootScope.Button7.Title = "";
$rootScope.Button7.TabIndex = -1;
$rootScope.Button7.TooltipText = "";
$rootScope.Button7.TooltipPos = "top";
$rootScope.Button7.PopoverText = "";
$rootScope.Button7.PopoverTitle = "";
$rootScope.Button7.PopoverEvent = "mouseenter";
$rootScope.Button7.PopoverPos = "top";
$rootScope.Button7.Badge = "";
$rootScope.Button7.Icon = "glyphicon glyphicon-hdd";
$rootScope.Button7.Text = "Detail Materi";
$rootScope.Button7.Class = "btn btn-primary btn-lg ";
$rootScope.Button7.Disabled = "";

$rootScope.Button8 = {};
$rootScope.Button8.Hidden = "";
$rootScope.Button8.Title = "";
$rootScope.Button8.TabIndex = -1;
$rootScope.Button8.TooltipText = "";
$rootScope.Button8.TooltipPos = "top";
$rootScope.Button8.PopoverText = "";
$rootScope.Button8.PopoverTitle = "";
$rootScope.Button8.PopoverEvent = "mouseenter";
$rootScope.Button8.PopoverPos = "top";
$rootScope.Button8.Badge = "";
$rootScope.Button8.Icon = "glyphicon glyphicon-log-in";
$rootScope.Button8.Text = "Tambah Tugas";
$rootScope.Button8.Class = "btn btn-success btn-lg ";
$rootScope.Button8.Disabled = "";

$rootScope.HtmlContent9 = {};
$rootScope.HtmlContent9.Hidden = "";
$rootScope.HtmlContent9.Class = "";
$rootScope.HtmlContent9.Title = "";
$rootScope.HtmlContent9.TooltipText = "";
$rootScope.HtmlContent9.TooltipPos = "top";
$rootScope.HtmlContent9.PopoverText = "";
$rootScope.HtmlContent9.PopoverEvent = "mouseenter";
$rootScope.HtmlContent9.PopoverTitle = "";
$rootScope.HtmlContent9.PopoverPos = "top";

$rootScope.HtmlContent16 = {};
$rootScope.HtmlContent16.Hidden = "";
$rootScope.HtmlContent16.Class = "";
$rootScope.HtmlContent16.Title = "";
$rootScope.HtmlContent16.TooltipText = "";
$rootScope.HtmlContent16.TooltipPos = "top";
$rootScope.HtmlContent16.PopoverText = "";
$rootScope.HtmlContent16.PopoverEvent = "mouseenter";
$rootScope.HtmlContent16.PopoverTitle = "";
$rootScope.HtmlContent16.PopoverPos = "top";

$rootScope.Button1 = {};
$rootScope.Button1.Hidden = "";
$rootScope.Button1.Title = "";
$rootScope.Button1.TabIndex = -1;
$rootScope.Button1.TooltipText = "";
$rootScope.Button1.TooltipPos = "top";
$rootScope.Button1.PopoverText = "";
$rootScope.Button1.PopoverTitle = "";
$rootScope.Button1.PopoverEvent = "mouseenter";
$rootScope.Button1.PopoverPos = "top";
$rootScope.Button1.Badge = "";
$rootScope.Button1.Icon = "glyphicon glyphicon-pencil";
$rootScope.Button1.Text = "Edit Tugas";
$rootScope.Button1.Class = "btn btn-warning btn-lg ";
$rootScope.Button1.Disabled = "";

$rootScope.Button9 = {};
$rootScope.Button9.Hidden = "";
$rootScope.Button9.Title = "";
$rootScope.Button9.TabIndex = -1;
$rootScope.Button9.TooltipText = "";
$rootScope.Button9.TooltipPos = "top";
$rootScope.Button9.PopoverText = "";
$rootScope.Button9.PopoverTitle = "";
$rootScope.Button9.PopoverEvent = "mouseenter";
$rootScope.Button9.PopoverPos = "top";
$rootScope.Button9.Badge = "";
$rootScope.Button9.Icon = "glyphicon glyphicon-trash";
$rootScope.Button9.Text = "Hapus Tugas";
$rootScope.Button9.Class = "btn btn-danger btn-lg ";
$rootScope.Button9.Disabled = "";

$rootScope.Button10 = {};
$rootScope.Button10.Hidden = "";
$rootScope.Button10.Title = "";
$rootScope.Button10.TabIndex = -1;
$rootScope.Button10.TooltipText = "";
$rootScope.Button10.TooltipPos = "top";
$rootScope.Button10.PopoverText = "";
$rootScope.Button10.PopoverTitle = "";
$rootScope.Button10.PopoverEvent = "mouseenter";
$rootScope.Button10.PopoverPos = "top";
$rootScope.Button10.Badge = "";
$rootScope.Button10.Icon = "glyphicon glyphicon-hdd";
$rootScope.Button10.Text = "Detail Tugas";
$rootScope.Button10.Class = "btn btn-primary btn-lg ";
$rootScope.Button10.Disabled = "";

$rootScope.HtmlContent17 = {};
$rootScope.HtmlContent17.Hidden = "";
$rootScope.HtmlContent17.Class = "";
$rootScope.HtmlContent17.Title = "";
$rootScope.HtmlContent17.TooltipText = "";
$rootScope.HtmlContent17.TooltipPos = "top";
$rootScope.HtmlContent17.PopoverText = "";
$rootScope.HtmlContent17.PopoverEvent = "mouseenter";
$rootScope.HtmlContent17.PopoverTitle = "";
$rootScope.HtmlContent17.PopoverPos = "top";

$rootScope.HtmlContent31 = {};
$rootScope.HtmlContent31.Hidden = "";
$rootScope.HtmlContent31.Class = "";
$rootScope.HtmlContent31.Title = "";
$rootScope.HtmlContent31.TooltipText = "";
$rootScope.HtmlContent31.TooltipPos = "top";
$rootScope.HtmlContent31.PopoverText = "";
$rootScope.HtmlContent31.PopoverEvent = "mouseenter";
$rootScope.HtmlContent31.PopoverTitle = "";
$rootScope.HtmlContent31.PopoverPos = "top";

$rootScope.Button12 = {};
$rootScope.Button12.Hidden = "";
$rootScope.Button12.Title = "";
$rootScope.Button12.TabIndex = -1;
$rootScope.Button12.TooltipText = "";
$rootScope.Button12.TooltipPos = "top";
$rootScope.Button12.PopoverText = "";
$rootScope.Button12.PopoverTitle = "";
$rootScope.Button12.PopoverEvent = "mouseenter";
$rootScope.Button12.PopoverPos = "top";
$rootScope.Button12.Badge = "";
$rootScope.Button12.Icon = "glyphicon glyphicon-pencil";
$rootScope.Button12.Text = "Lihat Materi";
$rootScope.Button12.Class = "btn btn-warning btn-lg ";
$rootScope.Button12.Disabled = "";

$rootScope.Button13 = {};
$rootScope.Button13.Hidden = "";
$rootScope.Button13.Title = "";
$rootScope.Button13.TabIndex = -1;
$rootScope.Button13.TooltipText = "";
$rootScope.Button13.TooltipPos = "top";
$rootScope.Button13.PopoverText = "";
$rootScope.Button13.PopoverTitle = "";
$rootScope.Button13.PopoverEvent = "mouseenter";
$rootScope.Button13.PopoverPos = "top";
$rootScope.Button13.Badge = "";
$rootScope.Button13.Icon = "glyphicon glyphicon-trash";
$rootScope.Button13.Text = "Hapus Enroll";
$rootScope.Button13.Class = "btn btn-danger btn-lg ";
$rootScope.Button13.Disabled = "";

$rootScope.HtmlContent33 = {};
$rootScope.HtmlContent33.Hidden = "";
$rootScope.HtmlContent33.Class = "";
$rootScope.HtmlContent33.Title = "";
$rootScope.HtmlContent33.TooltipText = "";
$rootScope.HtmlContent33.TooltipPos = "top";
$rootScope.HtmlContent33.PopoverText = "";
$rootScope.HtmlContent33.PopoverEvent = "mouseenter";
$rootScope.HtmlContent33.PopoverTitle = "";
$rootScope.HtmlContent33.PopoverPos = "top";

$rootScope.btnSimpanTugasDosen = {};
$rootScope.btnSimpanTugasDosen.Hidden = "";
$rootScope.btnSimpanTugasDosen.Title = "";
$rootScope.btnSimpanTugasDosen.TabIndex = 5;
$rootScope.btnSimpanTugasDosen.TooltipText = "";
$rootScope.btnSimpanTugasDosen.TooltipPos = "top";
$rootScope.btnSimpanTugasDosen.PopoverText = "";
$rootScope.btnSimpanTugasDosen.PopoverTitle = "";
$rootScope.btnSimpanTugasDosen.PopoverEvent = "mouseenter";
$rootScope.btnSimpanTugasDosen.PopoverPos = "top";
$rootScope.btnSimpanTugasDosen.Badge = "";
$rootScope.btnSimpanTugasDosen.Icon = "glyphicon glyphicon-floppy-disk";
$rootScope.btnSimpanTugasDosen.Text = "Simpan";
$rootScope.btnSimpanTugasDosen.Class = "btn btn-primary btn-lg ";
$rootScope.btnSimpanTugasDosen.Disabled = "";

$rootScope.DosenTugasTambahPrgress = {};
$rootScope.DosenTugasTambahPrgress.Hidden = "true";
$rootScope.DosenTugasTambahPrgress.Title = "";
$rootScope.DosenTugasTambahPrgress.TooltipText = "";
$rootScope.DosenTugasTambahPrgress.TooltipPos = "top";
$rootScope.DosenTugasTambahPrgress.PopoverText = "";
$rootScope.DosenTugasTambahPrgress.PopoverEvent = "mouseenter";
$rootScope.DosenTugasTambahPrgress.PopoverTitle = "";
$rootScope.DosenTugasTambahPrgress.PopoverPos = "top";
$rootScope.DosenTugasTambahPrgress.Class = "progress-bar progress-bar-info progress-bar-striped active ";
$rootScope.DosenTugasTambahPrgress.Percentage = 100;

$rootScope.Button3 = {};
$rootScope.Button3.Hidden = "";
$rootScope.Button3.Title = "";
$rootScope.Button3.TabIndex = 4;
$rootScope.Button3.TooltipText = "";
$rootScope.Button3.TooltipPos = "top";
$rootScope.Button3.PopoverText = "";
$rootScope.Button3.PopoverTitle = "";
$rootScope.Button3.PopoverEvent = "mouseenter";
$rootScope.Button3.PopoverPos = "top";
$rootScope.Button3.Badge = "";
$rootScope.Button3.Icon = "glyphicon glyphicon-repeat";
$rootScope.Button3.Text = "Batal";
$rootScope.Button3.Class = "btn btn-danger btn-lg ";
$rootScope.Button3.Disabled = "";

$rootScope.Label8 = {};
$rootScope.Label8.Hidden = "";
$rootScope.Label8.Class = "";
$rootScope.Label8.Text = "Isi Tugas";
$rootScope.Label8.Input = "Textarea3";
$rootScope.Label8.Title = "";
$rootScope.Label8.TooltipText = "";
$rootScope.Label8.TooltipPos = "top";
$rootScope.Label8.PopoverText = "";
$rootScope.Label8.PopoverEvent = "mouseenter";
$rootScope.Label8.PopoverTitle = "";
$rootScope.Label8.PopoverPos = "top";

$rootScope.Label9 = {};
$rootScope.Label9.Hidden = "";
$rootScope.Label9.Class = "";
$rootScope.Label9.Text = "Berkas";
$rootScope.Label9.Input = "Textarea3";
$rootScope.Label9.Title = "";
$rootScope.Label9.TooltipText = "";
$rootScope.Label9.TooltipPos = "top";
$rootScope.Label9.PopoverText = "";
$rootScope.Label9.PopoverEvent = "mouseenter";
$rootScope.Label9.PopoverTitle = "";
$rootScope.Label9.PopoverPos = "top";

$rootScope.P_IsiTugasDosen = {};
$rootScope.P_IsiTugasDosen.Hidden = "";
$rootScope.P_IsiTugasDosen.Value = "";
$rootScope.P_IsiTugasDosen.Title = "";
$rootScope.P_IsiTugasDosen.TabIndex = 7;
$rootScope.P_IsiTugasDosen.TooltipText = "";
$rootScope.P_IsiTugasDosen.TooltipPos = "top";
$rootScope.P_IsiTugasDosen.PopoverText = "";
$rootScope.P_IsiTugasDosen.PopoverEvent = "mouseenter";
$rootScope.P_IsiTugasDosen.PopoverTitle = "";
$rootScope.P_IsiTugasDosen.PopoverPos = "top";
$rootScope.P_IsiTugasDosen.PlaceHolder = "isikan teks materi...";
$rootScope.P_IsiTugasDosen.Class = "form-control input-sm ";
$rootScope.P_IsiTugasDosen.Disabled = "";
$rootScope.P_IsiTugasDosen.Required = "";
$rootScope.P_IsiTugasDosen.ReadOnly = "";

$rootScope.P_BerkasTugasDosen = {};
$rootScope.P_BerkasTugasDosen.Hidden = "";
$rootScope.P_BerkasTugasDosen.Url = "";
$rootScope.P_BerkasTugasDosen.Data = "";
$rootScope.P_BerkasTugasDosen.Value = null;
$rootScope.P_BerkasTugasDosen.Title = "";
$rootScope.P_BerkasTugasDosen.Accept = "";
$rootScope.P_BerkasTugasDosen.TabIndex = 3;
$rootScope.P_BerkasTugasDosen.TooltipText = "";
$rootScope.P_BerkasTugasDosen.TooltipPos = "top";
$rootScope.P_BerkasTugasDosen.PopoverText = "";
$rootScope.P_BerkasTugasDosen.PopoverEvent = "mouseenter";
$rootScope.P_BerkasTugasDosen.PopoverTitle = "";
$rootScope.P_BerkasTugasDosen.PopoverPos = "top";
$rootScope.P_BerkasTugasDosen.Class = "form-control input-sm ";
$rootScope.P_BerkasTugasDosen.Disabled = "";
$rootScope.P_BerkasTugasDosen.Required = "";

$rootScope.TugasClientSimpan = {};
$rootScope.TugasClientSimpan.Status = 0;
$rootScope.TugasClientSimpan.StatusText = "";
$rootScope.TugasClientSimpan.Response = "";
$rootScope.TugasClientSimpan.Request = {};
$rootScope.TugasClientSimpan.Request.data = {};
$rootScope.TugasClientSimpan.Request.headers = {};
$rootScope.TugasClientSimpan.Request.url = "";
$rootScope.TugasClientSimpan.Request.method = "POST";

$rootScope.KodeMateri = {};
$rootScope.KodeMateri.Hidden = "true";
$rootScope.KodeMateri.Value = "Input6";
$rootScope.KodeMateri.Title = "";
$rootScope.KodeMateri.TabIndex = -1;
$rootScope.KodeMateri.TooltipText = "";
$rootScope.KodeMateri.TooltipPos = "top";
$rootScope.KodeMateri.PopoverText = "";
$rootScope.KodeMateri.PopoverEvent = "mouseenter";
$rootScope.KodeMateri.PopoverTitle = "";
$rootScope.KodeMateri.PopoverPos = "top";
$rootScope.KodeMateri.PlaceHolder = "";
$rootScope.KodeMateri.Class = "form-control input-sm ";
$rootScope.KodeMateri.Disabled = "";
$rootScope.KodeMateri.Required = "";
$rootScope.KodeMateri.ReadOnly = "";

$rootScope.ReportTugas = {};
$rootScope.ReportTugas.Hidden = "";
$rootScope.ReportTugas.Url = "";
$rootScope.ReportTugas.Loading = "Loading data tugas...";
$rootScope.ReportTugas.Class = "";
$rootScope.ReportTugas.Order = "";
$rootScope.ReportTugas.Query = "";
$rootScope.ReportTugas.Record = null;
$rootScope.ReportTugas.Data = "";

$rootScope.Input1 = {};
$rootScope.Input1.Hidden = "";
$rootScope.Input1.Value = "";
$rootScope.Input1.Title = "";
$rootScope.Input1.TabIndex = -1;
$rootScope.Input1.TooltipText = "";
$rootScope.Input1.TooltipPos = "top";
$rootScope.Input1.PopoverText = "";
$rootScope.Input1.PopoverEvent = "mouseenter";
$rootScope.Input1.PopoverTitle = "";
$rootScope.Input1.PopoverPos = "top";
$rootScope.Input1.PlaceHolder = "pencarian data";
$rootScope.Input1.Class = "form-control input-sm ";
$rootScope.Input1.Disabled = "";
$rootScope.Input1.Required = "";
$rootScope.Input1.ReadOnly = "";

$rootScope.HtmlContent10 = {};
$rootScope.HtmlContent10.Hidden = "true";
$rootScope.HtmlContent10.Class = "";
$rootScope.HtmlContent10.Title = "";
$rootScope.HtmlContent10.TooltipText = "";
$rootScope.HtmlContent10.TooltipPos = "top";
$rootScope.HtmlContent10.PopoverText = "";
$rootScope.HtmlContent10.PopoverEvent = "mouseenter";
$rootScope.HtmlContent10.PopoverTitle = "";
$rootScope.HtmlContent10.PopoverPos = "top";

$rootScope.HtmlContent11 = {};
$rootScope.HtmlContent11.Hidden = "";
$rootScope.HtmlContent11.Class = "";
$rootScope.HtmlContent11.Title = "";
$rootScope.HtmlContent11.TooltipText = "";
$rootScope.HtmlContent11.TooltipPos = "top";
$rootScope.HtmlContent11.PopoverText = "";
$rootScope.HtmlContent11.PopoverEvent = "mouseenter";
$rootScope.HtmlContent11.PopoverTitle = "";
$rootScope.HtmlContent11.PopoverPos = "right";

$rootScope.HtmlContent12 = {};
$rootScope.HtmlContent12.Hidden = "";
$rootScope.HtmlContent12.Class = "";
$rootScope.HtmlContent12.Title = "";
$rootScope.HtmlContent12.TooltipText = "";
$rootScope.HtmlContent12.TooltipPos = "top";
$rootScope.HtmlContent12.PopoverText = "";
$rootScope.HtmlContent12.PopoverEvent = "mouseenter";
$rootScope.HtmlContent12.PopoverTitle = "";
$rootScope.HtmlContent12.PopoverPos = "right";

$rootScope.HtmlContent13 = {};
$rootScope.HtmlContent13.Hidden = "";
$rootScope.HtmlContent13.Class = "";
$rootScope.HtmlContent13.Title = "";
$rootScope.HtmlContent13.TooltipText = "";
$rootScope.HtmlContent13.TooltipPos = "top";
$rootScope.HtmlContent13.PopoverText = "";
$rootScope.HtmlContent13.PopoverEvent = "mouseenter";
$rootScope.HtmlContent13.PopoverTitle = "";
$rootScope.HtmlContent13.PopoverPos = "right";

$rootScope.TugasDosenLoader = {};
$rootScope.TugasDosenLoader.Hidden = "true";
$rootScope.TugasDosenLoader.Class = "";
$rootScope.TugasDosenLoader.Title = "";
$rootScope.TugasDosenLoader.TooltipText = "";
$rootScope.TugasDosenLoader.TooltipPos = "top";
$rootScope.TugasDosenLoader.PopoverText = "";
$rootScope.TugasDosenLoader.PopoverEvent = "mouseenter";
$rootScope.TugasDosenLoader.PopoverTitle = "";
$rootScope.TugasDosenLoader.PopoverPos = "top";

$rootScope.DosenTugasList = {};
$rootScope.DosenTugasList.Status = 0;
$rootScope.DosenTugasList.StatusText = "";
$rootScope.DosenTugasList.Response = "";
$rootScope.DosenTugasList.Request = {};
$rootScope.DosenTugasList.Request.data = {};
$rootScope.DosenTugasList.Request.headers = {};
$rootScope.DosenTugasList.Request.url = "";
$rootScope.DosenTugasList.Request.method = "POST";

$rootScope.DosenTugasHapus = {};
$rootScope.DosenTugasHapus.Status = 0;
$rootScope.DosenTugasHapus.StatusText = "";
$rootScope.DosenTugasHapus.Response = "";
$rootScope.DosenTugasHapus.Request = {};
$rootScope.DosenTugasHapus.Request.data = {};
$rootScope.DosenTugasHapus.Request.headers = {};
$rootScope.DosenTugasHapus.Request.url = "";
$rootScope.DosenTugasHapus.Request.method = "POST";

$rootScope.ReportListTugas = {};
$rootScope.ReportListTugas.Hidden = "";
$rootScope.ReportListTugas.Url = "";
$rootScope.ReportListTugas.Loading = "Loading data tugas...";
$rootScope.ReportListTugas.Class = "";
$rootScope.ReportListTugas.Order = "";
$rootScope.ReportListTugas.Query = "";
$rootScope.ReportListTugas.Record = null;
$rootScope.ReportListTugas.Data = "";

$rootScope.Input7 = {};
$rootScope.Input7.Hidden = "";
$rootScope.Input7.Value = "";
$rootScope.Input7.Title = "";
$rootScope.Input7.TabIndex = -1;
$rootScope.Input7.TooltipText = "";
$rootScope.Input7.TooltipPos = "top";
$rootScope.Input7.PopoverText = "";
$rootScope.Input7.PopoverEvent = "mouseenter";
$rootScope.Input7.PopoverTitle = "";
$rootScope.Input7.PopoverPos = "top";
$rootScope.Input7.PlaceHolder = "pencarian data";
$rootScope.Input7.Class = "form-control input-sm ";
$rootScope.Input7.Disabled = "";
$rootScope.Input7.Required = "";
$rootScope.Input7.ReadOnly = "";

$rootScope.HtmlContent25 = {};
$rootScope.HtmlContent25.Hidden = "true";
$rootScope.HtmlContent25.Class = "";
$rootScope.HtmlContent25.Title = "";
$rootScope.HtmlContent25.TooltipText = "";
$rootScope.HtmlContent25.TooltipPos = "top";
$rootScope.HtmlContent25.PopoverText = "";
$rootScope.HtmlContent25.PopoverEvent = "mouseenter";
$rootScope.HtmlContent25.PopoverTitle = "";
$rootScope.HtmlContent25.PopoverPos = "top";

$rootScope.ListTugasClientLoader = {};
$rootScope.ListTugasClientLoader.Hidden = "true";
$rootScope.ListTugasClientLoader.Class = "";
$rootScope.ListTugasClientLoader.Title = "";
$rootScope.ListTugasClientLoader.TooltipText = "";
$rootScope.ListTugasClientLoader.TooltipPos = "top";
$rootScope.ListTugasClientLoader.PopoverText = "";
$rootScope.ListTugasClientLoader.PopoverEvent = "mouseenter";
$rootScope.ListTugasClientLoader.PopoverTitle = "";
$rootScope.ListTugasClientLoader.PopoverPos = "top";

$rootScope.HtmlContent27 = {};
$rootScope.HtmlContent27.Hidden = "";
$rootScope.HtmlContent27.Class = "";
$rootScope.HtmlContent27.Title = "";
$rootScope.HtmlContent27.TooltipText = "";
$rootScope.HtmlContent27.TooltipPos = "top";
$rootScope.HtmlContent27.PopoverText = "";
$rootScope.HtmlContent27.PopoverEvent = "mouseenter";
$rootScope.HtmlContent27.PopoverTitle = "";
$rootScope.HtmlContent27.PopoverPos = "top";

$rootScope.ListTugasClient = {};
$rootScope.ListTugasClient.Status = 0;
$rootScope.ListTugasClient.StatusText = "";
$rootScope.ListTugasClient.Response = "";
$rootScope.ListTugasClient.Request = {};
$rootScope.ListTugasClient.Request.data = {};
$rootScope.ListTugasClient.Request.headers = {};
$rootScope.ListTugasClient.Request.url = "";
$rootScope.ListTugasClient.Request.method = "POST";

$rootScope.RepotMateriTugas = {};
$rootScope.RepotMateriTugas.Hidden = "";
$rootScope.RepotMateriTugas.Url = "";
$rootScope.RepotMateriTugas.Loading = "Loading data materi...";
$rootScope.RepotMateriTugas.Class = "";
$rootScope.RepotMateriTugas.Order = "";
$rootScope.RepotMateriTugas.Query = "";
$rootScope.RepotMateriTugas.Record = null;
$rootScope.RepotMateriTugas.Data = "";

$rootScope.Input2 = {};
$rootScope.Input2.Hidden = "";
$rootScope.Input2.Value = "";
$rootScope.Input2.Title = "";
$rootScope.Input2.TabIndex = -1;
$rootScope.Input2.TooltipText = "";
$rootScope.Input2.TooltipPos = "top";
$rootScope.Input2.PopoverText = "";
$rootScope.Input2.PopoverEvent = "mouseenter";
$rootScope.Input2.PopoverTitle = "";
$rootScope.Input2.PopoverPos = "top";
$rootScope.Input2.PlaceHolder = "pencarian data";
$rootScope.Input2.Class = "form-control input-sm ";
$rootScope.Input2.Disabled = "";
$rootScope.Input2.Required = "";
$rootScope.Input2.ReadOnly = "";

$rootScope.HtmlContent14 = {};
$rootScope.HtmlContent14.Hidden = "true";
$rootScope.HtmlContent14.Class = "";
$rootScope.HtmlContent14.Title = "";
$rootScope.HtmlContent14.TooltipText = "";
$rootScope.HtmlContent14.TooltipPos = "top";
$rootScope.HtmlContent14.PopoverText = "";
$rootScope.HtmlContent14.PopoverEvent = "mouseenter";
$rootScope.HtmlContent14.PopoverTitle = "";
$rootScope.HtmlContent14.PopoverPos = "top";

$rootScope.ListMateriLoader = {};
$rootScope.ListMateriLoader.Hidden = "true";
$rootScope.ListMateriLoader.Class = "";
$rootScope.ListMateriLoader.Title = "";
$rootScope.ListMateriLoader.TooltipText = "";
$rootScope.ListMateriLoader.TooltipPos = "top";
$rootScope.ListMateriLoader.PopoverText = "";
$rootScope.ListMateriLoader.PopoverEvent = "mouseenter";
$rootScope.ListMateriLoader.PopoverTitle = "";
$rootScope.ListMateriLoader.PopoverPos = "top";

$rootScope.MateriTugas = {};
$rootScope.MateriTugas.Status = 0;
$rootScope.MateriTugas.StatusText = "";
$rootScope.MateriTugas.Response = "";
$rootScope.MateriTugas.Request = {};
$rootScope.MateriTugas.Request.data = {};
$rootScope.MateriTugas.Request.headers = {};
$rootScope.MateriTugas.Request.url = "";
$rootScope.MateriTugas.Request.method = "POST";

$rootScope.HtmlContent15 = {};
$rootScope.HtmlContent15.Hidden = "";
$rootScope.HtmlContent15.Class = "";
$rootScope.HtmlContent15.Title = "";
$rootScope.HtmlContent15.TooltipText = "";
$rootScope.HtmlContent15.TooltipPos = "top";
$rootScope.HtmlContent15.PopoverText = "";
$rootScope.HtmlContent15.PopoverEvent = "mouseenter";
$rootScope.HtmlContent15.PopoverTitle = "";
$rootScope.HtmlContent15.PopoverPos = "top";

$rootScope.ReportTugasMahasiswaDosen = {};
$rootScope.ReportTugasMahasiswaDosen.Hidden = "";
$rootScope.ReportTugasMahasiswaDosen.Url = "";
$rootScope.ReportTugasMahasiswaDosen.Loading = "Loading data tugas mahasiswa...";
$rootScope.ReportTugasMahasiswaDosen.Class = "";
$rootScope.ReportTugasMahasiswaDosen.Order = "";
$rootScope.ReportTugasMahasiswaDosen.Query = "";
$rootScope.ReportTugasMahasiswaDosen.Record = null;
$rootScope.ReportTugasMahasiswaDosen.Data = "";

$rootScope.Input6 = {};
$rootScope.Input6.Hidden = "";
$rootScope.Input6.Value = "";
$rootScope.Input6.Title = "";
$rootScope.Input6.TabIndex = -1;
$rootScope.Input6.TooltipText = "";
$rootScope.Input6.TooltipPos = "top";
$rootScope.Input6.PopoverText = "";
$rootScope.Input6.PopoverEvent = "mouseenter";
$rootScope.Input6.PopoverTitle = "";
$rootScope.Input6.PopoverPos = "top";
$rootScope.Input6.PlaceHolder = "pencarian data";
$rootScope.Input6.Class = "form-control input-sm ";
$rootScope.Input6.Disabled = "";
$rootScope.Input6.Required = "";
$rootScope.Input6.ReadOnly = "";

$rootScope.HtmlContent20 = {};
$rootScope.HtmlContent20.Hidden = "true";
$rootScope.HtmlContent20.Class = "";
$rootScope.HtmlContent20.Title = "";
$rootScope.HtmlContent20.TooltipText = "";
$rootScope.HtmlContent20.TooltipPos = "top";
$rootScope.HtmlContent20.PopoverText = "";
$rootScope.HtmlContent20.PopoverEvent = "mouseenter";
$rootScope.HtmlContent20.PopoverTitle = "";
$rootScope.HtmlContent20.PopoverPos = "top";

$rootScope.TugasMahasiswaListDosenClientLoader = {};
$rootScope.TugasMahasiswaListDosenClientLoader.Hidden = "true";
$rootScope.TugasMahasiswaListDosenClientLoader.Class = "";
$rootScope.TugasMahasiswaListDosenClientLoader.Title = "";
$rootScope.TugasMahasiswaListDosenClientLoader.TooltipText = "";
$rootScope.TugasMahasiswaListDosenClientLoader.TooltipPos = "top";
$rootScope.TugasMahasiswaListDosenClientLoader.PopoverText = "";
$rootScope.TugasMahasiswaListDosenClientLoader.PopoverEvent = "mouseenter";
$rootScope.TugasMahasiswaListDosenClientLoader.PopoverTitle = "";
$rootScope.TugasMahasiswaListDosenClientLoader.PopoverPos = "top";

$rootScope.TugasMahasiswaListDosenClient = {};
$rootScope.TugasMahasiswaListDosenClient.Status = 0;
$rootScope.TugasMahasiswaListDosenClient.StatusText = "";
$rootScope.TugasMahasiswaListDosenClient.Response = "";
$rootScope.TugasMahasiswaListDosenClient.Request = {};
$rootScope.TugasMahasiswaListDosenClient.Request.data = {};
$rootScope.TugasMahasiswaListDosenClient.Request.headers = {};
$rootScope.TugasMahasiswaListDosenClient.Request.url = "";
$rootScope.TugasMahasiswaListDosenClient.Request.method = "POST";

$rootScope.HtmlContent23 = {};
$rootScope.HtmlContent23.Hidden = "";
$rootScope.HtmlContent23.Class = "";
$rootScope.HtmlContent23.Title = "";
$rootScope.HtmlContent23.TooltipText = "";
$rootScope.HtmlContent23.TooltipPos = "top";
$rootScope.HtmlContent23.PopoverText = "";
$rootScope.HtmlContent23.PopoverEvent = "mouseenter";
$rootScope.HtmlContent23.PopoverTitle = "";
$rootScope.HtmlContent23.PopoverPos = "right";

$rootScope.NilaiTugasSimpan = {};
$rootScope.NilaiTugasSimpan.Status = 0;
$rootScope.NilaiTugasSimpan.StatusText = "";
$rootScope.NilaiTugasSimpan.Response = "";
$rootScope.NilaiTugasSimpan.Request = {};
$rootScope.NilaiTugasSimpan.Request.data = {};
$rootScope.NilaiTugasSimpan.Request.headers = {};
$rootScope.NilaiTugasSimpan.Request.url = "";
$rootScope.NilaiTugasSimpan.Request.method = "POST";

$rootScope.HtmlContent18 = {};
$rootScope.HtmlContent18.Hidden = "";
$rootScope.HtmlContent18.Class = "";
$rootScope.HtmlContent18.Title = "";
$rootScope.HtmlContent18.TooltipText = "";
$rootScope.HtmlContent18.TooltipPos = "top";
$rootScope.HtmlContent18.PopoverText = "";
$rootScope.HtmlContent18.PopoverEvent = "mouseenter";
$rootScope.HtmlContent18.PopoverTitle = "";
$rootScope.HtmlContent18.PopoverPos = "top";

$rootScope.Button11 = {};
$rootScope.Button11.Hidden = "";
$rootScope.Button11.Title = "";
$rootScope.Button11.TabIndex = -1;
$rootScope.Button11.TooltipText = "";
$rootScope.Button11.TooltipPos = "top";
$rootScope.Button11.PopoverText = "";
$rootScope.Button11.PopoverTitle = "";
$rootScope.Button11.PopoverEvent = "mouseenter";
$rootScope.Button11.PopoverPos = "top";
$rootScope.Button11.Badge = "";
$rootScope.Button11.Icon = "glyphicon glyphicon-hdd";
$rootScope.Button11.Text = "Download Berkas";
$rootScope.Button11.Class = "btn btn-primary btn-md ";
$rootScope.Button11.Disabled = "";

$rootScope.HtmlContent19 = {};
$rootScope.HtmlContent19.Hidden = "";
$rootScope.HtmlContent19.Class = "";
$rootScope.HtmlContent19.Title = "";
$rootScope.HtmlContent19.TooltipText = "";
$rootScope.HtmlContent19.TooltipPos = "top";
$rootScope.HtmlContent19.PopoverText = "";
$rootScope.HtmlContent19.PopoverEvent = "mouseenter";
$rootScope.HtmlContent19.PopoverTitle = "";
$rootScope.HtmlContent19.PopoverPos = "top";

$rootScope.ReportMatkulEnroll = {};
$rootScope.ReportMatkulEnroll.Hidden = "";
$rootScope.ReportMatkulEnroll.Url = "";
$rootScope.ReportMatkulEnroll.Loading = "Loading data...";
$rootScope.ReportMatkulEnroll.Class = "";
$rootScope.ReportMatkulEnroll.Order = "";
$rootScope.ReportMatkulEnroll.Query = "";
$rootScope.ReportMatkulEnroll.Record = null;
$rootScope.ReportMatkulEnroll.Data = "";

$rootScope.Input9 = {};
$rootScope.Input9.Hidden = "";
$rootScope.Input9.Value = "";
$rootScope.Input9.Title = "";
$rootScope.Input9.TabIndex = -1;
$rootScope.Input9.TooltipText = "";
$rootScope.Input9.TooltipPos = "top";
$rootScope.Input9.PopoverText = "";
$rootScope.Input9.PopoverEvent = "mouseenter";
$rootScope.Input9.PopoverTitle = "";
$rootScope.Input9.PopoverPos = "top";
$rootScope.Input9.PlaceHolder = "pencarian data";
$rootScope.Input9.Class = "form-control input-sm ";
$rootScope.Input9.Disabled = "";
$rootScope.Input9.Required = "";
$rootScope.Input9.ReadOnly = "";

$rootScope.HtmlContent30 = {};
$rootScope.HtmlContent30.Hidden = "true";
$rootScope.HtmlContent30.Class = "";
$rootScope.HtmlContent30.Title = "";
$rootScope.HtmlContent30.TooltipText = "";
$rootScope.HtmlContent30.TooltipPos = "top";
$rootScope.HtmlContent30.PopoverText = "";
$rootScope.HtmlContent30.PopoverEvent = "mouseenter";
$rootScope.HtmlContent30.PopoverTitle = "";
$rootScope.HtmlContent30.PopoverPos = "top";

$rootScope.ReportMatkulEnrollLoader = {};
$rootScope.ReportMatkulEnrollLoader.Hidden = "true";
$rootScope.ReportMatkulEnrollLoader.Class = "";
$rootScope.ReportMatkulEnrollLoader.Title = "";
$rootScope.ReportMatkulEnrollLoader.TooltipText = "";
$rootScope.ReportMatkulEnrollLoader.TooltipPos = "top";
$rootScope.ReportMatkulEnrollLoader.PopoverText = "";
$rootScope.ReportMatkulEnrollLoader.PopoverEvent = "mouseenter";
$rootScope.ReportMatkulEnrollLoader.PopoverTitle = "";
$rootScope.ReportMatkulEnrollLoader.PopoverPos = "top";

$rootScope.HtmlContent32 = {};
$rootScope.HtmlContent32.Hidden = "";
$rootScope.HtmlContent32.Class = "";
$rootScope.HtmlContent32.Title = "";
$rootScope.HtmlContent32.TooltipText = "";
$rootScope.HtmlContent32.TooltipPos = "top";
$rootScope.HtmlContent32.PopoverText = "";
$rootScope.HtmlContent32.PopoverEvent = "mouseenter";
$rootScope.HtmlContent32.PopoverTitle = "";
$rootScope.HtmlContent32.PopoverPos = "top";

$rootScope.MatkulEnrollClient = {};
$rootScope.MatkulEnrollClient.Status = 0;
$rootScope.MatkulEnrollClient.StatusText = "";
$rootScope.MatkulEnrollClient.Response = "";
$rootScope.MatkulEnrollClient.Request = {};
$rootScope.MatkulEnrollClient.Request.data = {};
$rootScope.MatkulEnrollClient.Request.headers = {};
$rootScope.MatkulEnrollClient.Request.url = "";
$rootScope.MatkulEnrollClient.Request.method = "POST";

$rootScope.Button2 = {};
$rootScope.Button2.Hidden = "";
$rootScope.Button2.Title = "";
$rootScope.Button2.TabIndex = 4;
$rootScope.Button2.TooltipText = "";
$rootScope.Button2.TooltipPos = "top";
$rootScope.Button2.PopoverText = "";
$rootScope.Button2.PopoverTitle = "";
$rootScope.Button2.PopoverEvent = "mouseenter";
$rootScope.Button2.PopoverPos = "top";
$rootScope.Button2.Badge = "";
$rootScope.Button2.Icon = "glyphicon glyphicon-plane";
$rootScope.Button2.Text = "Send";
$rootScope.Button2.Class = "btn btn-primary btn-lg ";
$rootScope.Button2.Disabled = "";

$rootScope.Input3 = {};
$rootScope.Input3.Hidden = "";
$rootScope.Input3.Value = "";
$rootScope.Input3.Title = "";
$rootScope.Input3.TabIndex = 1;
$rootScope.Input3.TooltipText = "";
$rootScope.Input3.TooltipPos = "top";
$rootScope.Input3.PopoverText = "";
$rootScope.Input3.PopoverEvent = "mouseenter";
$rootScope.Input3.PopoverTitle = "";
$rootScope.Input3.PopoverPos = "top";
$rootScope.Input3.PlaceHolder = "Your name";
$rootScope.Input3.Class = "form-control input-sm ";
$rootScope.Input3.Disabled = "";
$rootScope.Input3.Required = "";
$rootScope.Input3.ReadOnly = "";

$rootScope.Input4 = {};
$rootScope.Input4.Hidden = "";
$rootScope.Input4.Value = "";
$rootScope.Input4.Title = "";
$rootScope.Input4.TabIndex = 2;
$rootScope.Input4.TooltipText = "";
$rootScope.Input4.TooltipPos = "top";
$rootScope.Input4.PopoverText = "";
$rootScope.Input4.PopoverEvent = "mouseenter";
$rootScope.Input4.PopoverTitle = "";
$rootScope.Input4.PopoverPos = "top";
$rootScope.Input4.PlaceHolder = "Your last name";
$rootScope.Input4.Class = "form-control input-sm ";
$rootScope.Input4.Disabled = "";
$rootScope.Input4.Required = "";
$rootScope.Input4.ReadOnly = "";

$rootScope.Textarea3 = {};
$rootScope.Textarea3.Hidden = "";
$rootScope.Textarea3.Value = "";
$rootScope.Textarea3.Title = "";
$rootScope.Textarea3.TabIndex = -1;
$rootScope.Textarea3.TooltipText = "";
$rootScope.Textarea3.TooltipPos = "top";
$rootScope.Textarea3.PopoverText = "";
$rootScope.Textarea3.PopoverEvent = "mouseenter";
$rootScope.Textarea3.PopoverTitle = "";
$rootScope.Textarea3.PopoverPos = "top";
$rootScope.Textarea3.PlaceHolder = "";
$rootScope.Textarea3.Class = "form-control input-sm ";
$rootScope.Textarea3.Disabled = "";
$rootScope.Textarea3.Required = "";
$rootScope.Textarea3.ReadOnly = "true";

$rootScope.Input5 = {};
$rootScope.Input5.Hidden = "";
$rootScope.Input5.Url = "";
$rootScope.Input5.Data = "";
$rootScope.Input5.Value = null;
$rootScope.Input5.Title = "";
$rootScope.Input5.Accept = "";
$rootScope.Input5.TabIndex = 3;
$rootScope.Input5.TooltipText = "";
$rootScope.Input5.TooltipPos = "top";
$rootScope.Input5.PopoverText = "";
$rootScope.Input5.PopoverEvent = "mouseenter";
$rootScope.Input5.PopoverTitle = "";
$rootScope.Input5.PopoverPos = "top";
$rootScope.Input5.Class = "form-control input-sm ";
$rootScope.Input5.Disabled = "";
$rootScope.Input5.Required = "";

$rootScope.HtmlContent3 = {};
$rootScope.HtmlContent3.Hidden = "";
$rootScope.HtmlContent3.Class = "";
$rootScope.HtmlContent3.Title = "";
$rootScope.HtmlContent3.TooltipText = "";
$rootScope.HtmlContent3.TooltipPos = "top";
$rootScope.HtmlContent3.PopoverText = "";
$rootScope.HtmlContent3.PopoverEvent = "mouseenter";
$rootScope.HtmlContent3.PopoverTitle = "";
$rootScope.HtmlContent3.PopoverPos = "top";

$rootScope.Progressbar1 = {};
$rootScope.Progressbar1.Hidden = "true";
$rootScope.Progressbar1.Title = "";
$rootScope.Progressbar1.TooltipText = "";
$rootScope.Progressbar1.TooltipPos = "top";
$rootScope.Progressbar1.PopoverText = "";
$rootScope.Progressbar1.PopoverEvent = "mouseenter";
$rootScope.Progressbar1.PopoverTitle = "";
$rootScope.Progressbar1.PopoverPos = "top";
$rootScope.Progressbar1.Class = "progress-bar progress-bar-info progress-bar-striped active ";
$rootScope.Progressbar1.Percentage = 100;

$rootScope.Label1 = {};
$rootScope.Label1.Hidden = "";
$rootScope.Label1.Class = "";
$rootScope.Label1.Text = "Response";
$rootScope.Label1.Input = "Textarea3";
$rootScope.Label1.Title = "";
$rootScope.Label1.TooltipText = "";
$rootScope.Label1.TooltipPos = "top";
$rootScope.Label1.PopoverText = "";
$rootScope.Label1.PopoverEvent = "mouseenter";
$rootScope.Label1.PopoverTitle = "";
$rootScope.Label1.PopoverPos = "top";

$rootScope.ReportListMateri = {};
$rootScope.ReportListMateri.Hidden = "";
$rootScope.ReportListMateri.Url = "";
$rootScope.ReportListMateri.Loading = "Loading data materi...";
$rootScope.ReportListMateri.Class = "";
$rootScope.ReportListMateri.Order = "";
$rootScope.ReportListMateri.Query = "";
$rootScope.ReportListMateri.Record = null;
$rootScope.ReportListMateri.Data = "";

$rootScope.Input10 = {};
$rootScope.Input10.Hidden = "";
$rootScope.Input10.Value = "";
$rootScope.Input10.Title = "";
$rootScope.Input10.TabIndex = -1;
$rootScope.Input10.TooltipText = "";
$rootScope.Input10.TooltipPos = "top";
$rootScope.Input10.PopoverText = "";
$rootScope.Input10.PopoverEvent = "mouseenter";
$rootScope.Input10.PopoverTitle = "";
$rootScope.Input10.PopoverPos = "top";
$rootScope.Input10.PlaceHolder = "pencarian data";
$rootScope.Input10.Class = "form-control input-sm ";
$rootScope.Input10.Disabled = "";
$rootScope.Input10.Required = "";
$rootScope.Input10.ReadOnly = "";

$rootScope.HtmlContent34 = {};
$rootScope.HtmlContent34.Hidden = "true";
$rootScope.HtmlContent34.Class = "";
$rootScope.HtmlContent34.Title = "";
$rootScope.HtmlContent34.TooltipText = "";
$rootScope.HtmlContent34.TooltipPos = "top";
$rootScope.HtmlContent34.PopoverText = "";
$rootScope.HtmlContent34.PopoverEvent = "mouseenter";
$rootScope.HtmlContent34.PopoverTitle = "";
$rootScope.HtmlContent34.PopoverPos = "top";

$rootScope.HtmlContent35 = {};
$rootScope.HtmlContent35.Hidden = "";
$rootScope.HtmlContent35.Class = "";
$rootScope.HtmlContent35.Title = "";
$rootScope.HtmlContent35.TooltipText = "";
$rootScope.HtmlContent35.TooltipPos = "top";
$rootScope.HtmlContent35.PopoverText = "";
$rootScope.HtmlContent35.PopoverEvent = "mouseenter";
$rootScope.HtmlContent35.PopoverTitle = "";
$rootScope.HtmlContent35.PopoverPos = "right";

$rootScope.HtmlContent37 = {};
$rootScope.HtmlContent37.Hidden = "";
$rootScope.HtmlContent37.Class = "";
$rootScope.HtmlContent37.Title = "";
$rootScope.HtmlContent37.TooltipText = "";
$rootScope.HtmlContent37.TooltipPos = "top";
$rootScope.HtmlContent37.PopoverText = "";
$rootScope.HtmlContent37.PopoverEvent = "mouseenter";
$rootScope.HtmlContent37.PopoverTitle = "";
$rootScope.HtmlContent37.PopoverPos = "right";

$rootScope.ReportListMateriLoader = {};
$rootScope.ReportListMateriLoader.Hidden = "true";
$rootScope.ReportListMateriLoader.Class = "";
$rootScope.ReportListMateriLoader.Title = "";
$rootScope.ReportListMateriLoader.TooltipText = "";
$rootScope.ReportListMateriLoader.TooltipPos = "top";
$rootScope.ReportListMateriLoader.PopoverText = "";
$rootScope.ReportListMateriLoader.PopoverEvent = "mouseenter";
$rootScope.ReportListMateriLoader.PopoverTitle = "";
$rootScope.ReportListMateriLoader.PopoverPos = "top";

$rootScope.ViewMateriClient = {};
$rootScope.ViewMateriClient.Status = 0;
$rootScope.ViewMateriClient.StatusText = "";
$rootScope.ViewMateriClient.Response = "";
$rootScope.ViewMateriClient.Request = {};
$rootScope.ViewMateriClient.Request.data = {};
$rootScope.ViewMateriClient.Request.headers = {};
$rootScope.ViewMateriClient.Request.url = "";
$rootScope.ViewMateriClient.Request.method = "POST";

$rootScope.HtmlContent36 = {};
$rootScope.HtmlContent36.Hidden = "";
$rootScope.HtmlContent36.Class = "";
$rootScope.HtmlContent36.Title = "";
$rootScope.HtmlContent36.TooltipText = "";
$rootScope.HtmlContent36.TooltipPos = "top";
$rootScope.HtmlContent36.PopoverText = "";
$rootScope.HtmlContent36.PopoverEvent = "mouseenter";
$rootScope.HtmlContent36.PopoverTitle = "";
$rootScope.HtmlContent36.PopoverPos = "top";

$rootScope.Button14 = {};
$rootScope.Button14.Hidden = "";
$rootScope.Button14.Title = "";
$rootScope.Button14.TabIndex = -1;
$rootScope.Button14.TooltipText = "";
$rootScope.Button14.TooltipPos = "top";
$rootScope.Button14.PopoverText = "";
$rootScope.Button14.PopoverTitle = "";
$rootScope.Button14.PopoverEvent = "mouseenter";
$rootScope.Button14.PopoverPos = "top";
$rootScope.Button14.Badge = "";
$rootScope.Button14.Icon = "glyphicon glyphicon-hdd";
$rootScope.Button14.Text = "Download Materi";
$rootScope.Button14.Class = "btn btn-primary btn-md ";
$rootScope.Button14.Disabled = "";

$rootScope.HtmlContent38 = {};
$rootScope.HtmlContent38.Hidden = "";
$rootScope.HtmlContent38.Class = "";
$rootScope.HtmlContent38.Title = "";
$rootScope.HtmlContent38.TooltipText = "";
$rootScope.HtmlContent38.TooltipPos = "top";
$rootScope.HtmlContent38.PopoverText = "";
$rootScope.HtmlContent38.PopoverEvent = "mouseenter";
$rootScope.HtmlContent38.PopoverTitle = "";
$rootScope.HtmlContent38.PopoverPos = "top";

$rootScope.ReportViewTugas = {};
$rootScope.ReportViewTugas.Hidden = "";
$rootScope.ReportViewTugas.Url = "";
$rootScope.ReportViewTugas.Loading = "Loading data tugas...";
$rootScope.ReportViewTugas.Class = "";
$rootScope.ReportViewTugas.Order = "";
$rootScope.ReportViewTugas.Query = "";
$rootScope.ReportViewTugas.Record = null;
$rootScope.ReportViewTugas.Data = "";

$rootScope.Input11 = {};
$rootScope.Input11.Hidden = "";
$rootScope.Input11.Value = "";
$rootScope.Input11.Title = "";
$rootScope.Input11.TabIndex = -1;
$rootScope.Input11.TooltipText = "";
$rootScope.Input11.TooltipPos = "top";
$rootScope.Input11.PopoverText = "";
$rootScope.Input11.PopoverEvent = "mouseenter";
$rootScope.Input11.PopoverTitle = "";
$rootScope.Input11.PopoverPos = "top";
$rootScope.Input11.PlaceHolder = "pencarian data";
$rootScope.Input11.Class = "form-control input-sm ";
$rootScope.Input11.Disabled = "";
$rootScope.Input11.Required = "";
$rootScope.Input11.ReadOnly = "";

$rootScope.HtmlContent39 = {};
$rootScope.HtmlContent39.Hidden = "true";
$rootScope.HtmlContent39.Class = "";
$rootScope.HtmlContent39.Title = "";
$rootScope.HtmlContent39.TooltipText = "";
$rootScope.HtmlContent39.TooltipPos = "top";
$rootScope.HtmlContent39.PopoverText = "";
$rootScope.HtmlContent39.PopoverEvent = "mouseenter";
$rootScope.HtmlContent39.PopoverTitle = "";
$rootScope.HtmlContent39.PopoverPos = "top";

$rootScope.HtmlContent40 = {};
$rootScope.HtmlContent40.Hidden = "";
$rootScope.HtmlContent40.Class = "";
$rootScope.HtmlContent40.Title = "";
$rootScope.HtmlContent40.TooltipText = "";
$rootScope.HtmlContent40.TooltipPos = "top";
$rootScope.HtmlContent40.PopoverText = "";
$rootScope.HtmlContent40.PopoverEvent = "mouseenter";
$rootScope.HtmlContent40.PopoverTitle = "";
$rootScope.HtmlContent40.PopoverPos = "right";

$rootScope.HtmlContent41 = {};
$rootScope.HtmlContent41.Hidden = "";
$rootScope.HtmlContent41.Class = "";
$rootScope.HtmlContent41.Title = "";
$rootScope.HtmlContent41.TooltipText = "";
$rootScope.HtmlContent41.TooltipPos = "top";
$rootScope.HtmlContent41.PopoverText = "";
$rootScope.HtmlContent41.PopoverEvent = "mouseenter";
$rootScope.HtmlContent41.PopoverTitle = "";
$rootScope.HtmlContent41.PopoverPos = "right";

$rootScope.ViewTugasClientLoader = {};
$rootScope.ViewTugasClientLoader.Hidden = "true";
$rootScope.ViewTugasClientLoader.Class = "";
$rootScope.ViewTugasClientLoader.Title = "";
$rootScope.ViewTugasClientLoader.TooltipText = "";
$rootScope.ViewTugasClientLoader.TooltipPos = "top";
$rootScope.ViewTugasClientLoader.PopoverText = "";
$rootScope.ViewTugasClientLoader.PopoverEvent = "mouseenter";
$rootScope.ViewTugasClientLoader.PopoverTitle = "";
$rootScope.ViewTugasClientLoader.PopoverPos = "top";

$rootScope.ViewTugasClient = {};
$rootScope.ViewTugasClient.Status = 0;
$rootScope.ViewTugasClient.StatusText = "";
$rootScope.ViewTugasClient.Response = "";
$rootScope.ViewTugasClient.Request = {};
$rootScope.ViewTugasClient.Request.data = {};
$rootScope.ViewTugasClient.Request.headers = {};
$rootScope.ViewTugasClient.Request.url = "";
$rootScope.ViewTugasClient.Request.method = "POST";

$rootScope.SimpanTugasMahasiswa = {};
$rootScope.SimpanTugasMahasiswa.Status = 0;
$rootScope.SimpanTugasMahasiswa.StatusText = "";
$rootScope.SimpanTugasMahasiswa.Response = "";
$rootScope.SimpanTugasMahasiswa.Request = {};
$rootScope.SimpanTugasMahasiswa.Request.data = {};
$rootScope.SimpanTugasMahasiswa.Request.headers = {};
$rootScope.SimpanTugasMahasiswa.Request.url = "";
$rootScope.SimpanTugasMahasiswa.Request.method = "POST";

$rootScope.HtmlContent42 = {};
$rootScope.HtmlContent42.Hidden = "";
$rootScope.HtmlContent42.Class = "";
$rootScope.HtmlContent42.Title = "";
$rootScope.HtmlContent42.TooltipText = "";
$rootScope.HtmlContent42.TooltipPos = "top";
$rootScope.HtmlContent42.PopoverText = "";
$rootScope.HtmlContent42.PopoverEvent = "mouseenter";
$rootScope.HtmlContent42.PopoverTitle = "";
$rootScope.HtmlContent42.PopoverPos = "top";

$rootScope.Button15 = {};
$rootScope.Button15.Hidden = "";
$rootScope.Button15.Title = "";
$rootScope.Button15.TabIndex = -1;
$rootScope.Button15.TooltipText = "";
$rootScope.Button15.TooltipPos = "top";
$rootScope.Button15.PopoverText = "";
$rootScope.Button15.PopoverTitle = "";
$rootScope.Button15.PopoverEvent = "mouseenter";
$rootScope.Button15.PopoverPos = "top";
$rootScope.Button15.Badge = "";
$rootScope.Button15.Icon = "glyphicon glyphicon-hdd";
$rootScope.Button15.Text = "Download Berkas";
$rootScope.Button15.Class = "btn btn-primary btn-md ";
$rootScope.Button15.Disabled = "";

$rootScope.HtmlContent43 = {};
$rootScope.HtmlContent43.Hidden = "";
$rootScope.HtmlContent43.Class = "";
$rootScope.HtmlContent43.Title = "";
$rootScope.HtmlContent43.TooltipText = "";
$rootScope.HtmlContent43.TooltipPos = "top";
$rootScope.HtmlContent43.PopoverText = "";
$rootScope.HtmlContent43.PopoverEvent = "mouseenter";
$rootScope.HtmlContent43.PopoverTitle = "";
$rootScope.HtmlContent43.PopoverPos = "top";

$rootScope.btnKirimTugas = {};
$rootScope.btnKirimTugas.Hidden = "";
$rootScope.btnKirimTugas.Title = "";
$rootScope.btnKirimTugas.TabIndex = -1;
$rootScope.btnKirimTugas.TooltipText = "";
$rootScope.btnKirimTugas.TooltipPos = "top";
$rootScope.btnKirimTugas.PopoverText = "";
$rootScope.btnKirimTugas.PopoverTitle = "";
$rootScope.btnKirimTugas.PopoverEvent = "mouseenter";
$rootScope.btnKirimTugas.PopoverPos = "top";
$rootScope.btnKirimTugas.Badge = "";
$rootScope.btnKirimTugas.Icon = "fa fa-external-link fa-lg";
$rootScope.btnKirimTugas.Text = "Kirim Tugas";
$rootScope.btnKirimTugas.Class = "btn btn-success btn-md ";
$rootScope.btnKirimTugas.Disabled = "";

$rootScope.Button16 = {};
$rootScope.Button16.Hidden = "";
$rootScope.Button16.Title = "";
$rootScope.Button16.TabIndex = 5;
$rootScope.Button16.TooltipText = "";
$rootScope.Button16.TooltipPos = "top";
$rootScope.Button16.PopoverText = "";
$rootScope.Button16.PopoverTitle = "";
$rootScope.Button16.PopoverEvent = "mouseenter";
$rootScope.Button16.PopoverPos = "top";
$rootScope.Button16.Badge = "";
$rootScope.Button16.Icon = "glyphicon glyphicon-floppy-disk";
$rootScope.Button16.Text = "Simpan";
$rootScope.Button16.Class = "btn btn-primary btn-lg ";
$rootScope.Button16.Disabled = "";

$rootScope.Progressbar3 = {};
$rootScope.Progressbar3.Hidden = "true";
$rootScope.Progressbar3.Title = "";
$rootScope.Progressbar3.TooltipText = "";
$rootScope.Progressbar3.TooltipPos = "top";
$rootScope.Progressbar3.PopoverText = "";
$rootScope.Progressbar3.PopoverEvent = "mouseenter";
$rootScope.Progressbar3.PopoverTitle = "";
$rootScope.Progressbar3.PopoverPos = "top";
$rootScope.Progressbar3.Class = "progress-bar progress-bar-info progress-bar-striped active ";
$rootScope.Progressbar3.Percentage = 100;

$rootScope.Button17 = {};
$rootScope.Button17.Hidden = "";
$rootScope.Button17.Title = "";
$rootScope.Button17.TabIndex = 4;
$rootScope.Button17.TooltipText = "";
$rootScope.Button17.TooltipPos = "top";
$rootScope.Button17.PopoverText = "";
$rootScope.Button17.PopoverTitle = "";
$rootScope.Button17.PopoverEvent = "mouseenter";
$rootScope.Button17.PopoverPos = "top";
$rootScope.Button17.Badge = "";
$rootScope.Button17.Icon = "glyphicon glyphicon-repeat";
$rootScope.Button17.Text = "Batal";
$rootScope.Button17.Class = "btn btn-danger btn-lg ";
$rootScope.Button17.Disabled = "";

$rootScope.Label7 = {};
$rootScope.Label7.Hidden = "";
$rootScope.Label7.Class = "";
$rootScope.Label7.Text = "Isi Tugas";
$rootScope.Label7.Input = "Textarea3";
$rootScope.Label7.Title = "";
$rootScope.Label7.TooltipText = "";
$rootScope.Label7.TooltipPos = "top";
$rootScope.Label7.PopoverText = "";
$rootScope.Label7.PopoverEvent = "mouseenter";
$rootScope.Label7.PopoverTitle = "";
$rootScope.Label7.PopoverPos = "top";

$rootScope.Label10 = {};
$rootScope.Label10.Hidden = "";
$rootScope.Label10.Class = "";
$rootScope.Label10.Text = "Berkas";
$rootScope.Label10.Input = "Textarea3";
$rootScope.Label10.Title = "";
$rootScope.Label10.TooltipText = "";
$rootScope.Label10.TooltipPos = "top";
$rootScope.Label10.PopoverText = "";
$rootScope.Label10.PopoverEvent = "mouseenter";
$rootScope.Label10.PopoverTitle = "";
$rootScope.Label10.PopoverPos = "top";

$rootScope.P_TugasMahasiswaIsi = {};
$rootScope.P_TugasMahasiswaIsi.Hidden = "";
$rootScope.P_TugasMahasiswaIsi.Value = "";
$rootScope.P_TugasMahasiswaIsi.Title = "";
$rootScope.P_TugasMahasiswaIsi.TabIndex = 7;
$rootScope.P_TugasMahasiswaIsi.TooltipText = "";
$rootScope.P_TugasMahasiswaIsi.TooltipPos = "top";
$rootScope.P_TugasMahasiswaIsi.PopoverText = "";
$rootScope.P_TugasMahasiswaIsi.PopoverEvent = "mouseenter";
$rootScope.P_TugasMahasiswaIsi.PopoverTitle = "";
$rootScope.P_TugasMahasiswaIsi.PopoverPos = "top";
$rootScope.P_TugasMahasiswaIsi.PlaceHolder = "isikan teks materi...";
$rootScope.P_TugasMahasiswaIsi.Class = "form-control input-sm ";
$rootScope.P_TugasMahasiswaIsi.Disabled = "";
$rootScope.P_TugasMahasiswaIsi.Required = "";
$rootScope.P_TugasMahasiswaIsi.ReadOnly = "";

$rootScope.P_TugasMahasiswaBerkas = {};
$rootScope.P_TugasMahasiswaBerkas.Hidden = "";
$rootScope.P_TugasMahasiswaBerkas.Url = "";
$rootScope.P_TugasMahasiswaBerkas.Data = "";
$rootScope.P_TugasMahasiswaBerkas.Value = null;
$rootScope.P_TugasMahasiswaBerkas.Title = "";
$rootScope.P_TugasMahasiswaBerkas.Accept = "";
$rootScope.P_TugasMahasiswaBerkas.TabIndex = 3;
$rootScope.P_TugasMahasiswaBerkas.TooltipText = "";
$rootScope.P_TugasMahasiswaBerkas.TooltipPos = "top";
$rootScope.P_TugasMahasiswaBerkas.PopoverText = "";
$rootScope.P_TugasMahasiswaBerkas.PopoverEvent = "mouseenter";
$rootScope.P_TugasMahasiswaBerkas.PopoverTitle = "";
$rootScope.P_TugasMahasiswaBerkas.PopoverPos = "top";
$rootScope.P_TugasMahasiswaBerkas.Class = "form-control input-sm ";
$rootScope.P_TugasMahasiswaBerkas.Disabled = "";
$rootScope.P_TugasMahasiswaBerkas.Required = "";

$rootScope.ID_Tugas = {};
$rootScope.ID_Tugas.Hidden = "true";
$rootScope.ID_Tugas.Value = "";
$rootScope.ID_Tugas.Title = "";
$rootScope.ID_Tugas.TabIndex = -1;
$rootScope.ID_Tugas.TooltipText = "";
$rootScope.ID_Tugas.TooltipPos = "top";
$rootScope.ID_Tugas.PopoverText = "";
$rootScope.ID_Tugas.PopoverEvent = "mouseenter";
$rootScope.ID_Tugas.PopoverTitle = "";
$rootScope.ID_Tugas.PopoverPos = "top";
$rootScope.ID_Tugas.PlaceHolder = "";
$rootScope.ID_Tugas.Class = "form-control input-sm ";
$rootScope.ID_Tugas.Disabled = "";
$rootScope.ID_Tugas.Required = "";
$rootScope.ID_Tugas.ReadOnly = "";

$rootScope.TugasMahasiswaClient = {};
$rootScope.TugasMahasiswaClient.Status = 0;
$rootScope.TugasMahasiswaClient.StatusText = "";
$rootScope.TugasMahasiswaClient.Response = "";
$rootScope.TugasMahasiswaClient.Request = {};
$rootScope.TugasMahasiswaClient.Request.data = {};
$rootScope.TugasMahasiswaClient.Request.headers = {};
$rootScope.TugasMahasiswaClient.Request.url = "";
$rootScope.TugasMahasiswaClient.Request.method = "POST";

$rootScope.ReportNilaiTugas = {};
$rootScope.ReportNilaiTugas.Hidden = "";
$rootScope.ReportNilaiTugas.Url = "";
$rootScope.ReportNilaiTugas.Loading = "Loading data nilai...";
$rootScope.ReportNilaiTugas.Class = "";
$rootScope.ReportNilaiTugas.Order = "";
$rootScope.ReportNilaiTugas.Query = "";
$rootScope.ReportNilaiTugas.Record = null;
$rootScope.ReportNilaiTugas.Data = "";

$rootScope.Input12 = {};
$rootScope.Input12.Hidden = "";
$rootScope.Input12.Value = "";
$rootScope.Input12.Title = "";
$rootScope.Input12.TabIndex = -1;
$rootScope.Input12.TooltipText = "";
$rootScope.Input12.TooltipPos = "top";
$rootScope.Input12.PopoverText = "";
$rootScope.Input12.PopoverEvent = "mouseenter";
$rootScope.Input12.PopoverTitle = "";
$rootScope.Input12.PopoverPos = "top";
$rootScope.Input12.PlaceHolder = "pencarian data";
$rootScope.Input12.Class = "form-control input-sm ";
$rootScope.Input12.Disabled = "";
$rootScope.Input12.Required = "";
$rootScope.Input12.ReadOnly = "";

$rootScope.HtmlContent44 = {};
$rootScope.HtmlContent44.Hidden = "true";
$rootScope.HtmlContent44.Class = "";
$rootScope.HtmlContent44.Title = "";
$rootScope.HtmlContent44.TooltipText = "";
$rootScope.HtmlContent44.TooltipPos = "top";
$rootScope.HtmlContent44.PopoverText = "";
$rootScope.HtmlContent44.PopoverEvent = "mouseenter";
$rootScope.HtmlContent44.PopoverTitle = "";
$rootScope.HtmlContent44.PopoverPos = "top";

$rootScope.HtmlContent45 = {};
$rootScope.HtmlContent45.Hidden = "";
$rootScope.HtmlContent45.Class = "";
$rootScope.HtmlContent45.Title = "";
$rootScope.HtmlContent45.TooltipText = "";
$rootScope.HtmlContent45.TooltipPos = "top";
$rootScope.HtmlContent45.PopoverText = "";
$rootScope.HtmlContent45.PopoverEvent = "mouseenter";
$rootScope.HtmlContent45.PopoverTitle = "";
$rootScope.HtmlContent45.PopoverPos = "right";

$rootScope.HtmlContent46 = {};
$rootScope.HtmlContent46.Hidden = "";
$rootScope.HtmlContent46.Class = "";
$rootScope.HtmlContent46.Title = "";
$rootScope.HtmlContent46.TooltipText = "";
$rootScope.HtmlContent46.TooltipPos = "top";
$rootScope.HtmlContent46.PopoverText = "";
$rootScope.HtmlContent46.PopoverEvent = "mouseenter";
$rootScope.HtmlContent46.PopoverTitle = "";
$rootScope.HtmlContent46.PopoverPos = "right";

$rootScope.ReportNilaiTugasLoader = {};
$rootScope.ReportNilaiTugasLoader.Hidden = "true";
$rootScope.ReportNilaiTugasLoader.Class = "";
$rootScope.ReportNilaiTugasLoader.Title = "";
$rootScope.ReportNilaiTugasLoader.TooltipText = "";
$rootScope.ReportNilaiTugasLoader.TooltipPos = "top";
$rootScope.ReportNilaiTugasLoader.PopoverText = "";
$rootScope.ReportNilaiTugasLoader.PopoverEvent = "mouseenter";
$rootScope.ReportNilaiTugasLoader.PopoverTitle = "";
$rootScope.ReportNilaiTugasLoader.PopoverPos = "top";

$rootScope.NilaiTugasMahasiswaCLient = {};
$rootScope.NilaiTugasMahasiswaCLient.Status = 0;
$rootScope.NilaiTugasMahasiswaCLient.StatusText = "";
$rootScope.NilaiTugasMahasiswaCLient.Response = "";
$rootScope.NilaiTugasMahasiswaCLient.Request = {};
$rootScope.NilaiTugasMahasiswaCLient.Request.data = {};
$rootScope.NilaiTugasMahasiswaCLient.Request.headers = {};
$rootScope.NilaiTugasMahasiswaCLient.Request.url = "";
$rootScope.NilaiTugasMahasiswaCLient.Request.method = "POST";

$rootScope.HtmlContent47 = {};
$rootScope.HtmlContent47.Hidden = "";
$rootScope.HtmlContent47.Class = "";
$rootScope.HtmlContent47.Title = "";
$rootScope.HtmlContent47.TooltipText = "";
$rootScope.HtmlContent47.TooltipPos = "top";
$rootScope.HtmlContent47.PopoverText = "";
$rootScope.HtmlContent47.PopoverEvent = "mouseenter";
$rootScope.HtmlContent47.PopoverTitle = "";
$rootScope.HtmlContent47.PopoverPos = "top";

$rootScope.Button18 = {};
$rootScope.Button18.Hidden = "";
$rootScope.Button18.Title = "";
$rootScope.Button18.TabIndex = -1;
$rootScope.Button18.TooltipText = "";
$rootScope.Button18.TooltipPos = "top";
$rootScope.Button18.PopoverText = "";
$rootScope.Button18.PopoverTitle = "";
$rootScope.Button18.PopoverEvent = "mouseenter";
$rootScope.Button18.PopoverPos = "top";
$rootScope.Button18.Badge = "";
$rootScope.Button18.Icon = "glyphicon glyphicon-hdd";
$rootScope.Button18.Text = "Download Berkas";
$rootScope.Button18.Class = "btn btn-primary btn-md ";
$rootScope.Button18.Disabled = "";

$rootScope.HtmlContent48 = {};
$rootScope.HtmlContent48.Hidden = "";
$rootScope.HtmlContent48.Class = "";
$rootScope.HtmlContent48.Title = "";
$rootScope.HtmlContent48.TooltipText = "";
$rootScope.HtmlContent48.TooltipPos = "top";
$rootScope.HtmlContent48.PopoverText = "";
$rootScope.HtmlContent48.PopoverEvent = "mouseenter";
$rootScope.HtmlContent48.PopoverTitle = "";
$rootScope.HtmlContent48.PopoverPos = "top";

$rootScope.HtmlContent49 = {};
$rootScope.HtmlContent49.Hidden = "";
$rootScope.HtmlContent49.Class = "";
$rootScope.HtmlContent49.Title = "";
$rootScope.HtmlContent49.TooltipText = "";
$rootScope.HtmlContent49.TooltipPos = "top";
$rootScope.HtmlContent49.PopoverText = "";
$rootScope.HtmlContent49.PopoverEvent = "mouseenter";
$rootScope.HtmlContent49.PopoverTitle = "";
$rootScope.HtmlContent49.PopoverPos = "top";

$rootScope.Button19 = {};
$rootScope.Button19.Hidden = "";
$rootScope.Button19.Title = "";
$rootScope.Button19.TabIndex = -1;
$rootScope.Button19.TooltipText = "";
$rootScope.Button19.TooltipPos = "top";
$rootScope.Button19.PopoverText = "";
$rootScope.Button19.PopoverTitle = "";
$rootScope.Button19.PopoverEvent = "mouseenter";
$rootScope.Button19.PopoverPos = "top";
$rootScope.Button19.Badge = "";
$rootScope.Button19.Icon = "glyphicon glyphicon-hdd";
$rootScope.Button19.Text = "Download Berkas";
$rootScope.Button19.Class = "btn btn-primary btn-md ";
$rootScope.Button19.Disabled = "";

$rootScope.HtmlContent50 = {};
$rootScope.HtmlContent50.Hidden = "";
$rootScope.HtmlContent50.Class = "";
$rootScope.HtmlContent50.Title = "";
$rootScope.HtmlContent50.TooltipText = "";
$rootScope.HtmlContent50.TooltipPos = "top";
$rootScope.HtmlContent50.PopoverText = "";
$rootScope.HtmlContent50.PopoverEvent = "mouseenter";
$rootScope.HtmlContent50.PopoverTitle = "";
$rootScope.HtmlContent50.PopoverPos = "top";

$rootScope.Label11 = {};
$rootScope.Label11.Hidden = "";
$rootScope.Label11.Class = "";
$rootScope.Label11.Text = "Nilai Tugas";
$rootScope.Label11.Input = "Textarea3";
$rootScope.Label11.Title = "";
$rootScope.Label11.TooltipText = "";
$rootScope.Label11.TooltipPos = "top";
$rootScope.Label11.PopoverText = "";
$rootScope.Label11.PopoverEvent = "mouseenter";
$rootScope.Label11.PopoverTitle = "";
$rootScope.Label11.PopoverPos = "top";

$rootScope.Button20 = {};
$rootScope.Button20.Hidden = "";
$rootScope.Button20.Title = "";
$rootScope.Button20.TabIndex = 5;
$rootScope.Button20.TooltipText = "";
$rootScope.Button20.TooltipPos = "top";
$rootScope.Button20.PopoverText = "";
$rootScope.Button20.PopoverTitle = "";
$rootScope.Button20.PopoverEvent = "mouseenter";
$rootScope.Button20.PopoverPos = "top";
$rootScope.Button20.Badge = "";
$rootScope.Button20.Icon = "glyphicon glyphicon-save-file";
$rootScope.Button20.Text = "Simpan";
$rootScope.Button20.Class = "btn btn-warning btn-md ";
$rootScope.Button20.Disabled = "";

$rootScope.P_NilaiTugas = {};
$rootScope.P_NilaiTugas.Hidden = "";
$rootScope.P_NilaiTugas.Value = "";
$rootScope.P_NilaiTugas.Title = "";
$rootScope.P_NilaiTugas.TabIndex = -1;
$rootScope.P_NilaiTugas.TooltipText = "";
$rootScope.P_NilaiTugas.TooltipPos = "top";
$rootScope.P_NilaiTugas.PopoverText = "";
$rootScope.P_NilaiTugas.PopoverEvent = "mouseenter";
$rootScope.P_NilaiTugas.PopoverTitle = "";
$rootScope.P_NilaiTugas.PopoverPos = "top";
$rootScope.P_NilaiTugas.PlaceHolder = "";
$rootScope.P_NilaiTugas.Class = "form-control input-sm ";
$rootScope.P_NilaiTugas.Disabled = "";
$rootScope.P_NilaiTugas.Required = "";
$rootScope.P_NilaiTugas.ReadOnly = "";
    };

    return {
      init : function() {
        setControlVars();
      }
    };
  }
]);

window.App.Module.service
(
  'AppPluginsService',

  ['$rootScope',

  function($rootScope) {

    var setupPlugins = function() {
      Object.keys(window.App.Plugins).forEach(function(plugin) {
        if (angular.isFunction(window.App.Plugins[plugin])) {
          plugin = window.App.Plugins[plugin].call();
          if (angular.isFunction(plugin.PluginSetupEvent)) {
            plugin.PluginSetupEvent();
          }
          if (angular.isFunction(plugin.PluginDocumentReadyEvent)) {
            angular.element(window.document).ready(
             plugin.PluginDocumentReadyEvent);
          }
          if (angular.isUndefined(window.App.Cordova) &&
           angular.isFunction(plugin.PluginAppReadyEvent)) {
             document.addEventListener('deviceready',
              plugin.PluginAppReadyEvent, false);
          }
        }
      });
    };

    return {
      init : function() {
        setupPlugins();
      }
    };
  }
]);

window.App.Ctrls = angular.module('AppCtrls', []);

window.App.Ctrls.controller
(
  'AppCtrl',

  ['$scope', '$rootScope', '$location', '$uibModal', '$http', '$sce', '$window', '$document',
    'AppEventsService', 'AppGlobalsService', 'AppControlsService', 'AppPluginsService',

  function($scope, $rootScope, $location, $uibModal, $http, $sce, $window, $document,
   AppEventsService, AppGlobalsService, AppControlsService, AppPluginsService) {

    window.App.Scope = $scope;
    window.App.RootScope = $rootScope;

    AppEventsService.init();
    AppGlobalsService.init();
    AppControlsService.init();
    AppPluginsService.init();

    $scope.showView = function(viewName) {
      window.App.Modal.closeAll();
      $rootScope.App.DialogView = '';
      $location.path(viewName);
    };

    $scope.replaceView = function(viewName) {
      window.App.Modal.closeAll();
      $rootScope.App.DialogView = '';
      $location.path(viewName).replace();
    };

    $scope.showModalView = function(viewName, callback) {
      var
        execCallback = null,
        modal = window.App.Modal.insert(viewName);

      $rootScope.App.DialogView = viewName;

      modal.instance = $uibModal.open
      ({
        size: 'lg',
        scope: $scope,
        keyboard: false,
        backdrop: 'static',
        windowClass: 'dialogView',
        controller: viewName + 'Ctrl',
        templateUrl: 'app/views/' + viewName + '.html'
      });
      execCallback = function(modalResult) {
        window.App.Modal.removeCurrent();
        if (angular.isFunction(callback)) {
          callback(modalResult);
        }
      };
      modal.instance.result.then(
        function(modalResult){execCallback(modalResult);},
        function(modalResult){execCallback(modalResult);}
      );
    };

    $scope.closeModalView = function(modalResult) {
      var
        modal = window.App.Modal.currentInstance();

      $rootScope.App.DialogView = '';

      if (modal !== null) {
        window.App.Modal.currentInstance().close(modalResult);
        window.App.Modal.removeCurrent();
      }
    };

    $scope.loadVariables = function(text) {

      var
        setVar = function(name, value) {
          var
            newName = '',
            dotPos = name.indexOf('.');

          if (dotPos != -1) {
            newName = name.split('.');
            if (newName.length === 2) {
              $rootScope[newName[0].trim()][newName[1].trim()] = value;
            } else if (newName.length === 3) {
              // We support up to 3 levels here
              $rootScope[newName[0].trim()][newName[1].trim()][newName[2].trim()] = value;
            }
          } else {
            $rootScope[name] = value;
          }
        };

      var
        lineLen = 0,
        varName = '',
        varValue = '',
        isArray = false,
        text = text || '',
        separatorPos = -1;

      angular.forEach(text.split('\n'), function(value, key) {
        separatorPos = value.indexOf('=');
        if (separatorPos != -1) {
          varName = value.substr(0, separatorPos).trim();
          if (varName != '') {
            varValue = value.substr(separatorPos + 1, value.length).trim();
            isArray = varValue.substr(0, 1) == '|';
            if (!isArray) {
              setVar(varName, varValue);
            } else {
              setVar(varName, varValue.substr(1, varValue.length).split('|'));
            }
          }
        }
      });
    };

    $scope.alertBox = function(content, type) {
      var
        aType = type || 'info',
        modal = window.App.Modal.insert('builder/views/alertBox.html');

      modal.instance = $uibModal.open
      ({
        size: 'sm',
        scope: $scope,
        keyboard: true,
        controller: 'AppDialogsCtrl',
        templateUrl: 'builder/views/alertBox.html',
        resolve: {
          properties: function() {
            return {
              Type: aType,
              Content: content
            };
          }
        }
      });
      modal.instance.result.then(null, function() {
        window.App.Modal.removeCurrent();
      });
    };

    $scope.inputBox = function(header, buttons,
     inputVar, defaultVal, type, callback) {
      var
        execCallback = null,
        aType = type || 'info',
        aButtons = buttons || 'Ok|Cancel',
        modal = window.App.Modal.insert('builder/views/inputBox.html');

      $rootScope[inputVar] = defaultVal;

      modal.instance = $uibModal.open
      ({
        size: 'md',
        scope: $scope,
        keyboard: false,
        backdrop: 'static',
        controller: 'AppDialogsCtrl',
        templateUrl: 'builder/views/inputBox.html',
        resolve: {
          properties: function() {
            return {
              Type: aType,
              Header: header,
              Buttons: aButtons.split('|'),
              InputVar: $rootScope.inputVar
            };
          }
        }
      });
      execCallback = function(modalResult) {
        window.App.Modal.removeCurrent();
        if (angular.isFunction(callback)) {
          callback(modalResult, $rootScope[inputVar]);
        }
      };
      modal.instance.result.then(
        function(modalResult){execCallback(modalResult);},
        function(modalResult){execCallback(modalResult);}
      );
    };

    $scope.messageBox = function(header,
     content, buttons, type, callback) {
      var
        execCallback = null,
        aType = type || 'info',
        aButtons = buttons || 'Ok',
        modal = window.App.Modal.insert('builder/views/messageBox.html');

      modal.instance = $uibModal.open
      ({
        size: 'md',
        scope: $scope,
        keyboard: false,
        backdrop: 'static',
        controller: 'AppDialogsCtrl',
        templateUrl: 'builder/views/messageBox.html',
        resolve: {
          properties: function() {
            return {
              Type: aType,
              Header: header,
              Content: content,
              Buttons: aButtons.split('|')
            };
          }
        }
      });
      execCallback = function(modalResult) {
        window.App.Modal.removeCurrent();
        if (angular.isFunction(callback)) {
          callback(modalResult);
        }
      };
      modal.instance.result.then(
        function(modalResult){execCallback(modalResult);},
        function(modalResult){execCallback(modalResult);}
      );
    };

    $scope.alert = function(title, text) {
      if (window.App.Cordova) {
        window.alert(text);
      } else {
        navigator.notification.alert(
         text, null, title, null);
      }
    };

    $scope.confirm = function(title, text, callback) {
      if (window.App.Cordova) {
        callback(window.confirm(text));
      } else {
        navigator.notification.confirm
        (
          text,
          function(btnIndex) {
            callback(btnIndex === 1);
          },
          title,
          null
        );
      }
    };

    $scope.prompt = function(title, text, defaultVal, callback) {
      if (window.App.Cordova) {
        var
          result = window.prompt(text, defaultVal);
        callback(result !== null, result);
      } else {
        navigator.notification.prompt(
          text,
          function(result) {
            callback(result.buttonIndex === 1, result.input1);
          },
          title,
          null,
          defaultVal
        );
      }
    };

    $scope.beep = function(times) {
      if (window.App.Cordova) {
        window.App.Utils.playSound
        (
          'builder/sounds/beep/beep.mp3',
          'builder/sounds/beep/beep.ogg'
        );
      } else {
        navigator.notification.beep(times);
      }
    };

    $scope.vibrate = function(milliseconds) {
      if (window.App.Cordova) {
        var
          body = angular.element(document.body);
        body.addClass('animated shake');
        setTimeout(function() {
          body.removeClass('animated shake');
        }, milliseconds);
      } else {
        navigator.vibrate(milliseconds);
      }
    };

    $scope.setLocalOption = function(key, value) {
      window.localStorage.setItem(key, value);
    };

    $scope.getLocalOption = function(key) {
      return window.localStorage.getItem(key) || '';
    };

    $scope.removeLocalOption = function(key) {
      window.localStorage.removeItem(key);
    };

    $scope.clearLocalOptions = function() {
      window.localStorage.clear();
    };

    $scope.log = function(text, lineNum) {
      window.App.Debugger.log(text, lineNum);
    };

    $window.TriggerAppOrientationEvent = function() {
      $rootScope.OnAppOrientation();
      $rootScope.$apply();
    };

    $scope.idleStart = function(seconds) {

      $scope.idleStop();
      $rootScope.App.IdleIsIdling = false;

      if($rootScope.App._IdleSeconds != seconds) {
        $rootScope.App._IdleSeconds = seconds;
      }

      $document.on('mousemove mousedown mousewheel keydown scroll touchstart touchmove DOMMouseScroll', $scope._resetIdle);

      $rootScope.App.IdleIsRunning = true;

      $rootScope.App._IdleTimer = setTimeout(function() {
        $rootScope.App.IdleIsIdling = true;
        $rootScope.OnAppIdleStart();
        $scope.$apply();
      }, $rootScope.App._IdleSeconds * 1000);
    };

    $scope._resetIdle = function() {
      if($rootScope.App.IdleIsIdling) {
        $rootScope.OnAppIdleEnd();
        $rootScope.App.IdleIsIdling = false;
        $scope.$apply();
      }
      $scope.idleStart($rootScope.App._IdleSeconds);
    };

    $scope.idleStop = function() {
      $document.off('mousemove mousedown mousewheel keydown scroll touchstart touchmove DOMMouseScroll', $scope._resetIdle);
      clearTimeout($rootScope.App._IdleTimer);
      $rootScope.App.IdleIsRunning = false;
    };

    $scope.trustSrc = function(src) {
      return $sce.trustAsResourceUrl(src);
    };

    $scope.openWindow = function(url, showLocation) {
      var
        options = 'location=';

      if (showLocation) {
        options += 'yes';
      } else {
        options += 'no';
      }

      if (window.App.Cordova) {
        options += ', width=500, height=500, resizable=yes, scrollbars=yes';
      }

      return window.open(encodeURI(url), '_blank', options);
    };

    $scope.closeWindow = function(winRef) {
      if (angular.isObject(winRef) && angular.isFunction(winRef.close)) {
        winRef.close();
      }
    };

   
$scope.AppExit = function(Result)
{

$rootScope.ResultAsString = (angular.lowercase(Result.toString()) === "true") ? "true" : "false";

if (""+$rootScope.ResultAsString+"" ==  "true" ) {


window.navigator.app.exitApp();

} else {

}
};

$scope.DoShowMenu = function()
{

angular.element(document.getElementById("Container1")).css("transition", "1000ms");

angular.element(document.getElementById("Container1")).css("transform", "translateX(240px)");

angular.element(document.getElementById("Container2")).css("transition", "1000ms");

angular.element(document.getElementById("Container2")).css("transform", "translateX(240px)");
};

$scope.DoHideMenu = function()
{

angular.element(document.getElementById("Container1")).css("transform", "");

angular.element(document.getElementById("Container2")).css("transform", "");
};

$scope.DoLogOut = function(Result)
{

$rootScope.ResultAsString = (angular.lowercase(Result.toString()) === "true") ? "true" : "false";

if (""+$rootScope.ResultAsString+"" ==  "true" ) {

$scope.clearLocalOptions();

$scope.replaceView("Login");

} else {

}
};

$scope.DoSaveMateri = function(Result)
{

$rootScope.ResultAsString = (angular.lowercase(Result.toString()) === "true") ? "true" : "false";

$rootScope.MK = $scope.getLocalOption("MatkulPilih");

$rootScope.URL_SERVER = $scope.getLocalOption($rootScope.URL_SERVER);

$rootScope.ID_USER = $scope.getLocalOption($rootScope.ID_USER);

if (""+$rootScope.ResultAsString+"" ==  "true" ) {

if ($rootScope.BtnSimpanMateriDosen.Text ==  "Update" ) {

$rootScope.MateriDosenProgress.Hidden = "";

$rootScope.MatkulSimpan.Request.data = {};

$rootScope.MatkulSimpan.Request.url = $rootScope.URL_SERVER;

$rootScope.MatkulSimpan.Request.data.A = $rootScope.ID_USER;

$rootScope.MatkulSimpan.Request.data.B = $rootScope.MK;

$rootScope.MatkulSimpan.Request.data.C = $rootScope.P_MateriDosenIsi.Value;

$rootScope.MatkulSimpan.Request.data.D = ""+$rootScope.ReportMateri.Record.ID+"";

$rootScope.MatkulSimpan.Request.data.MYFILES = $rootScope.P_MateriDosenBerkas.Value;

$rootScope.MatkulSimpan.Request.data.type = "do_update_matkul";

$rootScope.MatkulSimpan.Request.data.ID = "Learning.API";

$rootScope.MatkulSimpan.Execute();

} else {

$rootScope.MateriDosenProgress.Hidden = "";

$rootScope.MatkulSimpan.Request.data = {};

$rootScope.MatkulSimpan.Request.url = $rootScope.URL_SERVER;

$rootScope.MatkulSimpan.Request.data.A = $rootScope.ID_USER;

$rootScope.MatkulSimpan.Request.data.B = $rootScope.MK;

$rootScope.MatkulSimpan.Request.data.C = $rootScope.P_MateriDosenIsi.Value;

$rootScope.MatkulSimpan.Request.data.MYFILES = $rootScope.P_MateriDosenBerkas.Value;

$rootScope.MatkulSimpan.Request.data.type = "save_matkul";

$rootScope.MatkulSimpan.Request.data.ID = "Learning.API";

$rootScope.MatkulSimpan.Execute();

}

} else {

$scope.replaceView("MateriDosenHome");

}
};

$scope.DoDeleteMateri = function(Result)
{

$rootScope.ResultAsString = (angular.lowercase(Result.toString()) === "true") ? "true" : "false";

$rootScope.MP = $scope.getLocalOption("MateriPilih");

$rootScope.URL_SERVER = $scope.getLocalOption($rootScope.URL_SERVER);

$rootScope.ID_USER = $scope.getLocalOption($rootScope.ID_USER);

if (""+$rootScope.ResultAsString+"" ==  "true" ) {

$rootScope.MateriDosenProgress.Hidden = "";

$rootScope.MasterDosenHapus.Request.data = {};

$rootScope.MasterDosenHapus.Request.url = $rootScope.URL_SERVER;

$rootScope.MasterDosenHapus.Request.data.A = $rootScope.ID_USER;

$rootScope.MasterDosenHapus.Request.data.B = $rootScope.MP;

$rootScope.MasterDosenHapus.Request.data.type = "do_remove_materi";

$rootScope.MasterDosenHapus.Request.data.ID = "Learning.API";

$rootScope.MasterDosenHapus.Execute();

} else {

}
};

$scope.DoSaveTugas = function(Result)
{

$rootScope.ResultAsString = (angular.lowercase(Result.toString()) === "true") ? "true" : "false";

$rootScope.URL_SERVER = $scope.getLocalOption($rootScope.URL_SERVER);

$rootScope.ID_USER = $scope.getLocalOption($rootScope.ID_USER);

if (""+$rootScope.ResultAsString+"" ==  "true" ) {

if ($rootScope.btnSimpanTugasDosen.Text ==  "Update" ) {

$rootScope.DosenTugasTambahPrgress.Hidden = "";

$rootScope.TugasClientSimpan.Request.data = {};

$rootScope.TugasClientSimpan.Request.url = $rootScope.URL_SERVER;

$rootScope.TugasClientSimpan.Request.data.A = $rootScope.ID_USER;

$rootScope.TugasClientSimpan.Request.data.B = $rootScope.KodeMateri.Value;

$rootScope.TugasClientSimpan.Request.data.C = $rootScope.P_IsiTugasDosen.Value;

$rootScope.TugasClientSimpan.Request.data.D = ""+$rootScope.ReportTugas.Record.ID+"";

$rootScope.TugasClientSimpan.Request.data.MYFILES = $rootScope.P_BerkasTugasDosen.Value;

$rootScope.TugasClientSimpan.Request.data.type = "do_update_tugas";

$rootScope.TugasClientSimpan.Request.data.ID = "Learning.API";

$rootScope.TugasClientSimpan.Execute();

} else {

$rootScope.DosenTugasTambahPrgress.Hidden = "";

$rootScope.TugasClientSimpan.Request.data = {};

$rootScope.TugasClientSimpan.Request.url = $rootScope.URL_SERVER;

$rootScope.TugasClientSimpan.Request.data.A = $rootScope.ID_USER;

$rootScope.TugasClientSimpan.Request.data.B = $rootScope.KodeMateri.Value;

$rootScope.TugasClientSimpan.Request.data.C = $rootScope.P_IsiTugasDosen.Value;

$rootScope.TugasClientSimpan.Request.data.MYFILES = $rootScope.P_BerkasTugasDosen.Value;

$rootScope.TugasClientSimpan.Request.data.type = "save_tugas";

$rootScope.TugasClientSimpan.Request.data.ID = "Learning.API";

$rootScope.TugasClientSimpan.Execute();

}

} else {

window.history.back();

}
};

$scope.DoDeleteTugas = function(Result)
{

$rootScope.ResultAsString = (angular.lowercase(Result.toString()) === "true") ? "true" : "false";

$rootScope.URL_SERVER = $scope.getLocalOption($rootScope.URL_SERVER);

$rootScope.ID_USER = $scope.getLocalOption($rootScope.ID_USER);

$rootScope.TP = $scope.getLocalOption("TugasPilih");

if (""+$rootScope.ResultAsString+"" ==  "true" ) {

$rootScope.TugasDosenLoader.Hidden = "";

$rootScope.DosenTugasHapus.Request.data = {};

$rootScope.DosenTugasHapus.Request.url = $rootScope.URL_SERVER;

$rootScope.DosenTugasHapus.Request.data.A = $rootScope.ID_USER;

$rootScope.DosenTugasHapus.Request.data.B = $rootScope.TP;

$rootScope.DosenTugasHapus.Request.data.type = "do_remove_tugas";

$rootScope.DosenTugasHapus.Request.data.ID = "Learning.API";

$rootScope.DosenTugasHapus.Execute();

} else {

}
};

$scope.DoSaveEnroll = function(Result)
{

$rootScope.ResultAsString = (angular.lowercase(Result.toString()) === "true") ? "true" : "false";

$rootScope.URL_SERVER = $scope.getLocalOption($rootScope.URL_SERVER);

$rootScope.ID_USER = $scope.getLocalOption($rootScope.ID_USER);

if (""+$rootScope.ResultAsString+"" ==  "true" ) {

$rootScope.MatkulEnrollSimpan.Request.data = {};

$rootScope.MatkulEnrollSimpan.Request.url = $rootScope.URL_SERVER;

$rootScope.MatkulEnrollSimpan.Request.data.A = $rootScope.ID_USER;

$rootScope.MatkulEnrollSimpan.Request.data.B = ""+$rootScope.ReportMatkulEnroll.Record.ID+"";

$rootScope.MatkulEnrollSimpan.Request.data.type = "save_enroll";

$rootScope.MatkulEnrollSimpan.Request.data.ID = "Learning.API";

$rootScope.MatkulEnrollSimpan.Execute();

} else {

}
};

$scope.DoDeleteEnroll = function(Result)
{

$rootScope.ResultAsString = (angular.lowercase(Result.toString()) === "true") ? "true" : "false";

$rootScope.URL_SERVER = $scope.getLocalOption($rootScope.URL_SERVER);

$rootScope.ID_USER = $scope.getLocalOption($rootScope.ID_USER);

$rootScope.EP = $scope.getLocalOption("EnrollPilih");

if (""+$rootScope.ResultAsString+"" ==  "true" ) {

$rootScope.ReportEnrollLoader.Hidden = "";

$rootScope.EnrollHapus.Request.data = {};

$rootScope.EnrollHapus.Request.url = $rootScope.URL_SERVER;

$rootScope.EnrollHapus.Request.data.A = $rootScope.ID_USER;

$rootScope.EnrollHapus.Request.data.B = $rootScope.EP;

$rootScope.EnrollHapus.Request.data.type = "do_remove_enroll";

$rootScope.EnrollHapus.Request.data.ID = "Learning.API";

$rootScope.EnrollHapus.Execute();

} else {

}
};

$scope.DoKirimTugas = function(Result)
{

$rootScope.ResultAsString = (angular.lowercase(Result.toString()) === "true") ? "true" : "false";

$rootScope.URL_SERVER = $scope.getLocalOption($rootScope.URL_SERVER);

$rootScope.ID_USER = $scope.getLocalOption($rootScope.ID_USER);

if (""+$rootScope.ResultAsString+"" ==  "true" ) {

$rootScope.SimpanTugasMahasiswa.Request.data = {};

$rootScope.SimpanTugasMahasiswa.Request.url = $rootScope.URL_SERVER;

$rootScope.SimpanTugasMahasiswa.Request.data.A = $rootScope.ID_USER;

$rootScope.SimpanTugasMahasiswa.Request.data.B = $rootScope.ID_Tugas.Value;

$rootScope.SimpanTugasMahasiswa.Request.data.C = $rootScope.P_TugasMahasiswaIsi.Value;

$rootScope.SimpanTugasMahasiswa.Request.data.MYFILES = $rootScope.P_TugasMahasiswaBerkas.Value;

$rootScope.P_TugasMahasiswaIsi.Value = "";

$rootScope.ID_Tugas.Value = "";

$rootScope.SimpanTugasMahasiswa.Request.data.type = "save_tugas_mahasiwa";

$rootScope.SimpanTugasMahasiswa.Request.data.ID = "Learning.API";

$rootScope.SimpanTugasMahasiswa.Execute();

} else {

}
};

$scope.DoSimpanNilai = function(Result)
{

$rootScope.ResultAsString = (angular.lowercase(Result.toString()) === "true") ? "true" : "false";

$rootScope.URL_SERVER = $scope.getLocalOption($rootScope.URL_SERVER);

$rootScope.ID_USER = $scope.getLocalOption($rootScope.ID_USER);

if (""+$rootScope.ResultAsString+"" ==  "true" ) {

$rootScope.NilaiTugasSimpan.Request.data = {};

$rootScope.NilaiTugasSimpan.Request.url = $rootScope.URL_SERVER;

$rootScope.NilaiTugasSimpan.Request.data.A = ""+$rootScope.ReportTugasMahasiswaDosen.Record.Nim+"";

$rootScope.NilaiTugasSimpan.Request.data.B = ""+$rootScope.ReportTugasMahasiswaDosen.Record.ID+"";

$rootScope.NilaiTugasSimpan.Request.data.C = $rootScope.P_NilaiTugas.Value;

$rootScope.NilaiTugasSimpan.Request.data.type = "save_nilai";

$rootScope.NilaiTugasSimpan.Request.data.ID = "Learning.API";

$rootScope.NilaiTugasSimpan.Execute();

} else {

}
};

}]);

window.App.Ctrls.controller
(
  'AppDialogsCtrl',

  ['$scope', 'properties',

  function($scope, properties) {
    $scope.Properties = properties;
  }
]);

window.App.Ctrls.controller
(
  'AppEventsCtrl',

  ['$scope', '$rootScope', '$location', '$uibModal', '$http', '$sce', '$window', '$document', 'blockUI', '$uibPosition',

  function($scope, $rootScope, $location, $uibModal, $http, $sce, $window, $document, blockUI, $uibPosition) {

    $rootScope.OnAppHide = function() {
      //__APP_HIDE_EVENT
    };
    
    $rootScope.OnAppShow = function() {
      //__APP_SHOW_EVENT
    };    

    $rootScope.OnAppReady = function() {
      //__APP_READY_EVENT
    };

    $rootScope.OnAppPause = function() {
      //__APP_PAUSE_EVENT
    };

    $rootScope.OnAppKeyUp = function() {
      //__APP_KEY_UP_EVENT
    };

    $rootScope.OnAppKeyDown = function() {
      //__APP_KEY_DOWN_EVENT
    };

    $rootScope.OnAppMouseUp = function() {
      //__APP_MOUSE_UP_EVENT
    };

    $rootScope.OnAppMouseDown = function() {
      //__APP_MOUSE_DOWN_EVENT
    };

    $rootScope.OnAppError = function() {
      //__APP_ERROR_EVENT
    };

    $rootScope.OnAppResize = function() {
      //__APP_RESIZE_EVENT
    };

    $rootScope.OnAppResume = function() {
      //__APP_RESUME_EVENT
    };

    $rootScope.OnAppOnline = function() {
      //__APP_ONLINE_EVENT
    };

    $rootScope.OnAppOffline = function() {
      //__APP_OFFLINE_EVENT
    };

    $rootScope.OnAppIdleEnd = function() {
      //__APP_IDLE_END_EVENT
    };

    $rootScope.OnAppIdleStart = function() {
      //__APP_IDLE_START_EVENT
    };

    $rootScope.OnAppBackButton = function() {
      //__APP_BACK_BUTTON_EVENT
    };

    $rootScope.OnAppMenuButton = function() {
      //__APP_MENU_BUTTON_EVENT
    };

    $rootScope.OnAppViewChange = function() {
      //__APP_VIEW_CHANGE_EVENT
    };

    $rootScope.OnAppOrientation = function() {
      //__APP_ORIENTATION_EVENT
    };

    $rootScope.OnAppVolumeUpButton = function() {
      //__APP_VOLUME_UP_EVENT
    };

    $rootScope.OnAppVolumeDownButton = function() {
      //__APP_VOLUME_DOWN_EVENT
    };
  }
]);

angular.element(window.document).ready(function() {
  angular.bootstrap(window.document, ['AppModule']);
});

App.Ctrls.controller("LoginCtrl", ["$scope", "$rootScope", "$sce", "$interval", "$http", "$uibPosition", "blockUI",

function($scope, $rootScope, $sce, $interval, $http, $position, blockUI) {

$rootScope.Login = {};

window.App.Login = {};

window.App.Login.Scope = $scope;

$rootScope.App.CurrentView = "Login";

angular.element(window.document).ready(function(event){
angular.element(document.querySelector("body")).addClass($rootScope.App.Theme.toLowerCase());
});

angular.element(window.document).ready(function(event){
$rootScope.Login.Event = event;

$scope.setLocalOption("URL_SERVER", "http://ffinderlearning.com/learnapi/inc/api.php");

$scope.setLocalOption("FILE_SERVER", "http://ffinderlearning.com/learnapi/inc/files/");

$rootScope.URL_SERVER = $scope.getLocalOption("URL_SERVER");

$rootScope.FILE_SERVER = $scope.getLocalOption("FILE_SERVER");

$rootScope.$apply();
});

$scope.SimpanClick = function($event) {
$rootScope.Simpan.Event = $event;

$rootScope.Progressbar2.Hidden = "true";

$rootScope.ErrorMsg = "";

$rootScope.P1_Val = window.App.Utils.strLen($rootScope.P1.Value);

$rootScope.P2_Val = window.App.Utils.strLen($rootScope.P2.Value);

if($rootScope.P1_Val == 0 || $rootScope.P2_Val == 0  ) {

$rootScope.ErrorMsg = "Maaf inputan tidak boleh kosong...!!!.";

}

if ($rootScope.ErrorMsg != "") {

$scope.alertBox($rootScope.ErrorMsg, "warning");

return null;

}

$rootScope.LoginClient.Request.url = $rootScope.URL_SERVER;

$rootScope.Progressbar2.Hidden = "";

$rootScope.LoginClient.Request.data = {};

$rootScope.LoginClient.Request.data.A = $rootScope.P1.Value;

$rootScope.LoginClient.Request.data.B = $rootScope.P2.Value;

$rootScope.LoginClient.Request.data.ID = "Learning.API";

$rootScope.LoginClient.Request.data.type = "do_login";

$rootScope.LoginClient.Execute();

};

$scope.BatalClick = function($event) {
$rootScope.Batal.Event = $event;

$scope.confirm("Please, confirm...", "Do you want to continue?", (("AppExit".length > 0) && angular.isFunction($scope["AppExit"])) ? $scope["AppExit"] : null);

};

$rootScope.LoginClient.Execute = function() {
  $http($rootScope.LoginClient.Request)
  .then(function(response) {
    $rootScope.LoginClient.Status = response.status;
    $rootScope.LoginClient.Response = response.data;
    $rootScope.LoginClient.StatusText = response.statusText;

$rootScope.HttpStatus = $rootScope.LoginClient.Status;

$rootScope.HttpResponse = $rootScope.LoginClient.Response;

$rootScope.HttpStatusText = $rootScope.LoginClient.StatusText;

$rootScope.Item = $rootScope.HttpResponse[0];

$rootScope.A = $rootScope.Item["A"];

$rootScope.B = $rootScope.Item["B"];

window.App.Debugger.log(""+$rootScope.Item.C+"", "info", 0);

window.App.Debugger.log(""+$rootScope.Item.D+"", "info", 0);

window.App.Debugger.log(""+$rootScope.Item.E+"", "info", 0);

$scope.clearLocalOptions();

$rootScope.P1.Value = "";

$rootScope.P2.Value = "";

$rootScope.Progressbar2.Hidden = "true";

if($rootScope.Item.B== 'FALSE') {

$scope.alertBox("Response : "+$rootScope.Item.A+"", "danger");

} else {

$scope.setLocalOption("ID_USER", ""+$rootScope.Item.B+"");

$scope.setLocalOption("USER", ""+$rootScope.Item.C+"");

$scope.setLocalOption("AKSES", ""+$rootScope.Item.D+"");

$scope.setLocalOption("NAMA", ""+$rootScope.Item.E+"");

$scope.setLocalOption($rootScope.URL_SERVER, "http://ffinderlearning.com/learnapi/inc/api.php");

$scope.setLocalOption($rootScope.FILE_SERVER, "http://ffinderlearning.com/learnapi/inc/files/");

$scope.replaceView("HomeDosen");

}

  },
  function(response) {
    $rootScope.LoginClient.Status = response.status;
    $rootScope.LoginClient.Response = response.data;
    $rootScope.LoginClient.StatusText = response.statusText;

$scope.alertBox("Proses koneksi keserver gagal, silahkan coba lagi!", "danger");

$rootScope.Progressbar2.Hidden = "true";

  });
};

}]);

App.Ctrls.controller("HomeDosenCtrl", ["$scope", "$rootScope", "$sce", "$interval", "$http", "$uibPosition", "blockUI",

function($scope, $rootScope, $sce, $interval, $http, $position, blockUI) {

$rootScope.HomeDosen = {};

window.App.HomeDosen = {};

window.App.HomeDosen.Scope = $scope;

$rootScope.App.CurrentView = "HomeDosen";

angular.element(window.document).ready(function(event){
$rootScope.HomeDosen.Event = event;

$rootScope.NAMA = $scope.getLocalOption("NAMA");

$rootScope.USER = $scope.getLocalOption("USER");

$rootScope.AKSES = $scope.getLocalOption("AKSES");

$rootScope.ID_USER = $scope.getLocalOption("ID_USER");

$rootScope.URL_SERVER = $scope.getLocalOption($rootScope.URL_SERVER);

$rootScope.FILE_SERVER = $scope.getLocalOption($rootScope.FILE_SERVER);

$rootScope.Container1.Hidden = "true";

$rootScope.Container2.Hidden = "true";

if ($rootScope.AKSES ==  "DOSEN" ) {

$rootScope.NIMNIP = "NIP";

$rootScope.Container1.Hidden = "";

} else {

$rootScope.NIMNIP = "NIM";

$rootScope.Container2.Hidden = "";

}

$rootScope.AKSES = angular.lowercase($rootScope.AKSES);

$rootScope.Fw = window.App.Utils.subStr($rootScope.AKSES, 0, 1);

$rootScope.Fw = angular.uppercase(""+$rootScope.Fw+"");

$rootScope.Fe = window.App.Utils.subStr($rootScope.AKSES, 1, 15);

$rootScope.AKSES = ""+$rootScope.Fw+""+$rootScope.Fe+"";

window.App.Debugger.log("Cek Param "+$rootScope.ID_USER+" "+$rootScope.NAMA+" "+$rootScope.USER+"  "+$rootScope.URL_SERVER+"", "info", 0);

angular.element(document.getElementById("Container1")).css("top", 0);

angular.element(document.getElementById("Container1")).css("width", "240px");

angular.element(document.getElementById("Container1")).css("left", "-240px");

angular.element(document.getElementById("Container2")).css("top", 0);

angular.element(document.getElementById("Container2")).css("width", "240px");

angular.element(document.getElementById("Container2")).css("left", "-240px");

$rootScope.$apply();
});

$scope.HomeDosenSwipeleft = function($event) {
$rootScope.HomeDosen.Event = $event;

$scope.DoHideMenu();

};

$scope.HomeDosenSwiperight = function($event) {
$rootScope.HomeDosen.Event = $event;

$scope.DoShowMenu();

};

$scope.Container1Click = function($event) {
$rootScope.Container1.Event = $event;

$scope.DoHideMenu();

};

$rootScope.Menu1.ItemClick = function(index) {
  $rootScope.Menu1.ItemIndex = index;

$scope.setLocalOption($rootScope.ID_USER, $rootScope.B);

$scope.setLocalOption($rootScope.USER, ""+$rootScope.C+"");

$scope.setLocalOption($rootScope.AKSES, ""+$rootScope.D+"");

$scope.setLocalOption($rootScope.NAMA, ""+$rootScope.E+"");

$scope.setLocalOption($rootScope.URL_SERVER, "http://192.168.56.1/learnapi/inc/api.php");

if($rootScope.Menu1.ItemIndex==0) {

$scope.replaceView("MateriDosenHome");

}

if($rootScope.Menu1.ItemIndex==1) {

$scope.replaceView("TugasDosenHome");

}

if($rootScope.Menu1.ItemIndex==2) {

$scope.showModalView("NilaiTugasHome");

}

if($rootScope.Menu1.ItemIndex==3) {

$scope.confirm("Konfirmasi logout", "Anda yakin untuk logout ?", (("DoLogOut".length > 0) && angular.isFunction($scope["DoLogOut"])) ? $scope["DoLogOut"] : null);

}

};

$scope.htmlMenuClick = function($event) {
$rootScope.htmlMenu.Event = $event;

$scope.DoShowMenu();

};

$scope.Container2Click = function($event) {
$rootScope.Container2.Event = $event;

$scope.DoHideMenu();

};

$rootScope.Menu2.ItemClick = function(index) {
  $rootScope.Menu2.ItemIndex = index;

$scope.setLocalOption($rootScope.ID_USER, $rootScope.B);

$scope.setLocalOption($rootScope.USER, ""+$rootScope.C+"");

$scope.setLocalOption($rootScope.AKSES, ""+$rootScope.D+"");

$scope.setLocalOption($rootScope.NAMA, ""+$rootScope.E+"");

$scope.setLocalOption($rootScope.URL_SERVER, "http://192.168.56.1/learnapi/inc/api.php");

if($rootScope.Menu2.ItemIndex==0) {

$scope.replaceView("MahasiswaEnroll");

}

if($rootScope.Menu2.ItemIndex==1) {

$scope.replaceView("ViewMateriMahasiwa");

}

if($rootScope.Menu2.ItemIndex==2) {

$scope.replaceView("ViewTugasMahasisa");

}

if($rootScope.Menu2.ItemIndex==3) {

$scope.replaceView("ViewNilaiTugasMahasiswa");

}

if($rootScope.Menu2.ItemIndex==4) {

$scope.confirm("Konfirmasi logout", "Anda yakin untuk logout ?", (("DoLogOut".length > 0) && angular.isFunction($scope["DoLogOut"])) ? $scope["DoLogOut"] : null);

}

};

}]);

App.Ctrls.controller("MateriDosenHomeCtrl", ["$scope", "$rootScope", "$sce", "$interval", "$http", "$uibPosition", "blockUI",

function($scope, $rootScope, $sce, $interval, $http, $position, blockUI) {

$rootScope.MateriDosenHome = {};

window.App.MateriDosenHome = {};

window.App.MateriDosenHome.Scope = $scope;

$rootScope.App.CurrentView = "MateriDosenHome";

angular.element(window.document).ready(function(event){
$rootScope.MateriDosenHome.Event = event;

$rootScope.NAMA = $scope.getLocalOption($rootScope.NAMA);

$rootScope.USER = $scope.getLocalOption($rootScope.USER);

$rootScope.ID_USER = $scope.getLocalOption($rootScope.ID_USER);

$rootScope.URL_SERVER = $scope.getLocalOption($rootScope.URL_SERVER);

$rootScope.FILE_SERVER = $scope.getLocalOption($rootScope.FILE_SERVER);

window.App.Debugger.log("Cek Param "+$rootScope.ID_USER+" "+$rootScope.NAMA+" "+$rootScope.USER+"  "+$rootScope.URL_SERVER+" "+$rootScope.FILE_SERVER+"", "info", 0);

$rootScope.MateriDosenList.Request.data = {};

$rootScope.MateriDosenList.Request.url = $rootScope.URL_SERVER;

$rootScope.MateriDosenList.Request.data.type = "get_materi";

$rootScope.MateriDosenList.Request.data.A = $rootScope.ID_USER;

$rootScope.MateriDosenList.Request.data.ID = "Learning.API";

$rootScope.MateriDosenList.Execute();

$rootScope.MateriDosenListLoader.Hidden = "";

$rootScope.$apply();
});

$scope.ReportMateriRowClick = function($event, record) {
$rootScope.ReportMateri.Event = $event;
$rootScope.ReportMateri.Record = record;

$scope.setLocalOption("MateriPilih", ""+$rootScope.ReportMateri.Record.ID+"");

window.App.Debugger.log(""+$rootScope.ReportMateri.Record.ISI+"", "info", 0);

$scope.showModalView("MenuMateriDosen");

};

$rootScope.ReportMateri.GetData = function() {
if($rootScope.ReportMateri.Url == ""){return;}
$http.get($rootScope.ReportMateri.Url)
.then(function(response) {
$rootScope.ReportMateri.Status = response.status;
$rootScope.ReportMateri.Data = response.data;

},
function(response) {
$rootScope.ReportMateri.Status = response.status || "";
$rootScope.ReportMateri.Data = response.data || "";

if (""+$rootScope.NotesReport.Data+"" != "") {

$rootScope.LastError = ""+$rootScope.NotesReport.Data+"";

} else {

$rootScope.LastError = "We can't connect to the server.";

}

$scope.replaceView("Error");

});
};
$rootScope.$watch("ReportMateri.Url", function() {
  $rootScope.ReportMateri.GetData();
});

$scope.HtmlContent7Click = function($event) {
$rootScope.HtmlContent7.Event = $event;

$scope.DoShowMenu();

};

$scope.menTambahClick = function($event) {
$rootScope.menTambah.Event = $event;

$scope.replaceView("MateriDosenTambah");

$rootScope.BtnSimpanMateriDosen.Text = "Simpan";

};

$scope.menuBackClick = function($event) {
$rootScope.menuBack.Event = $event;

$scope.replaceView("HomeDosen");

};

$rootScope.MateriDosenList.Execute = function() {
  $http($rootScope.MateriDosenList.Request)
  .then(function(response) {
    $rootScope.MateriDosenList.Status = response.status;
    $rootScope.MateriDosenList.Response = response.data;
    $rootScope.MateriDosenList.StatusText = response.statusText;

$rootScope.MateriDosenListLoader.Hidden = "true";

$rootScope.ReportMateri.Data = [];

$rootScope.TotalRecords = $rootScope.MateriDosenList.Response.length;

$rootScope.I = 0;

for ($rootScope.I = 1; $rootScope.I <= $rootScope.TotalRecords; $rootScope.I++) {

$rootScope.Item = $rootScope.MateriDosenList.Response[$rootScope.I+-1];

$rootScope.Record = {};

$rootScope.Record["Nomer"] = $rootScope.I;

$rootScope.Record["Title"] = ""+$rootScope.Item.C+"";

$rootScope.Record["Description"] = ""+$rootScope.Item.F+".";

$rootScope.st = ""+$rootScope.Item.F+"";

$rootScope.st = window.App.Utils.subStr($rootScope.st, 0, 200);

$rootScope.Record["SDesc"] = ""+$rootScope.st+"..";

$rootScope.Record["Tanggal"] = ""+$rootScope.Item.H+".";

$rootScope.Record["ID"] = ""+$rootScope.Item.E+"";

$rootScope.Record["MK"] = ""+$rootScope.Item.B+"";

$rootScope.Record["ISI"] = ""+$rootScope.Item.F+"";

$rootScope.Record["D"] = ""+$rootScope.Item.D+"";

$rootScope.Record["E"] = ""+$rootScope.Item.E+"";

$rootScope.Record["F"] = ""+$rootScope.Item.F+"";

$rootScope.Record["G"] = ""+$rootScope.Item.G+"";

$rootScope.Record["H"] = ""+$rootScope.Item.H+"";

$rootScope.ReportMateri.Data.push($rootScope.Record);

}

  },
  function(response) {
    $rootScope.MateriDosenList.Status = response.status;
    $rootScope.MateriDosenList.Response = response.data;
    $rootScope.MateriDosenList.StatusText = response.statusText;

$rootScope.MateriDosenListLoader.Hidden = "true";

  });
};

$rootScope.MasterDosenHapus.Execute = function() {
  $http($rootScope.MasterDosenHapus.Request)
  .then(function(response) {
    $rootScope.MasterDosenHapus.Status = response.status;
    $rootScope.MasterDosenHapus.Response = response.data;
    $rootScope.MasterDosenHapus.StatusText = response.statusText;

$rootScope.Item = $rootScope.MasterDosenHapus.Response[0];

if($rootScope.Item.B== 'FALSE') {

$scope.alertBox("Response : "+$rootScope.Item.A+"", "danger");

} else {

$scope.alertBox("Response : "+$rootScope.Item.A+"", "success");

}

$rootScope.MateriDosenList.Request.data = {};

$rootScope.MateriDosenList.Request.url = $rootScope.URL_SERVER;

$rootScope.MateriDosenList.Request.data.type = "get_materi";

$rootScope.MateriDosenList.Request.data.A = $rootScope.ID_USER;

$rootScope.MateriDosenList.Request.data.ID = "Learning.API";

$rootScope.MateriDosenList.Execute();

$rootScope.MateriDosenListLoader.Hidden = "";

  },
  function(response) {
    $rootScope.MasterDosenHapus.Status = response.status;
    $rootScope.MasterDosenHapus.Response = response.data;
    $rootScope.MasterDosenHapus.StatusText = response.statusText;

$scope.alertBox("Proses penghapusan  gagal, cek koneksi internet", "danger");

  });
};

}]);

App.Ctrls.controller("MateriDosenTambahCtrl", ["$scope", "$rootScope", "$sce", "$interval", "$http", "$uibPosition", "blockUI",

function($scope, $rootScope, $sce, $interval, $http, $position, blockUI) {

$rootScope.MateriDosenTambah = {};

window.App.MateriDosenTambah = {};

window.App.MateriDosenTambah.Scope = $scope;

$rootScope.App.CurrentView = "MateriDosenTambah";

angular.element(window.document).ready(function(event){
$rootScope.MateriDosenTambah.Event = event;

$rootScope.NAMA = $scope.getLocalOption($rootScope.NAMA);

$rootScope.USER = $scope.getLocalOption($rootScope.USER);

$rootScope.ID_USER = $scope.getLocalOption($rootScope.ID_USER);

$rootScope.URL_SERVER = $scope.getLocalOption($rootScope.URL_SERVER);

$rootScope.FILE_SERVER = $scope.getLocalOption($rootScope.FILE_SERVER);

window.App.Debugger.log("Cek Param "+$rootScope.ID_USER+" "+$rootScope.NAMA+" "+$rootScope.USER+"  "+$rootScope.URL_SERVER+"", "info", 0);

$rootScope.MatkulLoader.Hidden = "";

$rootScope.MatkulClient.Request.data = {};

$rootScope.MatkulClient.Request.url = $rootScope.URL_SERVER;

$rootScope.MatkulClient.Request.data.A = "2";

$rootScope.MatkulClient.Request.data.type = "get_matkul";

$rootScope.MatkulClient.Request.data.ID = "Learning.API";

$rootScope.MatkulClient.Execute();

$rootScope.BtnSimpanMateriDosen.Hidden = "true";

$rootScope.$apply();
});

$scope.BtnSimpanMateriDosenClick = function($event) {
$rootScope.BtnSimpanMateriDosen.Event = $event;

if ($rootScope.P_MateriDosenIsi.Value == "") {

$scope.alertBox("Maaf inputan tidak boleh ada yang kosong", "danger");

return null;

} else {

}

$rootScope.CurrentUnit = $rootScope.P_MateriDosenMatkul.Items[$rootScope.P_MateriDosenMatkul.ItemIndex];

$scope.setLocalOption("MatkulPilih", $rootScope.CurrentUnit);

$scope.confirm("Konfimasi", "Yakin untuk menyimpan data ?", (("DoSaveMateri".length > 0) && angular.isFunction($scope["DoSaveMateri"])) ? $scope["DoSaveMateri"] : null);

};
angular.element(document.getElementById("P_MateriDosenBerkas")).on("change", function(event){
  $rootScope.P_MateriDosenBerkas.Url = URL.createObjectURL(event.target.files[0]);
});

$rootScope.MatkulClient.Execute = function() {
  $http($rootScope.MatkulClient.Request)
  .then(function(response) {
    $rootScope.MatkulClient.Status = response.status;
    $rootScope.MatkulClient.Response = response.data;
    $rootScope.MatkulClient.StatusText = response.statusText;

$rootScope.ItemMatkul = [];

$rootScope.TotalRecords = $rootScope.MatkulClient.Response.length;

$rootScope.I = 0;

for ($rootScope.I = 0; $rootScope.I <= $rootScope.TotalRecords+-1; $rootScope.I++) {

$rootScope.Item = $rootScope.MatkulClient.Response[$rootScope.I];

$rootScope.ItemMatkul.push(""+$rootScope.Item.B+":"+$rootScope.Item.C+" ");

}

$rootScope.P_MateriDosenMatkul.Items = $rootScope.ItemMatkul;

$rootScope.MatkulLoader.Hidden = "true";

$rootScope.BtnSimpanMateriDosen.Hidden = "";

  },
  function(response) {
    $rootScope.MatkulClient.Status = response.status;
    $rootScope.MatkulClient.Response = response.data;
    $rootScope.MatkulClient.StatusText = response.statusText;

$scope.alertBox("Erorr Load data matakuliah..", "danger");

$rootScope.MatkulLoader.Hidden = "true";

$rootScope.BtnSimpanMateriDosen.Hidden = "true";

  });
};

$scope.btnBatalMateriDosenClick = function($event) {
$rootScope.btnBatalMateriDosen.Event = $event;

$scope.replaceView("MateriDosenHome");

};

$rootScope.MatkulSimpan.Execute = function() {
  $http($rootScope.MatkulSimpan.Request)
  .then(function(response) {
    $rootScope.MatkulSimpan.Status = response.status;
    $rootScope.MatkulSimpan.Response = response.data;
    $rootScope.MatkulSimpan.StatusText = response.statusText;

$rootScope.Item = $rootScope.MatkulSimpan.Response[0];

if($rootScope.Item.B== 'FALSE') {

$scope.alertBox("Response : "+$rootScope.Item.A+"", "danger");

} else {

$scope.alertBox("Response : "+$rootScope.Item.A+"", "success");

}

$rootScope.MateriDosenProgress.Hidden = "true";

$rootScope.P_MateriDosenIsi.Value = "";

$rootScope.P_MateriDosenBerkas.Value = "";

$scope.replaceView("MateriDosenHome");

  },
  function(response) {
    $rootScope.MatkulSimpan.Status = response.status;
    $rootScope.MatkulSimpan.Response = response.data;
    $rootScope.MatkulSimpan.StatusText = response.statusText;

$rootScope.MateriDosenProgress.Hidden = "true";

$scope.alertBox("Proses penyimpanan gagal, cek koneksi internet", "danger");

  });
};

}]);

App.Ctrls.controller("MahasiswaEnrollCtrl", ["$scope", "$rootScope", "$sce", "$interval", "$http", "$uibPosition", "blockUI",

function($scope, $rootScope, $sce, $interval, $http, $position, blockUI) {

$rootScope.MahasiswaEnroll = {};

window.App.MahasiswaEnroll = {};

window.App.MahasiswaEnroll.Scope = $scope;

$rootScope.App.CurrentView = "MahasiswaEnroll";

angular.element(window.document).ready(function(event){
$rootScope.MahasiswaEnroll.Event = event;

$rootScope.NAMA = $scope.getLocalOption($rootScope.NAMA);

$rootScope.USER = $scope.getLocalOption($rootScope.USER);

$rootScope.ID_USER = $scope.getLocalOption($rootScope.ID_USER);

$rootScope.URL_SERVER = $scope.getLocalOption($rootScope.URL_SERVER);

$rootScope.FILE_SERVER = $scope.getLocalOption($rootScope.FILE_SERVER);

window.App.Debugger.log("Cek Param "+$rootScope.ID_USER+" "+$rootScope.NAMA+" "+$rootScope.USER+"  "+$rootScope.URL_SERVER+" "+$rootScope.FILE_SERVER+"", "info", 0);

$rootScope.EnrollClient.Request.data = {};

$rootScope.EnrollClient.Request.url = $rootScope.URL_SERVER;

$rootScope.EnrollClient.Request.data.type = "get_enroll";

$rootScope.EnrollClient.Request.data.A = $rootScope.ID_USER;

$rootScope.EnrollClient.Request.data.ID = "Learning.API";

$rootScope.EnrollClient.Execute();

$rootScope.ReportEnrollLoader.Hidden = "";

$rootScope.$apply();
});

$scope.ReporteEnrollRowClick = function($event, record) {
$rootScope.ReporteEnroll.Event = $event;
$rootScope.ReporteEnroll.Record = record;

$scope.setLocalOption("EnrollPilih", ""+$rootScope.ReporteEnroll.Record.MK+"");

$scope.showModalView("MenuEnroll");

};

$rootScope.ReporteEnroll.GetData = function() {
if($rootScope.ReporteEnroll.Url == ""){return;}
$http.get($rootScope.ReporteEnroll.Url)
.then(function(response) {
$rootScope.ReporteEnroll.Status = response.status;
$rootScope.ReporteEnroll.Data = response.data;

},
function(response) {
$rootScope.ReporteEnroll.Status = response.status || "";
$rootScope.ReporteEnroll.Data = response.data || "";

if (""+$rootScope.NotesReport.Data+"" != "") {

$rootScope.LastError = ""+$rootScope.NotesReport.Data+"";

} else {

$rootScope.LastError = "We can't connect to the server.";

}

$scope.replaceView("Error");

});
};
$rootScope.$watch("ReporteEnroll.Url", function() {
  $rootScope.ReporteEnroll.GetData();
});

$scope.HtmlContent26Click = function($event) {
$rootScope.HtmlContent26.Event = $event;

$scope.DoShowMenu();

};

$scope.HtmlContent28Click = function($event) {
$rootScope.HtmlContent28.Event = $event;

$scope.showModalView("ListMatkulEnroll");

};

$scope.HtmlContent29Click = function($event) {
$rootScope.HtmlContent29.Event = $event;

$scope.replaceView("HomeDosen");

};

$rootScope.EnrollClient.Execute = function() {
  $http($rootScope.EnrollClient.Request)
  .then(function(response) {
    $rootScope.EnrollClient.Status = response.status;
    $rootScope.EnrollClient.Response = response.data;
    $rootScope.EnrollClient.StatusText = response.statusText;

$rootScope.ReportEnrollLoader.Hidden = "true";

$rootScope.ReporteEnroll.Data = [];

$rootScope.TotalRecords = $rootScope.EnrollClient.Response.length;

$rootScope.I = 0;

for ($rootScope.I = 1; $rootScope.I <= $rootScope.TotalRecords; $rootScope.I++) {

$rootScope.Item = $rootScope.EnrollClient.Response[$rootScope.I+-1];

if (""+$rootScope.Item.B+"" ==  "FALSE" ) {

$rootScope.ReporteEnroll.Loading = "Data tidak ditemukan";

return null;

}

$rootScope.Record = {};

$rootScope.Record["Nomer"] = $rootScope.I;

$rootScope.Record["Title"] = ""+$rootScope.Item.D+"";

$rootScope.Record["NIP"] = ""+$rootScope.Item.F+"";

$rootScope.Record["Nama"] = ""+$rootScope.Item.G+"";

$rootScope.Record["ID"] = ""+$rootScope.Item.B+"";

$rootScope.Record["MK"] = ""+$rootScope.Item.C+"";

$rootScope.Record["ISI"] = ""+$rootScope.Item.F+"";

$rootScope.ReporteEnroll.Data.push($rootScope.Record);

}

  },
  function(response) {
    $rootScope.EnrollClient.Status = response.status;
    $rootScope.EnrollClient.Response = response.data;
    $rootScope.EnrollClient.StatusText = response.statusText;

  });
};

$rootScope.MatkulEnrollSimpan.Execute = function() {
  $http($rootScope.MatkulEnrollSimpan.Request)
  .then(function(response) {
    $rootScope.MatkulEnrollSimpan.Status = response.status;
    $rootScope.MatkulEnrollSimpan.Response = response.data;
    $rootScope.MatkulEnrollSimpan.StatusText = response.statusText;

$rootScope.Item = $rootScope.MatkulEnrollSimpan.Response[0];

if($rootScope.Item.B== 'FALSE') {

$scope.alertBox("Response : "+$rootScope.Item.A+"", "danger");

} else {

$scope.alertBox("Response : "+$rootScope.Item.A+"", "success");

}

$rootScope.EnrollClient.Request.data = {};

$rootScope.EnrollClient.Request.url = $rootScope.URL_SERVER;

$rootScope.EnrollClient.Request.data.type = "get_enroll";

$rootScope.EnrollClient.Request.data.A = $rootScope.ID_USER;

$rootScope.EnrollClient.Request.data.ID = "Learning.API";

$rootScope.EnrollClient.Execute();

$rootScope.ReportEnrollLoader.Hidden = "";

  },
  function(response) {
    $rootScope.MatkulEnrollSimpan.Status = response.status;
    $rootScope.MatkulEnrollSimpan.Response = response.data;
    $rootScope.MatkulEnrollSimpan.StatusText = response.statusText;

$rootScope.ReportEnrollLoader.Hidden = "true";

$scope.closeModalView();

  });
};

$rootScope.EnrollHapus.Execute = function() {
  $http($rootScope.EnrollHapus.Request)
  .then(function(response) {
    $rootScope.EnrollHapus.Status = response.status;
    $rootScope.EnrollHapus.Response = response.data;
    $rootScope.EnrollHapus.StatusText = response.statusText;

$rootScope.Item = $rootScope.EnrollHapus.Response[0];

if($rootScope.Item.B== 'FALSE') {

$scope.alertBox("Response : "+$rootScope.Item.A+"", "danger");

} else {

$scope.alertBox("Response : "+$rootScope.Item.A+"", "success");

}

$rootScope.EnrollClient.Request.data = {};

$rootScope.EnrollClient.Request.url = $rootScope.URL_SERVER;

$rootScope.EnrollClient.Request.data.type = "get_enroll";

$rootScope.EnrollClient.Request.data.A = $rootScope.ID_USER;

$rootScope.EnrollClient.Request.data.ID = "Learning.API";

$rootScope.EnrollClient.Execute();

$rootScope.ReportEnrollLoader.Hidden = "";

  },
  function(response) {
    $rootScope.EnrollHapus.Status = response.status;
    $rootScope.EnrollHapus.Response = response.data;
    $rootScope.EnrollHapus.StatusText = response.statusText;

$rootScope.ReportEnrollLoader.Hidden = "true";

  });
};

}]);

App.Ctrls.controller("DetailMateriDosenCtrl", ["$scope", "$rootScope", "$sce", "$interval", "$http", "$uibPosition", "blockUI",

function($scope, $rootScope, $sce, $interval, $http, $position, blockUI) {

$rootScope.DetailMateriDosen = {};

window.App.DetailMateriDosen = {};

window.App.DetailMateriDosen.Scope = $scope;

$rootScope.App.CurrentView = "DetailMateriDosen";

angular.element(window.document).ready(function(event){
$rootScope.DetailMateriDosen.Event = event;

$rootScope.FILE_SERVER = $scope.getLocalOption($rootScope.FILE_SERVER);

window.App.Debugger.log("Cek Param "+$rootScope.ID_USER+" "+$rootScope.NAMA+" "+$rootScope.USER+"  "+$rootScope.URL_SERVER+" "+$rootScope.FILE_SERVER+"", "info", 0);

$rootScope.$apply();
});

$scope.Button4Click = function($event) {
$rootScope.Button4.Event = $event;

$scope.openWindow(""+$rootScope.FILE_SERVER+""+$rootScope.ReportMateri.Record.G+"", "");

};

$scope.HtmlContent6Click = function($event) {
$rootScope.HtmlContent6.Event = $event;

window.history.back();

};

}]);

App.Ctrls.controller("MenuMateriDosenCtrl", ["$scope", "$rootScope", "$sce", "$interval", "$http", "$uibPosition", "blockUI",

function($scope, $rootScope, $sce, $interval, $http, $position, blockUI) {

$rootScope.MenuMateriDosen = {};

window.App.MenuMateriDosen = {};

window.App.MenuMateriDosen.Scope = $scope;

$rootScope.App.CurrentView = "MenuMateriDosen";

$scope.Button5Click = function($event) {
$rootScope.Button5.Event = $event;

$scope.closeModalView();

$scope.replaceView("MateriDosenTambah");

$rootScope.BtnSimpanMateriDosen.Text = "Update";

$rootScope.P_MateriDosenIsi.Value = ""+$rootScope.ReportMateri.Record.ISI+"";

$rootScope.P_MateriDosenBerkas.Value = ""+$rootScope.ReportMateri.Record.ISI+"";

};

$scope.Button6Click = function($event) {
$rootScope.Button6.Event = $event;

$scope.closeModalView();

$scope.confirm("Konfimasi", "Yakin untuk menghapus data ?", (("DoDeleteMateri".length > 0) && angular.isFunction($scope["DoDeleteMateri"])) ? $scope["DoDeleteMateri"] : null);

};

$scope.Button7Click = function($event) {
$rootScope.Button7.Event = $event;

$scope.showView("DetailMateriDosen");

};

$scope.Button8Click = function($event) {
$rootScope.Button8.Event = $event;

$scope.closeModalView();

$scope.showView("DosenTugasTambah");

$rootScope.KodeMateri.Value = ""+$rootScope.ReportMateri.Record.ID+"";

};

$scope.HtmlContent9Click = function($event) {
$rootScope.HtmlContent9.Event = $event;

$scope.closeModalView();

};

}]);

App.Ctrls.controller("MenuTugasDosenCtrl", ["$scope", "$rootScope", "$sce", "$interval", "$http", "$uibPosition", "blockUI",

function($scope, $rootScope, $sce, $interval, $http, $position, blockUI) {

$rootScope.MenuTugasDosen = {};

window.App.MenuTugasDosen = {};

window.App.MenuTugasDosen.Scope = $scope;

$rootScope.App.CurrentView = "MenuTugasDosen";

$scope.Button1Click = function($event) {
$rootScope.Button1.Event = $event;

$scope.closeModalView();

$scope.showView("DosenTugasTambah");

$rootScope.btnSimpanTugasDosen.Text = "Update";

$rootScope.KodeMateri.Value = ""+$rootScope.ReportTugas.Record.MT+"";

$rootScope.P_IsiTugasDosen.Value = ""+$rootScope.ReportTugas.Record.ISI+"";

$rootScope.P_BerkasTugasDosen.Value = ""+$rootScope.ReportTugas.Record.ISI+"";

};

$scope.Button9Click = function($event) {
$rootScope.Button9.Event = $event;

$scope.closeModalView();

$scope.confirm("Konfimasi", "Yakin untuk menghapus data ?", (("DoDeleteTugas".length > 0) && angular.isFunction($scope["DoDeleteTugas"])) ? $scope["DoDeleteTugas"] : null);

};

$scope.Button10Click = function($event) {
$rootScope.Button10.Event = $event;

$scope.showView("DetailTugasDosen");

};

$scope.HtmlContent17Click = function($event) {
$rootScope.HtmlContent17.Event = $event;

$scope.closeModalView();

};

}]);

App.Ctrls.controller("MenuEnrollCtrl", ["$scope", "$rootScope", "$sce", "$interval", "$http", "$uibPosition", "blockUI",

function($scope, $rootScope, $sce, $interval, $http, $position, blockUI) {

$rootScope.MenuEnroll = {};

window.App.MenuEnroll = {};

window.App.MenuEnroll.Scope = $scope;

$rootScope.App.CurrentView = "MenuEnroll";

$scope.Button12Click = function($event) {
$rootScope.Button12.Event = $event;

$scope.closeModalView();

$scope.showView("DosenTugasTambah");

$rootScope.btnSimpanTugasDosen.Text = "Update";

$rootScope.KodeMateri.Value = ""+$rootScope.ReportTugas.Record.MT+"";

$rootScope.P_IsiTugasDosen.Value = ""+$rootScope.ReportTugas.Record.ISI+"";

$rootScope.P_BerkasTugasDosen.Value = ""+$rootScope.ReportTugas.Record.ISI+"";

};

$scope.Button13Click = function($event) {
$rootScope.Button13.Event = $event;

$scope.closeModalView();

$scope.confirm("Konfimasi", "Yakin untuk menghapus data ?", (("DoDeleteEnroll".length > 0) && angular.isFunction($scope["DoDeleteEnroll"])) ? $scope["DoDeleteEnroll"] : null);

};

$scope.HtmlContent33Click = function($event) {
$rootScope.HtmlContent33.Event = $event;

$scope.closeModalView();

};

}]);

App.Ctrls.controller("DosenTugasTambahCtrl", ["$scope", "$rootScope", "$sce", "$interval", "$http", "$uibPosition", "blockUI",

function($scope, $rootScope, $sce, $interval, $http, $position, blockUI) {

$rootScope.DosenTugasTambah = {};

window.App.DosenTugasTambah = {};

window.App.DosenTugasTambah.Scope = $scope;

$rootScope.App.CurrentView = "DosenTugasTambah";

angular.element(window.document).ready(function(event){
$rootScope.DosenTugasTambah.Event = event;

$rootScope.$apply();
});

$scope.btnSimpanTugasDosenClick = function($event) {
$rootScope.btnSimpanTugasDosen.Event = $event;

if($rootScope.P_IsiTugasDosen.Value == ''  ) {

$scope.alertBox("Maaf inputan tidak boleh ada yang kosong", "danger");

return null;

} else {

}

$scope.confirm("Konfimasi", "Yakin untuk menyimpan data ?", (("DoSaveTugas".length > 0) && angular.isFunction($scope["DoSaveTugas"])) ? $scope["DoSaveTugas"] : null);

};

$scope.Button3Click = function($event) {
$rootScope.Button3.Event = $event;

window.history.back();

};
angular.element(document.getElementById("P_BerkasTugasDosen")).on("change", function(event){
  $rootScope.P_BerkasTugasDosen.Url = URL.createObjectURL(event.target.files[0]);
});

$rootScope.TugasClientSimpan.Execute = function() {
  $http($rootScope.TugasClientSimpan.Request)
  .then(function(response) {
    $rootScope.TugasClientSimpan.Status = response.status;
    $rootScope.TugasClientSimpan.Response = response.data;
    $rootScope.TugasClientSimpan.StatusText = response.statusText;

$rootScope.Item = $rootScope.TugasClientSimpan.Response[0];

if($rootScope.Item.B== 'FALSE') {

$scope.alertBox("Response : "+$rootScope.Item.A+"", "danger");

} else {

$scope.alertBox("Response : "+$rootScope.Item.A+"", "success");

}

$rootScope.DosenTugasTambahPrgress.Hidden = "true";

$rootScope.P_BerkasTugasDosen.Value = "";

$rootScope.P_IsiTugasDosen.Value = "";

window.history.back();

  },
  function(response) {
    $rootScope.TugasClientSimpan.Status = response.status;
    $rootScope.TugasClientSimpan.Response = response.data;
    $rootScope.TugasClientSimpan.StatusText = response.statusText;

$rootScope.DosenTugasTambahPrgress.Hidden = "true";

$scope.alertBox("Proses penyimpanan gagal, cek koneksi internet", "danger");

  });
};

}]);

App.Ctrls.controller("TugasDosenHomeCtrl", ["$scope", "$rootScope", "$sce", "$interval", "$http", "$uibPosition", "blockUI",

function($scope, $rootScope, $sce, $interval, $http, $position, blockUI) {

$rootScope.TugasDosenHome = {};

window.App.TugasDosenHome = {};

window.App.TugasDosenHome.Scope = $scope;

$rootScope.App.CurrentView = "TugasDosenHome";

angular.element(window.document).ready(function(event){
$rootScope.TugasDosenHome.Event = event;

$rootScope.NAMA = $scope.getLocalOption($rootScope.NAMA);

$rootScope.USER = $scope.getLocalOption($rootScope.USER);

$rootScope.ID_USER = $scope.getLocalOption($rootScope.ID_USER);

$rootScope.URL_SERVER = $scope.getLocalOption($rootScope.URL_SERVER);

$rootScope.FILE_SERVER = $scope.getLocalOption($rootScope.FILE_SERVER);

window.App.Debugger.log("Cek Param "+$rootScope.ID_USER+" "+$rootScope.NAMA+" "+$rootScope.USER+"  "+$rootScope.URL_SERVER+" "+$rootScope.FILE_SERVER+"", "info", 0);

$rootScope.DosenTugasList.Request.data = {};

$rootScope.DosenTugasList.Request.url = $rootScope.URL_SERVER;

$rootScope.DosenTugasList.Request.data.type = "get_tugas";

$rootScope.DosenTugasList.Request.data.A = $rootScope.ID_USER;

$rootScope.DosenTugasList.Request.data.ID = "Learning.API";

$rootScope.DosenTugasList.Execute();

$rootScope.TugasDosenLoader.Hidden = "";

$rootScope.$apply();
});

$scope.ReportTugasRowClick = function($event, record) {
$rootScope.ReportTugas.Event = $event;
$rootScope.ReportTugas.Record = record;

$scope.setLocalOption("TugasPilih", ""+$rootScope.ReportTugas.Record.ID+"");

$scope.showModalView("MenuTugasDosen");

};

$rootScope.ReportTugas.GetData = function() {
if($rootScope.ReportTugas.Url == ""){return;}
$http.get($rootScope.ReportTugas.Url)
.then(function(response) {
$rootScope.ReportTugas.Status = response.status;
$rootScope.ReportTugas.Data = response.data;

},
function(response) {
$rootScope.ReportTugas.Status = response.status || "";
$rootScope.ReportTugas.Data = response.data || "";

if (""+$rootScope.NotesReport.Data+"" != "") {

$rootScope.LastError = ""+$rootScope.NotesReport.Data+"";

} else {

$rootScope.LastError = "We can't connect to the server.";

}

$scope.replaceView("Error");

});
};
$rootScope.$watch("ReportTugas.Url", function() {
  $rootScope.ReportTugas.GetData();
});

$scope.HtmlContent11Click = function($event) {
$rootScope.HtmlContent11.Event = $event;

$scope.DoShowMenu();

};

$scope.HtmlContent12Click = function($event) {
$rootScope.HtmlContent12.Event = $event;

$scope.showModalView("ListMateriTugas");

};

$scope.HtmlContent13Click = function($event) {
$rootScope.HtmlContent13.Event = $event;

$scope.replaceView("HomeDosen");

};

$rootScope.DosenTugasList.Execute = function() {
  $http($rootScope.DosenTugasList.Request)
  .then(function(response) {
    $rootScope.DosenTugasList.Status = response.status;
    $rootScope.DosenTugasList.Response = response.data;
    $rootScope.DosenTugasList.StatusText = response.statusText;

$rootScope.TugasDosenLoader.Hidden = "true";

$rootScope.ReportTugas.Data = [];

$rootScope.TotalRecords = $rootScope.DosenTugasList.Response.length;

$rootScope.I = 0;

for ($rootScope.I = 1; $rootScope.I <= $rootScope.TotalRecords; $rootScope.I++) {

$rootScope.Item = $rootScope.DosenTugasList.Response[$rootScope.I+-1];

$rootScope.Record = {};

$rootScope.Record["Nomer"] = $rootScope.I;

$rootScope.Record["Title"] = ""+$rootScope.Item.I+"";

$rootScope.Record["Description"] = ""+$rootScope.Item.D+".";

$rootScope.Record["Tanggal"] = ""+$rootScope.Item.F+".";

$rootScope.Record["Berkas"] = ""+$rootScope.Item.E+".";

$rootScope.st = ""+$rootScope.Item.D+"";

$rootScope.st = window.App.Utils.subStr($rootScope.st, 0, 200);

$rootScope.Record["SDesc"] = ""+$rootScope.st+"..";

$rootScope.Record["ID"] = ""+$rootScope.Item.B+"";

$rootScope.Record["MT"] = ""+$rootScope.Item.C+"";

$rootScope.Record["ISI"] = ""+$rootScope.Item.D+"";

$rootScope.Record["D"] = ""+$rootScope.Item.D+"";

$rootScope.Record["E"] = ""+$rootScope.Item.E+"";

$rootScope.Record["F"] = ""+$rootScope.Item.F+"";

$rootScope.Record["G"] = ""+$rootScope.Item.G+"";

$rootScope.Record["H"] = ""+$rootScope.Item.H+"";

$rootScope.ReportTugas.Data.push($rootScope.Record);

}

  },
  function(response) {
    $rootScope.DosenTugasList.Status = response.status;
    $rootScope.DosenTugasList.Response = response.data;
    $rootScope.DosenTugasList.StatusText = response.statusText;

$rootScope.TugasDosenLoader.Hidden = "true";

  });
};

$rootScope.DosenTugasHapus.Execute = function() {
  $http($rootScope.DosenTugasHapus.Request)
  .then(function(response) {
    $rootScope.DosenTugasHapus.Status = response.status;
    $rootScope.DosenTugasHapus.Response = response.data;
    $rootScope.DosenTugasHapus.StatusText = response.statusText;

$rootScope.Item = $rootScope.DosenTugasHapus.Response[0];

if($rootScope.Item.B== 'FALSE') {

$scope.alertBox("Response : "+$rootScope.Item.A+"", "danger");

} else {

$scope.alertBox("Response : "+$rootScope.Item.A+"", "success");

}

$rootScope.DosenTugasList.Request.data = {};

$rootScope.DosenTugasList.Request.url = $rootScope.URL_SERVER;

$rootScope.DosenTugasList.Request.data.type = "get_tugas";

$rootScope.DosenTugasList.Request.data.A = $rootScope.ID_USER;

$rootScope.DosenTugasList.Request.data.ID = "Learning.API";

$rootScope.DosenTugasList.Execute();

$rootScope.TugasDosenLoader.Hidden = "";

  },
  function(response) {
    $rootScope.DosenTugasHapus.Status = response.status;
    $rootScope.DosenTugasHapus.Response = response.data;
    $rootScope.DosenTugasHapus.StatusText = response.statusText;

$scope.alertBox("Proses penghapusan  gagal, cek koneksi internet", "danger");

  });
};

}]);

App.Ctrls.controller("NilaiTugasHomeCtrl", ["$scope", "$rootScope", "$sce", "$interval", "$http", "$uibPosition", "blockUI",

function($scope, $rootScope, $sce, $interval, $http, $position, blockUI) {

$rootScope.NilaiTugasHome = {};

window.App.NilaiTugasHome = {};

window.App.NilaiTugasHome.Scope = $scope;

$rootScope.App.CurrentView = "NilaiTugasHome";

angular.element(window.document).ready(function(event){
$rootScope.NilaiTugasHome.Event = event;

$rootScope.NAMA = $scope.getLocalOption($rootScope.NAMA);

$rootScope.USER = $scope.getLocalOption($rootScope.USER);

$rootScope.ID_USER = $scope.getLocalOption($rootScope.ID_USER);

$rootScope.URL_SERVER = $scope.getLocalOption($rootScope.URL_SERVER);

$rootScope.FILE_SERVER = $scope.getLocalOption($rootScope.FILE_SERVER);

window.App.Debugger.log("Cek Param "+$rootScope.ID_USER+" "+$rootScope.NAMA+" "+$rootScope.USER+"  "+$rootScope.URL_SERVER+" "+$rootScope.FILE_SERVER+"", "info", 0);

$rootScope.ListTugasClient.Request.data = {};

$rootScope.ListTugasClient.Request.url = $rootScope.URL_SERVER;

$rootScope.ListTugasClient.Request.data.type = "get_tugas";

$rootScope.ListTugasClient.Request.data.A = $rootScope.ID_USER;

$rootScope.ListTugasClient.Request.data.ID = "Learning.API";

$rootScope.ListTugasClient.Execute();

$rootScope.ListTugasClientLoader.Hidden = "";

$rootScope.$apply();
});

$scope.ReportListTugasRowClick = function($event, record) {
$rootScope.ReportListTugas.Event = $event;
$rootScope.ReportListTugas.Record = record;

$scope.showView("TugasMahasiswaDosen");

$scope.closeModalView();

};

$rootScope.ReportListTugas.GetData = function() {
if($rootScope.ReportListTugas.Url == ""){return;}
$http.get($rootScope.ReportListTugas.Url)
.then(function(response) {
$rootScope.ReportListTugas.Status = response.status;
$rootScope.ReportListTugas.Data = response.data;

},
function(response) {
$rootScope.ReportListTugas.Status = response.status || "";
$rootScope.ReportListTugas.Data = response.data || "";

if (""+$rootScope.NotesReport.Data+"" != "") {

$rootScope.LastError = ""+$rootScope.NotesReport.Data+"";

} else {

$rootScope.LastError = "We can't connect to the server.";

}

$scope.replaceView("Error");

});
};
$rootScope.$watch("ReportListTugas.Url", function() {
  $rootScope.ReportListTugas.GetData();
});

$scope.HtmlContent27Click = function($event) {
$rootScope.HtmlContent27.Event = $event;

$scope.closeModalView();

};

$rootScope.ListTugasClient.Execute = function() {
  $http($rootScope.ListTugasClient.Request)
  .then(function(response) {
    $rootScope.ListTugasClient.Status = response.status;
    $rootScope.ListTugasClient.Response = response.data;
    $rootScope.ListTugasClient.StatusText = response.statusText;

$rootScope.ListTugasClientLoader.Hidden = "true";

$rootScope.ReportListTugas.Data = [];

$rootScope.TotalRecords = $rootScope.ListTugasClient.Response.length;

$rootScope.I = 0;

for ($rootScope.I = 1; $rootScope.I <= $rootScope.TotalRecords; $rootScope.I++) {

$rootScope.Item = $rootScope.ListTugasClient.Response[$rootScope.I+-1];

$rootScope.Record = {};

$rootScope.Record["Nomer"] = $rootScope.I;

$rootScope.Record["Title"] = ""+$rootScope.Item.I+"";

$rootScope.Record["Description"] = ""+$rootScope.Item.D+".";

$rootScope.st = ""+$rootScope.Item.D+"";

$rootScope.st = window.App.Utils.subStr($rootScope.st, 0, 200);

$rootScope.Record["SDesc"] = ""+$rootScope.st+"..";

$rootScope.Record["Berkas"] = ""+$rootScope.Item.E+".";

$rootScope.Record["Tanggal"] = ""+$rootScope.Item.F+".";

$rootScope.Record["Tugas"] = ""+$rootScope.Item.B+".";

$rootScope.Record["ID"] = ""+$rootScope.Item.C+"";

$rootScope.Record["MT"] = ""+$rootScope.Item.C+"";

$rootScope.Record["ISI"] = ""+$rootScope.Item.D+"";

$rootScope.Record["D"] = ""+$rootScope.Item.D+"";

$rootScope.Record["E"] = ""+$rootScope.Item.E+"";

$rootScope.ReportListTugas.Data.push($rootScope.Record);

}

  },
  function(response) {
    $rootScope.ListTugasClient.Status = response.status;
    $rootScope.ListTugasClient.Response = response.data;
    $rootScope.ListTugasClient.StatusText = response.statusText;

$rootScope.ListTugasClientLoader.Hidden = "true";

  });
};

}]);

App.Ctrls.controller("ListMateriTugasCtrl", ["$scope", "$rootScope", "$sce", "$interval", "$http", "$uibPosition", "blockUI",

function($scope, $rootScope, $sce, $interval, $http, $position, blockUI) {

$rootScope.ListMateriTugas = {};

window.App.ListMateriTugas = {};

window.App.ListMateriTugas.Scope = $scope;

$rootScope.App.CurrentView = "ListMateriTugas";

angular.element(window.document).ready(function(event){
$rootScope.ListMateriTugas.Event = event;

$rootScope.NAMA = $scope.getLocalOption($rootScope.NAMA);

$rootScope.USER = $scope.getLocalOption($rootScope.USER);

$rootScope.ID_USER = $scope.getLocalOption($rootScope.ID_USER);

$rootScope.URL_SERVER = $scope.getLocalOption($rootScope.URL_SERVER);

$rootScope.FILE_SERVER = $scope.getLocalOption($rootScope.FILE_SERVER);

window.App.Debugger.log("Cek Param "+$rootScope.ID_USER+" "+$rootScope.NAMA+" "+$rootScope.USER+"  "+$rootScope.URL_SERVER+" "+$rootScope.FILE_SERVER+"", "info", 0);

$rootScope.MateriTugas.Request.data = {};

$rootScope.MateriTugas.Request.url = $rootScope.URL_SERVER;

$rootScope.MateriTugas.Request.data.type = "get_materi";

$rootScope.MateriTugas.Request.data.A = $rootScope.ID_USER;

$rootScope.MateriTugas.Request.data.ID = "Learning.API";

$rootScope.MateriTugas.Execute();

$rootScope.ListMateriLoader.Hidden = "";

$rootScope.$apply();
});

$scope.RepotMateriTugasRowClick = function($event, record) {
$rootScope.RepotMateriTugas.Event = $event;
$rootScope.RepotMateriTugas.Record = record;

$scope.showView("DosenTugasTambah");

$rootScope.KodeMateri.Value = ""+$rootScope.RepotMateriTugas.Record.ID+"";

$scope.closeModalView();

};

$rootScope.RepotMateriTugas.GetData = function() {
if($rootScope.RepotMateriTugas.Url == ""){return;}
$http.get($rootScope.RepotMateriTugas.Url)
.then(function(response) {
$rootScope.RepotMateriTugas.Status = response.status;
$rootScope.RepotMateriTugas.Data = response.data;

},
function(response) {
$rootScope.RepotMateriTugas.Status = response.status || "";
$rootScope.RepotMateriTugas.Data = response.data || "";

if (""+$rootScope.NotesReport.Data+"" != "") {

$rootScope.LastError = ""+$rootScope.NotesReport.Data+"";

} else {

$rootScope.LastError = "We can't connect to the server.";

}

$scope.replaceView("Error");

});
};
$rootScope.$watch("RepotMateriTugas.Url", function() {
  $rootScope.RepotMateriTugas.GetData();
});

$rootScope.MateriTugas.Execute = function() {
  $http($rootScope.MateriTugas.Request)
  .then(function(response) {
    $rootScope.MateriTugas.Status = response.status;
    $rootScope.MateriTugas.Response = response.data;
    $rootScope.MateriTugas.StatusText = response.statusText;

$rootScope.ListMateriLoader.Hidden = "true";

$rootScope.RepotMateriTugas.Data = [];

$rootScope.TotalRecords = $rootScope.MateriTugas.Response.length;

$rootScope.I = 0;

for ($rootScope.I = 1; $rootScope.I <= $rootScope.TotalRecords; $rootScope.I++) {

$rootScope.Item = $rootScope.MateriTugas.Response[$rootScope.I+-1];

$rootScope.Record = {};

$rootScope.Record["Nomer"] = $rootScope.I;

$rootScope.Record["Title"] = ""+$rootScope.Item.C+"";

$rootScope.Record["Description"] = ""+$rootScope.Item.F+".";

$rootScope.st = ""+$rootScope.Item.F+"";

$rootScope.st = window.App.Utils.subStr($rootScope.st, 0, 200);

$rootScope.Record["SDesc"] = ""+$rootScope.st+"..";

$rootScope.Record["Tanggal"] = ""+$rootScope.Item.H+".";

$rootScope.Record["ID"] = ""+$rootScope.Item.E+"";

$rootScope.Record["MK"] = ""+$rootScope.Item.B+"";

$rootScope.Record["ISI"] = ""+$rootScope.Item.F+"";

$rootScope.Record["D"] = ""+$rootScope.Item.D+"";

$rootScope.Record["E"] = ""+$rootScope.Item.E+"";

$rootScope.Record["F"] = ""+$rootScope.Item.F+"";

$rootScope.Record["G"] = ""+$rootScope.Item.G+"";

$rootScope.Record["H"] = ""+$rootScope.Item.H+"";

$rootScope.RepotMateriTugas.Data.push($rootScope.Record);

}

  },
  function(response) {
    $rootScope.MateriTugas.Status = response.status;
    $rootScope.MateriTugas.Response = response.data;
    $rootScope.MateriTugas.StatusText = response.statusText;

$rootScope.ListMateriLoader.Hidden = "true";

  });
};

$scope.HtmlContent15Click = function($event) {
$rootScope.HtmlContent15.Event = $event;

$scope.closeModalView();

};

}]);

App.Ctrls.controller("TugasMahasiswaDosenCtrl", ["$scope", "$rootScope", "$sce", "$interval", "$http", "$uibPosition", "blockUI",

function($scope, $rootScope, $sce, $interval, $http, $position, blockUI) {

$rootScope.TugasMahasiswaDosen = {};

window.App.TugasMahasiswaDosen = {};

window.App.TugasMahasiswaDosen.Scope = $scope;

$rootScope.App.CurrentView = "TugasMahasiswaDosen";

angular.element(window.document).ready(function(event){
$rootScope.TugasMahasiswaDosen.Event = event;

$rootScope.NAMA = $scope.getLocalOption($rootScope.NAMA);

$rootScope.USER = $scope.getLocalOption($rootScope.USER);

$rootScope.ID_USER = $scope.getLocalOption($rootScope.ID_USER);

$rootScope.URL_SERVER = $scope.getLocalOption($rootScope.URL_SERVER);

$rootScope.FILE_SERVER = $scope.getLocalOption($rootScope.FILE_SERVER);

window.App.Debugger.log("Cek Param "+$rootScope.ID_USER+" "+$rootScope.NAMA+" "+$rootScope.USER+"  "+$rootScope.URL_SERVER+" "+$rootScope.FILE_SERVER+"", "info", 0);

$rootScope.TugasMahasiswaListDosenClient.Request.data = {};

$rootScope.TugasMahasiswaListDosenClient.Request.url = $rootScope.URL_SERVER;

$rootScope.TugasMahasiswaListDosenClient.Request.data.type = "get_tugas_mahasiswa";

$rootScope.TugasMahasiswaListDosenClient.Request.data.A = $rootScope.ID_USER;

$rootScope.TugasMahasiswaListDosenClient.Request.data.B = ""+$rootScope.ReportListTugas.Record.Tugas+"";

$rootScope.TugasMahasiswaListDosenClient.Request.data.ID = "Learning.API";

$rootScope.TugasMahasiswaListDosenClient.Execute();

$rootScope.TugasMahasiswaListDosenClientLoader.Hidden = "";

$rootScope.$apply();
});

$scope.ReportTugasMahasiswaDosenRowClick = function($event, record) {
$rootScope.ReportTugasMahasiswaDosen.Event = $event;
$rootScope.ReportTugasMahasiswaDosen.Record = record;

$scope.showModalView("ViewTugasMahasiswaDosen");

$rootScope.KodeMateri.Value = ""+$rootScope.ReportTugasMahasiswaDosen.Record.ID+"";

};

$rootScope.ReportTugasMahasiswaDosen.GetData = function() {
if($rootScope.ReportTugasMahasiswaDosen.Url == ""){return;}
$http.get($rootScope.ReportTugasMahasiswaDosen.Url)
.then(function(response) {
$rootScope.ReportTugasMahasiswaDosen.Status = response.status;
$rootScope.ReportTugasMahasiswaDosen.Data = response.data;

},
function(response) {
$rootScope.ReportTugasMahasiswaDosen.Status = response.status || "";
$rootScope.ReportTugasMahasiswaDosen.Data = response.data || "";

if (""+$rootScope.NotesReport.Data+"" != "") {

$rootScope.LastError = ""+$rootScope.NotesReport.Data+"";

} else {

$rootScope.LastError = "We can't connect to the server.";

}

$scope.replaceView("Error");

});
};
$rootScope.$watch("ReportTugasMahasiswaDosen.Url", function() {
  $rootScope.ReportTugasMahasiswaDosen.GetData();
});

$rootScope.TugasMahasiswaListDosenClient.Execute = function() {
  $http($rootScope.TugasMahasiswaListDosenClient.Request)
  .then(function(response) {
    $rootScope.TugasMahasiswaListDosenClient.Status = response.status;
    $rootScope.TugasMahasiswaListDosenClient.Response = response.data;
    $rootScope.TugasMahasiswaListDosenClient.StatusText = response.statusText;

$rootScope.TugasMahasiswaListDosenClientLoader.Hidden = "true";

$rootScope.ReportTugasMahasiswaDosen.Data = [];

$rootScope.TotalRecords = $rootScope.TugasMahasiswaListDosenClient.Response.length;

$rootScope.I = 0;

for ($rootScope.I = 1; $rootScope.I <= $rootScope.TotalRecords; $rootScope.I++) {

$rootScope.Item = $rootScope.TugasMahasiswaListDosenClient.Response[$rootScope.I+-1];

if (""+$rootScope.Item.B+"" ==  "FALSE" ) {

$rootScope.ReportTugasMahasiswaDosen.Loading = "Data tidak ditemukan";

return null;

}

$rootScope.Record = {};

$rootScope.Record["Nomer"] = $rootScope.I;

$rootScope.Record["Title"] = ""+$rootScope.Item.L+"";

$rootScope.Record["Description"] = ""+$rootScope.Item.M+".";

$rootScope.Record["Tanggal"] = ""+$rootScope.Item.O+".";

$rootScope.Record["Berkas"] = ""+$rootScope.Item.N+".";

$rootScope.st = ""+$rootScope.Item.M+"";

$rootScope.st = window.App.Utils.subStr($rootScope.st, 0, 200);

$rootScope.Record["SDesc"] = ""+$rootScope.st+"..";

$rootScope.Record["ID"] = ""+$rootScope.Item.B+"";

$rootScope.Record["Nim"] = ""+$rootScope.Item.L+"";

$rootScope.Record["Nama"] = ""+$rootScope.Item.R+"";

$rootScope.Record["Nilai"] = ""+$rootScope.Item.P+"";

$rootScope.Record["ISI"] = ""+$rootScope.Item.M+"";

$rootScope.Record["E"] = ""+$rootScope.Item.E+"";

$rootScope.Record["F"] = ""+$rootScope.Item.F+"";

$rootScope.Record["G"] = ""+$rootScope.Item.G+"";

$rootScope.Record["H"] = ""+$rootScope.Item.H+"";

$rootScope.ReportTugasMahasiswaDosen.Data.push($rootScope.Record);

}

  },
  function(response) {
    $rootScope.TugasMahasiswaListDosenClient.Status = response.status;
    $rootScope.TugasMahasiswaListDosenClient.Response = response.data;
    $rootScope.TugasMahasiswaListDosenClient.StatusText = response.statusText;

$rootScope.TugasMahasiswaListDosenClientLoader.Hidden = "true";

  });
};

$scope.HtmlContent23Click = function($event) {
$rootScope.HtmlContent23.Event = $event;

$scope.replaceView("HomeDosen");

};

$rootScope.NilaiTugasSimpan.Execute = function() {
  $http($rootScope.NilaiTugasSimpan.Request)
  .then(function(response) {
    $rootScope.NilaiTugasSimpan.Status = response.status;
    $rootScope.NilaiTugasSimpan.Response = response.data;
    $rootScope.NilaiTugasSimpan.StatusText = response.statusText;

$rootScope.Item = $rootScope.NilaiTugasSimpan.Response[0];

if($rootScope.Item.B== 'FALSE') {

$scope.alertBox("Response : "+$rootScope.Item.A+"", "danger");

} else {

$scope.alertBox("Response : "+$rootScope.Item.A+"", "success");

}

$rootScope.TugasMahasiswaListDosenClient.Request.data = {};

$rootScope.TugasMahasiswaListDosenClient.Request.url = $rootScope.URL_SERVER;

$rootScope.TugasMahasiswaListDosenClient.Request.data.type = "get_tugas_mahasiswa";

$rootScope.TugasMahasiswaListDosenClient.Request.data.A = $rootScope.ID_USER;

$rootScope.TugasMahasiswaListDosenClient.Request.data.B = ""+$rootScope.ReportListTugas.Record.Tugas+"";

$rootScope.TugasMahasiswaListDosenClient.Request.data.ID = "Learning.API";

$rootScope.TugasMahasiswaListDosenClient.Execute();

$rootScope.TugasMahasiswaListDosenClientLoader.Hidden = "";

  },
  function(response) {
    $rootScope.NilaiTugasSimpan.Status = response.status;
    $rootScope.NilaiTugasSimpan.Response = response.data;
    $rootScope.NilaiTugasSimpan.StatusText = response.statusText;

  });
};

}]);

App.Ctrls.controller("DetailTugasDosenCtrl", ["$scope", "$rootScope", "$sce", "$interval", "$http", "$uibPosition", "blockUI",

function($scope, $rootScope, $sce, $interval, $http, $position, blockUI) {

$rootScope.DetailTugasDosen = {};

window.App.DetailTugasDosen = {};

window.App.DetailTugasDosen.Scope = $scope;

$rootScope.App.CurrentView = "DetailTugasDosen";

$scope.Button11Click = function($event) {
$rootScope.Button11.Event = $event;

$scope.openWindow(""+$rootScope.FILE_SERVER+""+$rootScope.ReportTugas.Record.Berkas+"", "");

};

$scope.HtmlContent19Click = function($event) {
$rootScope.HtmlContent19.Event = $event;

window.history.back();

};

}]);

App.Ctrls.controller("ListMatkulEnrollCtrl", ["$scope", "$rootScope", "$sce", "$interval", "$http", "$uibPosition", "blockUI",

function($scope, $rootScope, $sce, $interval, $http, $position, blockUI) {

$rootScope.ListMatkulEnroll = {};

window.App.ListMatkulEnroll = {};

window.App.ListMatkulEnroll.Scope = $scope;

$rootScope.App.CurrentView = "ListMatkulEnroll";

angular.element(window.document).ready(function(event){
$rootScope.ListMatkulEnroll.Event = event;

$rootScope.NAMA = $scope.getLocalOption($rootScope.NAMA);

$rootScope.USER = $scope.getLocalOption($rootScope.USER);

$rootScope.ID_USER = $scope.getLocalOption($rootScope.ID_USER);

$rootScope.URL_SERVER = $scope.getLocalOption($rootScope.URL_SERVER);

$rootScope.FILE_SERVER = $scope.getLocalOption($rootScope.FILE_SERVER);

window.App.Debugger.log("Cek Param "+$rootScope.ID_USER+" "+$rootScope.NAMA+" "+$rootScope.USER+"  "+$rootScope.URL_SERVER+" "+$rootScope.FILE_SERVER+"", "info", 0);

$rootScope.MatkulEnrollClient.Request.data = {};

$rootScope.MatkulEnrollClient.Request.url = $rootScope.URL_SERVER;

$rootScope.MatkulEnrollClient.Request.data.type = "get_all_matkul";

$rootScope.MatkulEnrollClient.Request.data.A = $rootScope.ID_USER;

$rootScope.MatkulEnrollClient.Request.data.ID = "Learning.API";

$rootScope.MatkulEnrollClient.Execute();

$rootScope.ReportMatkulEnrollLoader.Hidden = "";

$rootScope.$apply();
});

$scope.ReportMatkulEnrollRowClick = function($event, record) {
$rootScope.ReportMatkulEnroll.Event = $event;
$rootScope.ReportMatkulEnroll.Record = record;

$scope.closeModalView();

$scope.confirm("Konfimasi", "Yakin untuk menyimpan data ?", (("DoSaveEnroll".length > 0) && angular.isFunction($scope["DoSaveEnroll"])) ? $scope["DoSaveEnroll"] : null);

};

$rootScope.ReportMatkulEnroll.GetData = function() {
if($rootScope.ReportMatkulEnroll.Url == ""){return;}
$http.get($rootScope.ReportMatkulEnroll.Url)
.then(function(response) {
$rootScope.ReportMatkulEnroll.Status = response.status;
$rootScope.ReportMatkulEnroll.Data = response.data;

},
function(response) {
$rootScope.ReportMatkulEnroll.Status = response.status || "";
$rootScope.ReportMatkulEnroll.Data = response.data || "";

if (""+$rootScope.NotesReport.Data+"" != "") {

$rootScope.LastError = ""+$rootScope.NotesReport.Data+"";

} else {

$rootScope.LastError = "We can't connect to the server.";

}

$scope.replaceView("Error");

});
};
$rootScope.$watch("ReportMatkulEnroll.Url", function() {
  $rootScope.ReportMatkulEnroll.GetData();
});

$scope.HtmlContent32Click = function($event) {
$rootScope.HtmlContent32.Event = $event;

$scope.closeModalView();

};

$rootScope.MatkulEnrollClient.Execute = function() {
  $http($rootScope.MatkulEnrollClient.Request)
  .then(function(response) {
    $rootScope.MatkulEnrollClient.Status = response.status;
    $rootScope.MatkulEnrollClient.Response = response.data;
    $rootScope.MatkulEnrollClient.StatusText = response.statusText;

$rootScope.ReportMatkulEnrollLoader.Hidden = "true";

$rootScope.ReportMatkulEnroll.Data = [];

$rootScope.TotalRecords = $rootScope.MatkulEnrollClient.Response.length;

$rootScope.I = 0;

for ($rootScope.I = 1; $rootScope.I <= $rootScope.TotalRecords; $rootScope.I++) {

$rootScope.Item = $rootScope.MatkulEnrollClient.Response[$rootScope.I+-1];

$rootScope.Record = {};

$rootScope.Record["Nomer"] = $rootScope.I;

$rootScope.Record["Title"] = ""+$rootScope.Item.C+"";

$rootScope.Record["NIP"] = ""+$rootScope.Item.D+"";

$rootScope.Record["Nama"] = ""+$rootScope.Item.F+"";

$rootScope.Record["ID"] = ""+$rootScope.Item.B+"";

$rootScope.Record["MK"] = ""+$rootScope.Item.C+"";

$rootScope.Record["ISI"] = ""+$rootScope.Item.F+"";

$rootScope.ReportMatkulEnroll.Data.push($rootScope.Record);

}

  },
  function(response) {
    $rootScope.MatkulEnrollClient.Status = response.status;
    $rootScope.MatkulEnrollClient.Response = response.data;
    $rootScope.MatkulEnrollClient.StatusText = response.statusText;

$rootScope.ReportMatkulEnrollLoader.Hidden = "true";

  });
};

}]);

App.Ctrls.controller("MateriCtrl", ["$scope", "$rootScope", "$sce", "$interval", "$http", "$uibPosition", "blockUI",

function($scope, $rootScope, $sce, $interval, $http, $position, blockUI) {

$rootScope.Materi = {};

window.App.Materi = {};

window.App.Materi.Scope = $scope;

$rootScope.App.CurrentView = "Materi";

angular.element(window.document).ready(function(event){
$rootScope.Materi.Event = event;

$rootScope.$apply();
});

$scope.Button2Click = function($event) {
$rootScope.Button2.Event = $event;

$rootScope.Progressbar1.Hidden = "";

$rootScope.Textarea3.Value = "";

$rootScope.HttpClient1.Request.data = {};

$rootScope.HttpClient1.Request.data.Name = $rootScope.Input3.Value;

$rootScope.HttpClient1.Request.data.LastName = $rootScope.Input4.Value;

$rootScope.HttpClient1.Request.data.MyFile = $rootScope.Input5.Value;

$rootScope.HttpClient1.Execute();

};
angular.element(document.getElementById("Input5")).on("change", function(event){
  $rootScope.Input5.Url = URL.createObjectURL(event.target.files[0]);
});

}]);

App.Ctrls.controller("HomeCtrl", ["$scope", "$rootScope", "$sce", "$interval", "$http", "$uibPosition", "blockUI",

function($scope, $rootScope, $sce, $interval, $http, $position, blockUI) {

$rootScope.Home = {};

window.App.Home = {};

window.App.Home.Scope = $scope;

$rootScope.App.CurrentView = "Home";

}]);

App.Ctrls.controller("ViewMateriMahasiwaCtrl", ["$scope", "$rootScope", "$sce", "$interval", "$http", "$uibPosition", "blockUI",

function($scope, $rootScope, $sce, $interval, $http, $position, blockUI) {

$rootScope.ViewMateriMahasiwa = {};

window.App.ViewMateriMahasiwa = {};

window.App.ViewMateriMahasiwa.Scope = $scope;

$rootScope.App.CurrentView = "ViewMateriMahasiwa";

angular.element(window.document).ready(function(event){
$rootScope.ViewMateriMahasiwa.Event = event;

$rootScope.NAMA = $scope.getLocalOption($rootScope.NAMA);

$rootScope.USER = $scope.getLocalOption($rootScope.USER);

$rootScope.ID_USER = $scope.getLocalOption($rootScope.ID_USER);

$rootScope.URL_SERVER = $scope.getLocalOption($rootScope.URL_SERVER);

$rootScope.FILE_SERVER = $scope.getLocalOption($rootScope.FILE_SERVER);

window.App.Debugger.log("Cek Param "+$rootScope.ID_USER+" "+$rootScope.NAMA+" "+$rootScope.USER+"  "+$rootScope.URL_SERVER+" "+$rootScope.FILE_SERVER+"", "info", 0);

$rootScope.ViewMateriClient.Request.data = {};

$rootScope.ViewMateriClient.Request.url = $rootScope.URL_SERVER;

$rootScope.ViewMateriClient.Request.data.type = "get_materi_mhs";

$rootScope.ViewMateriClient.Request.data.A = $rootScope.ID_USER;

$rootScope.ViewMateriClient.Request.data.ID = "Learning.API";

$rootScope.ViewMateriClient.Execute();

$rootScope.ReportListMateriLoader.Hidden = "";

$rootScope.$apply();
});

$scope.ReportListMateriRowClick = function($event, record) {
$rootScope.ReportListMateri.Event = $event;
$rootScope.ReportListMateri.Record = record;

$scope.setLocalOption("MateriPilih", ""+$rootScope.ReportListMateri.Record.ID+"");

$scope.showModalView("DetailMateriMahasiswa");

};

$rootScope.ReportListMateri.GetData = function() {
if($rootScope.ReportListMateri.Url == ""){return;}
$http.get($rootScope.ReportListMateri.Url)
.then(function(response) {
$rootScope.ReportListMateri.Status = response.status;
$rootScope.ReportListMateri.Data = response.data;

},
function(response) {
$rootScope.ReportListMateri.Status = response.status || "";
$rootScope.ReportListMateri.Data = response.data || "";

if (""+$rootScope.NotesReport.Data+"" != "") {

$rootScope.LastError = ""+$rootScope.NotesReport.Data+"";

} else {

$rootScope.LastError = "We can't connect to the server.";

}

$scope.replaceView("Error");

});
};
$rootScope.$watch("ReportListMateri.Url", function() {
  $rootScope.ReportListMateri.GetData();
});

$scope.HtmlContent35Click = function($event) {
$rootScope.HtmlContent35.Event = $event;

$scope.DoShowMenu();

};

$scope.HtmlContent37Click = function($event) {
$rootScope.HtmlContent37.Event = $event;

$scope.replaceView("HomeDosen");

};

$rootScope.ViewMateriClient.Execute = function() {
  $http($rootScope.ViewMateriClient.Request)
  .then(function(response) {
    $rootScope.ViewMateriClient.Status = response.status;
    $rootScope.ViewMateriClient.Response = response.data;
    $rootScope.ViewMateriClient.StatusText = response.statusText;

$rootScope.ReportListMateri.Data = [];

$rootScope.TotalRecords = $rootScope.ViewMateriClient.Response.length;

$rootScope.I = 0;

$rootScope.ReportListMateriLoader.Hidden = "true";

for ($rootScope.I = 1; $rootScope.I <= $rootScope.TotalRecords; $rootScope.I++) {

$rootScope.Item = $rootScope.ViewMateriClient.Response[$rootScope.I+-1];

if (""+$rootScope.Item.B+"" ==  "FALSE" ) {

$rootScope.ReportListMateri.Loading = "Data tidak ditemukan";

return null;

}

$rootScope.Record = {};

$rootScope.Record["Nomer"] = $rootScope.I;

$rootScope.Record["Title"] = ""+$rootScope.Item.D+"";

$rootScope.Record["Description"] = ""+$rootScope.Item.I+".";

$rootScope.Record["Tanggal"] = ""+$rootScope.Item.K+".";

$rootScope.Record["Berkas"] = ""+$rootScope.Item.J+".";

$rootScope.st = ""+$rootScope.Item.I+"";

$rootScope.st = window.App.Utils.subStr($rootScope.st, 0, 200);

$rootScope.Record["SDesc"] = ""+$rootScope.st+"..";

$rootScope.Record["ID"] = ""+$rootScope.Item.H+"";

$rootScope.Record["Nama"] = ""+$rootScope.Item.G+"";

$rootScope.Record["MT"] = ""+$rootScope.Item.B+"";

$rootScope.Record["ISI"] = ""+$rootScope.Item.I+"";

$rootScope.ReportListMateri.Data.push($rootScope.Record);

}

  },
  function(response) {
    $rootScope.ViewMateriClient.Status = response.status;
    $rootScope.ViewMateriClient.Response = response.data;
    $rootScope.ViewMateriClient.StatusText = response.statusText;

$rootScope.ReportListMateriLoader.Hidden = "true";

  });
};

}]);

App.Ctrls.controller("DetailMateriMahasiswaCtrl", ["$scope", "$rootScope", "$sce", "$interval", "$http", "$uibPosition", "blockUI",

function($scope, $rootScope, $sce, $interval, $http, $position, blockUI) {

$rootScope.DetailMateriMahasiswa = {};

window.App.DetailMateriMahasiswa = {};

window.App.DetailMateriMahasiswa.Scope = $scope;

$rootScope.App.CurrentView = "DetailMateriMahasiswa";

angular.element(window.document).ready(function(event){
$rootScope.DetailMateriMahasiswa.Event = event;

$rootScope.FILE_SERVER = $scope.getLocalOption($rootScope.FILE_SERVER);

window.App.Debugger.log("Cek Param "+$rootScope.ID_USER+" "+$rootScope.NAMA+" "+$rootScope.USER+"  "+$rootScope.URL_SERVER+" "+$rootScope.FILE_SERVER+"", "info", 0);

$rootScope.$apply();
});

$scope.Button14Click = function($event) {
$rootScope.Button14.Event = $event;

$scope.openWindow(""+$rootScope.FILE_SERVER+""+$rootScope.ReportListMateri.Record.Berkas+"", "");

};

$scope.HtmlContent38Click = function($event) {
$rootScope.HtmlContent38.Event = $event;

$scope.closeModalView();

};

}]);

App.Ctrls.controller("ViewTugasMahasisaCtrl", ["$scope", "$rootScope", "$sce", "$interval", "$http", "$uibPosition", "blockUI",

function($scope, $rootScope, $sce, $interval, $http, $position, blockUI) {

$rootScope.ViewTugasMahasisa = {};

window.App.ViewTugasMahasisa = {};

window.App.ViewTugasMahasisa.Scope = $scope;

$rootScope.App.CurrentView = "ViewTugasMahasisa";

angular.element(window.document).ready(function(event){
$rootScope.ViewTugasMahasisa.Event = event;

$rootScope.NAMA = $scope.getLocalOption($rootScope.NAMA);

$rootScope.USER = $scope.getLocalOption($rootScope.USER);

$rootScope.ID_USER = $scope.getLocalOption($rootScope.ID_USER);

$rootScope.URL_SERVER = $scope.getLocalOption($rootScope.URL_SERVER);

$rootScope.FILE_SERVER = $scope.getLocalOption($rootScope.FILE_SERVER);

window.App.Debugger.log("Cek Param "+$rootScope.ID_USER+" "+$rootScope.NAMA+" "+$rootScope.USER+"  "+$rootScope.URL_SERVER+" "+$rootScope.FILE_SERVER+"", "info", 0);

$rootScope.ViewTugasClient.Request.data = {};

$rootScope.ViewTugasClient.Request.url = $rootScope.URL_SERVER;

$rootScope.ViewTugasClient.Request.data.type = "get_tugas_mhs";

$rootScope.ViewTugasClient.Request.data.A = $rootScope.ID_USER;

$rootScope.ViewTugasClient.Request.data.ID = "Learning.API";

$rootScope.ViewTugasClient.Execute();

$rootScope.ViewTugasClientLoader.Hidden = "";

$rootScope.$apply();
});

$scope.ReportViewTugasRowClick = function($event, record) {
$rootScope.ReportViewTugas.Event = $event;
$rootScope.ReportViewTugas.Record = record;

$scope.setLocalOption("TugasPilih", ""+$rootScope.ReportViewTugas.Record.ID+"");

$scope.setLocalOption("IDPilih", ""+$rootScope.ReportViewTugas.Record.Tugas+"");

$scope.showModalView("DetailTugasMahasiswa");

};

$rootScope.ReportViewTugas.GetData = function() {
if($rootScope.ReportViewTugas.Url == ""){return;}
$http.get($rootScope.ReportViewTugas.Url)
.then(function(response) {
$rootScope.ReportViewTugas.Status = response.status;
$rootScope.ReportViewTugas.Data = response.data;

},
function(response) {
$rootScope.ReportViewTugas.Status = response.status || "";
$rootScope.ReportViewTugas.Data = response.data || "";

if (""+$rootScope.NotesReport.Data+"" != "") {

$rootScope.LastError = ""+$rootScope.NotesReport.Data+"";

} else {

$rootScope.LastError = "We can't connect to the server.";

}

$scope.replaceView("Error");

});
};
$rootScope.$watch("ReportViewTugas.Url", function() {
  $rootScope.ReportViewTugas.GetData();
});

$scope.HtmlContent40Click = function($event) {
$rootScope.HtmlContent40.Event = $event;

$scope.DoShowMenu();

};

$scope.HtmlContent41Click = function($event) {
$rootScope.HtmlContent41.Event = $event;

$scope.replaceView("HomeDosen");

};

$rootScope.ViewTugasClient.Execute = function() {
  $http($rootScope.ViewTugasClient.Request)
  .then(function(response) {
    $rootScope.ViewTugasClient.Status = response.status;
    $rootScope.ViewTugasClient.Response = response.data;
    $rootScope.ViewTugasClient.StatusText = response.statusText;

$rootScope.ViewTugasClientLoader.Hidden = "true";

$rootScope.ReportViewTugas.Data = [];

$rootScope.TotalRecords = $rootScope.ViewTugasClient.Response.length;

$rootScope.I = 0;

for ($rootScope.I = 1; $rootScope.I <= $rootScope.TotalRecords; $rootScope.I++) {

$rootScope.Item = $rootScope.ViewTugasClient.Response[$rootScope.I+-1];

if (""+$rootScope.Item.B+"" ==  "FALSE" ) {

$rootScope.ReportViewTugas.Loading = "Data tidak ditemukan";

return null;

}

$rootScope.Record = {};

$rootScope.Record["Nomer"] = $rootScope.I;

$rootScope.Record["Title"] = ""+$rootScope.Item.D+"";

$rootScope.Record["Description"] = ""+$rootScope.Item.I+".";

$rootScope.Record["Tanggal"] = ""+$rootScope.Item.K+".";

$rootScope.Record["Berkas"] = ""+$rootScope.Item.J+".";

$rootScope.st = ""+$rootScope.Item.I+"";

$rootScope.st = window.App.Utils.subStr($rootScope.st, 0, 200);

$rootScope.Record["SDesc"] = ""+$rootScope.st+"..";

$rootScope.Record["ID"] = ""+$rootScope.Item.H+"";

$rootScope.Record["Nama"] = ""+$rootScope.Item.G+"";

$rootScope.Record["MK"] = ""+$rootScope.Item.C+"";

$rootScope.Record["ISI"] = ""+$rootScope.Item.I+"";

$rootScope.Record["Tugas"] = ""+$rootScope.Item.L+"";

$rootScope.ReportViewTugas.Data.push($rootScope.Record);

}

  },
  function(response) {
    $rootScope.ViewTugasClient.Status = response.status;
    $rootScope.ViewTugasClient.Response = response.data;
    $rootScope.ViewTugasClient.StatusText = response.statusText;

$rootScope.ViewTugasClientLoader.Hidden = "true";

  });
};

$rootScope.SimpanTugasMahasiswa.Execute = function() {
  $http($rootScope.SimpanTugasMahasiswa.Request)
  .then(function(response) {
    $rootScope.SimpanTugasMahasiswa.Status = response.status;
    $rootScope.SimpanTugasMahasiswa.Response = response.data;
    $rootScope.SimpanTugasMahasiswa.StatusText = response.statusText;

$rootScope.Item = $rootScope.SimpanTugasMahasiswa.Response[0];

if($rootScope.Item.B== 'FALSE') {

$scope.alertBox("Response : "+$rootScope.Item.A+"", "danger");

} else {

$scope.alertBox("Response : "+$rootScope.Item.A+"", "success");

}

$rootScope.ViewTugasClient.Request.data = {};

$rootScope.ViewTugasClient.Request.url = $rootScope.URL_SERVER;

$rootScope.ViewTugasClient.Request.data.type = "get_tugas_mhs";

$rootScope.ViewTugasClient.Request.data.A = $rootScope.ID_USER;

$rootScope.ViewTugasClient.Request.data.ID = "Learning.API";

$rootScope.ViewTugasClient.Execute();

$rootScope.ViewTugasClientLoader.Hidden = "";

  },
  function(response) {
    $rootScope.SimpanTugasMahasiswa.Status = response.status;
    $rootScope.SimpanTugasMahasiswa.Response = response.data;
    $rootScope.SimpanTugasMahasiswa.StatusText = response.statusText;

  });
};

}]);

App.Ctrls.controller("DetailTugasMahasiswaCtrl", ["$scope", "$rootScope", "$sce", "$interval", "$http", "$uibPosition", "blockUI",

function($scope, $rootScope, $sce, $interval, $http, $position, blockUI) {

$rootScope.DetailTugasMahasiswa = {};

window.App.DetailTugasMahasiswa = {};

window.App.DetailTugasMahasiswa.Scope = $scope;

$rootScope.App.CurrentView = "DetailTugasMahasiswa";

$scope.Button15Click = function($event) {
$rootScope.Button15.Event = $event;

$scope.openWindow(""+$rootScope.FILE_SERVER+""+$rootScope.ReportViewTugas.Record.Berkas+"", "");

};

$scope.HtmlContent43Click = function($event) {
$rootScope.HtmlContent43.Event = $event;

$scope.closeModalView();

};

$scope.btnKirimTugasClick = function($event) {
$rootScope.btnKirimTugas.Event = $event;

$rootScope.ID_Tugas.Value = ""+$rootScope.ReportViewTugas.Record.Tugas+"";

$scope.closeModalView();

$scope.showView("MahasiswaKirimTugas");

};

}]);

App.Ctrls.controller("MahasiswaKirimTugasCtrl", ["$scope", "$rootScope", "$sce", "$interval", "$http", "$uibPosition", "blockUI",

function($scope, $rootScope, $sce, $interval, $http, $position, blockUI) {

$rootScope.MahasiswaKirimTugas = {};

window.App.MahasiswaKirimTugas = {};

window.App.MahasiswaKirimTugas.Scope = $scope;

$rootScope.App.CurrentView = "MahasiswaKirimTugas";

$scope.Button16Click = function($event) {
$rootScope.Button16.Event = $event;

if($rootScope.P_TugasMahasiswaIsi.Value == ''  ) {

$scope.alertBox("Maaf inputan tidak boleh ada yang kosong", "danger");

return null;

} else {

}

$scope.confirm("Konfimasi", "Yakin untuk menyimpan data ?", (("DoKirimTugas".length > 0) && angular.isFunction($scope["DoKirimTugas"])) ? $scope["DoKirimTugas"] : null);

$scope.replaceView("ViewTugasMahasisa");

};

$scope.Button17Click = function($event) {
$rootScope.Button17.Event = $event;

window.history.back();

};
angular.element(document.getElementById("P_TugasMahasiswaBerkas")).on("change", function(event){
  $rootScope.P_TugasMahasiswaBerkas.Url = URL.createObjectURL(event.target.files[0]);
});

$rootScope.TugasMahasiswaClient.Execute = function() {
  $http($rootScope.TugasMahasiswaClient.Request)
  .then(function(response) {
    $rootScope.TugasMahasiswaClient.Status = response.status;
    $rootScope.TugasMahasiswaClient.Response = response.data;
    $rootScope.TugasMahasiswaClient.StatusText = response.statusText;

  },
  function(response) {
    $rootScope.TugasMahasiswaClient.Status = response.status;
    $rootScope.TugasMahasiswaClient.Response = response.data;
    $rootScope.TugasMahasiswaClient.StatusText = response.statusText;

  });
};

}]);

App.Ctrls.controller("ViewNilaiTugasMahasiswaCtrl", ["$scope", "$rootScope", "$sce", "$interval", "$http", "$uibPosition", "blockUI",

function($scope, $rootScope, $sce, $interval, $http, $position, blockUI) {

$rootScope.ViewNilaiTugasMahasiswa = {};

window.App.ViewNilaiTugasMahasiswa = {};

window.App.ViewNilaiTugasMahasiswa.Scope = $scope;

$rootScope.App.CurrentView = "ViewNilaiTugasMahasiswa";

angular.element(window.document).ready(function(event){
$rootScope.ViewNilaiTugasMahasiswa.Event = event;

$rootScope.NAMA = $scope.getLocalOption($rootScope.NAMA);

$rootScope.USER = $scope.getLocalOption($rootScope.USER);

$rootScope.ID_USER = $scope.getLocalOption($rootScope.ID_USER);

$rootScope.URL_SERVER = $scope.getLocalOption($rootScope.URL_SERVER);

$rootScope.FILE_SERVER = $scope.getLocalOption($rootScope.FILE_SERVER);

window.App.Debugger.log("Cek Param "+$rootScope.ID_USER+" "+$rootScope.NAMA+" "+$rootScope.USER+"  "+$rootScope.URL_SERVER+" "+$rootScope.FILE_SERVER+"", "info", 0);

$rootScope.NilaiTugasMahasiswaCLient.Request.data = {};

$rootScope.NilaiTugasMahasiswaCLient.Request.url = $rootScope.URL_SERVER;

$rootScope.NilaiTugasMahasiswaCLient.Request.data.type = "get_tugas_kumpul";

$rootScope.NilaiTugasMahasiswaCLient.Request.data.A = $rootScope.ID_USER;

$rootScope.NilaiTugasMahasiswaCLient.Request.data.ID = "Learning.API";

$rootScope.NilaiTugasMahasiswaCLient.Execute();

$rootScope.ViewTugasClientLoader.Hidden = "";

$rootScope.$apply();
});

$scope.ReportNilaiTugasRowClick = function($event, record) {
$rootScope.ReportNilaiTugas.Event = $event;
$rootScope.ReportNilaiTugas.Record = record;

$scope.setLocalOption("TugasPilih", ""+$rootScope.ReportNilaiTugas.Record.ID+"");

$scope.setLocalOption("IDPilih", ""+$rootScope.ReportNilaiTugas.Record.Tugas+"");

$scope.showModalView("DetailNilaiMahasiswa");

};

$rootScope.ReportNilaiTugas.GetData = function() {
if($rootScope.ReportNilaiTugas.Url == ""){return;}
$http.get($rootScope.ReportNilaiTugas.Url)
.then(function(response) {
$rootScope.ReportNilaiTugas.Status = response.status;
$rootScope.ReportNilaiTugas.Data = response.data;

},
function(response) {
$rootScope.ReportNilaiTugas.Status = response.status || "";
$rootScope.ReportNilaiTugas.Data = response.data || "";

if (""+$rootScope.NotesReport.Data+"" != "") {

$rootScope.LastError = ""+$rootScope.NotesReport.Data+"";

} else {

$rootScope.LastError = "We can't connect to the server.";

}

$scope.replaceView("Error");

});
};
$rootScope.$watch("ReportNilaiTugas.Url", function() {
  $rootScope.ReportNilaiTugas.GetData();
});

$scope.HtmlContent45Click = function($event) {
$rootScope.HtmlContent45.Event = $event;

$scope.DoShowMenu();

};

$scope.HtmlContent46Click = function($event) {
$rootScope.HtmlContent46.Event = $event;

$scope.replaceView("HomeDosen");

};

$rootScope.NilaiTugasMahasiswaCLient.Execute = function() {
  $http($rootScope.NilaiTugasMahasiswaCLient.Request)
  .then(function(response) {
    $rootScope.NilaiTugasMahasiswaCLient.Status = response.status;
    $rootScope.NilaiTugasMahasiswaCLient.Response = response.data;
    $rootScope.NilaiTugasMahasiswaCLient.StatusText = response.statusText;

$rootScope.ReportNilaiTugasLoader.Hidden = "true";

$rootScope.ReportNilaiTugas.Data = [];

$rootScope.TotalRecords = $rootScope.NilaiTugasMahasiswaCLient.Response.length;

$rootScope.I = 0;

for ($rootScope.I = 1; $rootScope.I <= $rootScope.TotalRecords; $rootScope.I++) {

$rootScope.Item = $rootScope.NilaiTugasMahasiswaCLient.Response[$rootScope.I+-1];

if (""+$rootScope.Item.B+"" ==  "FALSE" ) {

$rootScope.ReportNilaiTugas.Loading = "Data tidak ditemukan";

return null;

}

$rootScope.Record = {};

$rootScope.Record["Nomer"] = $rootScope.I;

$rootScope.Record["Title"] = ""+$rootScope.Item.D+"";

$rootScope.Record["Description"] = ""+$rootScope.Item.J+".";

$rootScope.Record["Tanggal"] = ""+$rootScope.Item.L+".";

$rootScope.Record["Berkas"] = ""+$rootScope.Item.K+".";

$rootScope.st = ""+$rootScope.Item.J+"";

$rootScope.st = window.App.Utils.subStr($rootScope.st, 0, 200);

$rootScope.Record["SDesc"] = ""+$rootScope.st+"..";

$rootScope.Record["ID"] = ""+$rootScope.Item.H+"";

$rootScope.Record["Nama"] = ""+$rootScope.Item.G+"";

$rootScope.Record["NIP"] = ""+$rootScope.Item.F+"";

$rootScope.Record["Nilai"] = ""+$rootScope.Item.M+"";

$rootScope.Record["MK"] = ""+$rootScope.Item.C+"";

$rootScope.Record["ISI"] = ""+$rootScope.Item.J+"";

$rootScope.Record["Tugas"] = ""+$rootScope.Item.L+"";

$rootScope.ReportNilaiTugas.Data.push($rootScope.Record);

}

  },
  function(response) {
    $rootScope.NilaiTugasMahasiswaCLient.Status = response.status;
    $rootScope.NilaiTugasMahasiswaCLient.Response = response.data;
    $rootScope.NilaiTugasMahasiswaCLient.StatusText = response.statusText;

$rootScope.ReportNilaiTugasLoader.Hidden = "true";

  });
};

}]);

App.Ctrls.controller("DetailNilaiMahasiswaCtrl", ["$scope", "$rootScope", "$sce", "$interval", "$http", "$uibPosition", "blockUI",

function($scope, $rootScope, $sce, $interval, $http, $position, blockUI) {

$rootScope.DetailNilaiMahasiswa = {};

window.App.DetailNilaiMahasiswa = {};

window.App.DetailNilaiMahasiswa.Scope = $scope;

$rootScope.App.CurrentView = "DetailNilaiMahasiswa";

$scope.Button18Click = function($event) {
$rootScope.Button18.Event = $event;

$scope.openWindow(""+$rootScope.FILE_SERVER+""+$rootScope.ReportNilaiTugas.Record.Berkas+"", "");

};

$scope.HtmlContent48Click = function($event) {
$rootScope.HtmlContent48.Event = $event;

$scope.closeModalView();

};

}]);

App.Ctrls.controller("ViewTugasMahasiswaDosenCtrl", ["$scope", "$rootScope", "$sce", "$interval", "$http", "$uibPosition", "blockUI",

function($scope, $rootScope, $sce, $interval, $http, $position, blockUI) {

$rootScope.ViewTugasMahasiswaDosen = {};

window.App.ViewTugasMahasiswaDosen = {};

window.App.ViewTugasMahasiswaDosen.Scope = $scope;

$rootScope.App.CurrentView = "ViewTugasMahasiswaDosen";

angular.element(window.document).ready(function(event){
$rootScope.ViewTugasMahasiswaDosen.Event = event;

$rootScope.P_NilaiTugas.Value = parseFloat($rootScope.ReportTugasMahasiswaDosen.Record.Nilai);

$rootScope.$apply();
});

$scope.Button19Click = function($event) {
$rootScope.Button19.Event = $event;

$scope.openWindow(""+$rootScope.FILE_SERVER+""+$rootScope.ReportTugasMahasiswaDosen.Record.Berkas+"", "");

};

$scope.HtmlContent50Click = function($event) {
$rootScope.HtmlContent50.Event = $event;

$scope.closeModalView();

};

$scope.Button20Click = function($event) {
$rootScope.Button20.Event = $event;

if($rootScope.P_NilaiTugas.Value == ''  ) {

$scope.alertBox("Maaf inputan tidak boleh ada yang kosong", "danger");

return null;

} else {

}

$scope.closeModalView();

$scope.confirm("Konfimasi", "Yakin untuk menyimpan data ?", (("DoSimpanNilai".length > 0) && angular.isFunction($scope["DoSimpanNilai"])) ? $scope["DoSimpanNilai"] : null);

};

}]);
